require("./system/module.js")

//==============================================//
global.owner = "99999999999"
global.namabot = "LINUX THERE" 
global.versi = "9.0.0"
global.negara = "RUSIA🇷🇺"
global.namaOwner = "LIUX HERE"
global.namaowner = "VPS PRIVATE"
global.packname = "LINUX"
global.author = "LINUX"
global.botname = "FORM BELOW"
global.botname2 = "$"
global.thumbbot = "https://files.catbox.moe/na6kpv.jpg"
global.urlfoto = 'https://files.catbox.moe/na6kpv.jpg'

global.image = {
digitalocean: "https://files.catbox.moe/poqknz.jpg",
reply: "https://files.catbox.moe/na6kpv.jpg", 
menu: "https://files.catbox.moe/poqknz.jpg",    
};
//==============================================//
global.linksaluran = ""
global.linkweb = ""

global.idsaluran = "@newsletter"
global.namasaluran = "lupa"
global.channel = "https://whatsapp.com/channel/0029Vb6cTegAzNc0OuTBXM02"
global.linkgrub = "",

global.apiDigitalOcean = {
    akun1: "",
    akun2: "_",
    akun3: "_",
    akun4: "—",
    akun5: "—",
    akun6: "—",
    akun7: "—",
    akun8: "—",
    akun9: "—",
    akun10: "—",
    akun11: "—",
    akun12: "—",
    akun13: "—",
    akun14: "—",
    akun15: "—",
    akun16: "—",
    akun17: "—",
    akun18: "—",
    akun19: "—",
    akun20: "—"
}

global.subdomain = {
    "aditt-store.my.id": {
        zone: "7e91d270e6852dbcf3843d55f05f167f", 
        apitoken: "5mrHAyGUu4PcabM5d0S0aWOr3ScNxf27jL09ki0f"
    }, 
    "agcloud.my.id": {
        zone: "09c637a74efd85e94e035eeae2aa3c31", 
        apitoken: "Hi5A5xlLHR8q1glXHCAB1p-hOMf2Z1AVgLkFwwRn"
    },
    "bokepp.biz.id": {
        zone: "46b8cab5631c6c23c5ec4a7ef1f10803", 
        apitoken: "A8df8PxnKIcxLUTE7XS4TRZBoLslvt4XjJb1XEyi"
    }, 
    "brannmarket.biz.id": {
        zone: "d8fcdee77abf68fc1fd39e8c8ff4fe3f",
        apitoken: "_d5Sm2sdygEcA8ycWT05bfKkTlJNy-vKcOBPjWdz"
    },
    "cafee.my.id": {
        zone: "0d7044fc3e0d66189724952fa3b850ce", 
        apitoken: "wAOEzAfvb-L3vKYE2Xg8svJpHfNS_u2noWSReSzJ"
    }, 
    "celestialhost.my.id": {
        zone: "8ebca468945d4ce2ca5ca3c3e9cfae00",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "celestialnet.biz.id": {
        zone: "c926c4b135796bd3eba2e5fd27537cbf",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "centzzcloud.my.id": {
        zone: "749f1d7d69e9329195761b570010c00f", 
        apitoken: "9Su8A1EDXnt9-yGDb7YSGlY_ogJAw2vR9IDtpFrQ"
    },
    "chizyy.my.id": {
        zone: "057cbf622eed270982769d5557dcee59",
        apitoken: "BUg6UBu_68M1fG21nD6QzZkkpa9_Zp3hP54LsxX3"
    },
    "cloud-hosting.my.id": {
        zone: "47510cfd81f2c9991c693224fac38ef0",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "cloudnet.biz.id": {
        zone: "a88065c5d2ee79fedff60df97e002d09",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "cloudspace.my.id": {
        zone: "c091d8d7d101c6b254d86458a705b85f",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "cupenpendiem.shop": {
        zone: "a70c572f7c8f8bc0ad5ac2552e42e516", 
        apitoken: "VEtKD6sBAvgwQd1pYBV957Rno1feXoxqXPo1biij"
    }, 
    "digihost.biz.id": {
        zone: "0552c8910cc9dbbb2f4056c580504b7b",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "digital-market.web.id": {
        zone: "652c4800932a51249d42099dcfd55d0d", 
        apitoken: "wUQ8mx8_thiR0lq_sZ0bhyEjdo-UIs9iZojgTi7g"
    },
    "ekiofficial.my.id": {
        zone: "df33365b44b11cbe51570a7ed981cae5", 
        apitoken: "rMJGbyeuwFVZJifsB3rIX-nRpIOOa4Wkrhu7V5Jo"
    },
    "ekiofficial.web.id": {
        zone: "e1b037c00268cae95076b58f7f78b1f6", 
        apitoken: "EJO7mHrBORH9XoQrnUvBqotMYxNm5bjB5UO2PeQE"
    },
    "eki-panelpvrt.my.id": {
        zone: "6b4cb792b77b6118e91d8604253ca572", 
        apitoken: "DsftwwFCAKrbSo-9r9hxqcscMw8Xvx8gQzTXMSz4"
    },
    "gacorr.biz.id": {
        zone: "cff22ce1965394f1992c8dba4c3db539", 
        apitoken: "v9kYfj5g2lcacvBaJHA_HRgNqBi9UlsVy0cm_EhT"
    },
    "googlehost.biz.id": {
        zone: "aab7652200b19a2d3309f4fc09b60d09",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "googlex.my.id": {
        zone: "dda9e25dac2556c7494470ee6152fc7f",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "heavencraft.my.id": {
        zone: "9e7239dcda7cbd6be79d7615257f56f8", 
        apitoken: "aHvYYKk7YIADVOfpG3i1eaIqTeWCdPS25FAPreDQ"
    },
    "hilman-store.web.id": {
        zone: "4e214dfe36faa7c942bc68b5aecdd1e9",
        apitoken: "wpQCANKLRAtWb0XvTRed3vwSkOMMWKO2C75uwnKE"
    },
    "hilmanofficial.tech": {
        zone: "c8705bfbfdca9c4e8e61eb2663ee87d6",
        apitoken: "hjqWa_eFAfoJNJyBu9WAlg8WO0ICtN5AYpZURgqe"
    },
    "hilmanzoffc.web.id": {
        zone: "2627badfda28951bfb936fce0febc5b0",
        apitoken: "wZ3QAKn7zDx-tyb04HgCvmogqeM6je8jDNmiPZXq"
    },
    "host-panel.web.id": {
        zone: "74b3192f7c3b0925cdb8606bb7db95c4",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "hostingers-vvip.my.id": {
        zone: "2341ae01634b852230b7521af26c261f",
        apitoken: "Ztw1ouD8_lJf-QzRecgmijjsDJODFU4b-y697lPw"
    },
    "hostingnusantara.my.id": {
        zone: "156715abae5f34849a0f936753c986c8",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "hostpanel.biz.id": {
        zone: "76acbc398ab09c2bc0b179a7fa9ef488",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "hostsatoruu.biz.id": {
        zone: "30ea1aac05ca26dda61540e172f52ff4", 
        apitoken: "eZp1wNcc0Mj-btUQQ1cDIek2NZ6u1YW1Bxc2SB3z"
    },
    "hypertech.my.id": {
        zone: "49cb6f9b5bba0de92b82ea96bbaccb29",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "indopanel.my.id": {
        zone: "efa9ae7dc01901c96f669e7d3d4961ec",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "jstpiwz.my.id": {
        zone: "f1901becfbd79f39048f7698de71d53b",
        apitoken: "g8_D70UKwk0hBeuPqdXgWmZcoNjwXMkfd3OEUL4k"
    },
    "jokowii.my.id": {
        zone: "67a887a21f43fea088a47902a436c400", 
        apitoken: "FwLKNhNL5LhI_LhAzH7pD-v6BrIcQ5dsdKRtaytS"
    },
    "kenz-host.my.id": {
        zone: "df24766ae8eeb04b330b71b5facde5f4",
        apitoken: "fyaxLxD0jNONtMWK3AmnaiLkkWi5Wg3Y9h8nqJh6"
    },
    "lexcz.me": {
        zone: "7a4e7ca1131daf5a4c7ef03191432a6a",
        apitoken: "DTxnQFaoI9p2YtZUL7PLikauBvXcL_CWzpBbQx2b"
    },
    "lexczalok.xyz": {
        zone: "dd510b41fc4d7074c5be6f47f9f5b722",
        apitoken: "IsRLdOOP7OVrB95PUWaW_eq1n5T2T8OUcnwGhP_q"
    },
    "mafiapnel.my.id": {
        zone: "34e28e0546feabb87c023f456ef033bf", 
        apitoken: "bHNaEBwaVSdNklVFzPSkSegxOd9OtKzWtY7P9Zwt"
    },
    "markethosting.web.id": {
        zone: "605164b2473c56bc63ab93f729ad60b3",
        apitoken: "cNx00jgbyhIQXbDUQ3iptLPmjgxRmz2P4jJ4q0nx"
    },
    "market-store.my.id": {
        zone: "4ae70eaa56096fdb94ef9050dde52220", 
        apitoken: "_T1fxXQLd6864mYGwgHmciZMiLURKNkyomaPv0sy"
    },
    "marketrikishop.my.id": {
        zone: "33970794e3373167a9c9556ad19fdb6a",
        apitoken: "TWf7dzMAu1dOc0XNuE98auJiSryxkUkQBbJpkwgr"
    },
    "metabot.biz.id": {
        zone: "d326a4d2754a82ccfbacd7a7d32115c4",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "mypanel.web.id": {
        zone: "b8233801ad0b684d315c19b4b3963463",
        apitoken: "Jxwpvdw2IkwtuS-Dv97c0DQFZOQcrvDaM31HtiiU"
    },
    "nextgenhost.my.id": {
        zone: "2844e71ed4f3da615d190b5a0a3628c6",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "nusantarahost.biz.id": {
        zone: "11739916a6aed214d45c679317fbb574",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "nusantarahost.my.id": {
        zone: "2389dab552f48c793e188ab8cc6d15e9",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "nusantarahost.web.id": {
        zone: "83398bb8adb915deb77d4fb6e7595fb4",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "pakvinsen.me": {
        zone: "3b8cb89265c0e026abaf3bc50ed57e76", 
        apitoken: "ttt0IHK50UKP2HltWUauuyDzkVPqnOEkx7M-5CFs"
    },
    "panel-pvrt.my.id": {
        zone: "ee4060e03b223e8e0724908575b70c3b", 
        apitoken: "6HxTQ0VJZVcAJISlKsezttCNzpAAf7ubPy5EDOGR"
    },
    "paneldo.biz.id": {
        zone: "21540fba8e682ddc1b73ad5603aaeccb",
        apitoken: "lkgTTdCe7LQvmU4eYuoseuR0qyFugLB8QHCz5gFn"
    },
    "panelhost.my.id": {
        zone: "380d161fa020353cd874bdd6b2d4318b",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "panelkishop.web.id": {
        zone: "8f4812b3c78ca478b5d162b6cb35d1b3",
        apitoken: "3Y0cW3cVVIhyeWHytqFEbGDrdWaAC-k8twOEeFP2"
    },
    "panelku-ptero.my.id": {
        zone: "ea719beeec3cfe39b58f0195f848498f",
        apitoken: "Gb8j0xFasrWB1k80b4BFrIL_f2IgAQ5n66CamFbP"
    },
    "panelku-vip.my.id": {
        zone: "0d9911cf588f189a626249a082af24be",
        apitoken: "jsli552xYmcVeVyX2-ulWeepLK_-XCqiar0PxO7l"
    },
    "panelprivate.biz.id": {
        zone: "a6ac45aec9d526564078cde7a449780d",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "panelpro.fun": {
        zone: "a5c4697e86cf1cda49c0f81a699a690e",
        apitoken: "k-ZxmwqjyZf7iu4zNSJDTIx2tH6JZ--JQgfZReM9"
    },
    "panelpublic.biz.id": {
        zone: "92ed47fdfb94db589708b8057d44087f",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "panelstore-vvip.biz.id": {
        zone: "a99445e7459f95735af8e44f43b03834",
        apitoken: "pOKX689oVlJCQBq1awwHkok-o3cKyOEk6vq8AGoe"
    },
    "panelvip.biz.id": {
        zone: "70969a584446a244efe1461f5bb41ff5", 
        apitoken: "pzj2mcvQL1KUQCjj5XjSVPjLqKGCy8U7PtVFuOXr"
    },
    "panelzone.my.id": {
        zone: "e7d8d6265266607e97e798db02bef310",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "prabowoo.my.id": {
        zone: "af679c959583e9eff1685ef4c7cbf048", 
        apitoken: "gGQeMyeo8jM5xNGMsfChkwrawZ3UiX3QUnBnvwTe"
    },
    "privatehost.biz.id": {
        zone: "6ffb0b15b396774ebc8f4342351fdc83",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "privatesrvr.xyz": {
        zone: "b488e5d4635431243cab94d5fec4a3d2",
        apitoken: "Wv6SqCo8772I6WG-EGnD4w272sJsYVSXd-LpPc7C"
    },
    "publicserver.my.id": {
        zone: "b1b16801d28009e899a843b0c8faee34",
        apitoken: "y_0WKCNCnOgx0sgbcQr-puVTXyTQPN9KErR9vlzN"
    },
    "pterodactyl-io.web.id": {
        zone: "40e7e47e12e091756d491cb0e8500a5d",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "pterodactyl-panel.web.id": {
        zone: "d69feb7345d9e4dd5cfd7cce29e7d5b0",
        apitoken: "32zZwadzwc7qB4mzuDBJkk1xFyoQ2Grr27mAfJcB"
    },
    "pterodaytl.my.id": {
        zone: "828ef14600aaaa0b1ea881dd0e7972b2",
        apitoken: "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
    },
    "ptero-panellku.web.id": {
        zone: "429c740cae756ab9958481108e851092",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "rapziexdserverbotwa.web.id": {
        zone: "490a3eaced4eb712ae90d50e5d581cc7", 
        apitoken: "79rgceVB_twEtUEwYMpa9ECuY4hX36tZn9l3ME9P"
    },
    "rexxa.my.id": {
        zone: "b0d37cb6e9d6a7c2b0a82395cbdfd8b9", 
        apitoken: "fR2LO4Hz2y0U8dP3IHRwMHnWi_xKKa5RCZjWaXv3"
    },
    "rexxaoffc.my.id": {
        zone: "f972ed410a833b28c8b5f166d6620d6a", 
        apitoken: "liq8sBPHwvbU2jWQYTCjo4BXafVPeopkAU4avUlP"
    },
    "rikionline.shop": {
        zone: "082ec80d7367d6d4f7c52600034ac635", 
        apitoken: "r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l"
    },
    "roompanelpriv.my.id": {
        zone: "73f4d0171fe1f48db80aed6323e9330d",
        apitoken: "2c29LWyyTHGXNtccxA62QWCGmxRcLoGcB9Y35jrH"
    },
    "sanoofficial.my.id": {
        zone: "86baa73720986cb2197874ea944d0dd4",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "sanoofficial.web.id": {
        zone: "ff6deb4d464da2c98495a1d296c32f2c",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "sanoofc.web.id": {
        zone: "3b73e863885615fd2c868e04da4ceee6",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "sanoku.my.id": {
        zone: "bfc41b55bed6504cdf0c82e582e28e09",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "sanoku.web.id": {
        zone: "b87085523ab13773d2dc25f13ec53eb2",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "satoruuhost.tech": {
        zone: "086b2b4e1c65c22bfd8d5d86cbfa947f", 
        apitoken: "62XZSKEzz4mKM_1wAHK7-_JaA14VrQJDoWI2GeHT"
    },
    "servemcpec.my.id": {
        zone: "bb0b767035e14c69cecfdd3eb757b322", 
        apitoken: "S9-2ht3ZxW0B8JjkTI720WaM743nvJKwXfMw3pXI"
    },
    "serverpanell.biz.id": {
        zone: "225512a558115605508656b7bdf29b28", 
        apitoken: "XasxSSnGp8M9QixvT6AAlh1vEm4icVgzDyz7KDiF"
    },
    "sevsbotz.xyz": {
        zone: "594ebd64574548c2cdda04f500059bf3",
        apitoken: "IDjXUZTsJejkc4hGIU3j-_7h7_i531MxOlb3drVf"
    },
    "shop-panel.biz.id": {
        zone: "62e0683ee057e0e2a39eaf73d18e6eb1", 
        apitoken: "opUN9xsI7mlS3CP8cJA9RbO5SB4gUpcyof9Yaeb7"
    },
    "storedigital.web.id": {
        zone: "2ce8a2f880534806e2f463e3eec68d31",
        apitoken: "v5_unJTqruXV_x-5uj0dT5_Q4QAPThJbXzC2MmOQ"
    },
    "storeid.my.id": {
        zone: "c651c828a01962eb3c530513c7ad7dcf",
        apitoken: "N-D6fN6la7jY0AnvbWn9FcU6ZHuDitmFXd-JF04g"
    },
    "store-panell.my.id": {
        zone: "0189ecfadb9cf2c4a311c0a3ec8f0d5c", 
        apitoken: "eVI-BXIXNEQtBqLpdvuitAR5nXC2bLj6jw365JPZ"
    }, 
    "tamaoffc.biz.id": {
        zone: "177538af7fb12443a80892554d01206f",
        apitoken: "ZaVSjxa96NQDV6lQgspAVsVXrvVzdOpqL1z6PG0Z"
    },
    "tokopanelkishop.biz.id": {
        zone: "d87d4f320d9902f31fbbcc5ee23fafe8",
        apitoken: "D00akOLxF3qzBzpYBp5SbpaLTmwYeybNsyAcDfiB"
    },
    "vipstoree.my.id": {
        zone: "72fd03404485ddba1c753fc0bf47f0b3", 
        apitoken: "J2_c07ypFEaen92RMS7irszQSrgZ_VFMfgNgzmp0"
    }, 
    "wannhosting.biz.id": {
        zone: "4e6fe33fb08c27d97389cad0246bfd9b",
        apitoken: "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
    },   
    "wannhosting.my.id": {
        zone: "0b36d11edd793b3f702e0591f0424339",
        apitoken: "OsSjhDZLdHImYTX8fdeiP1wocKwVnoPw5EiI85IF"
    }, 
    "webpanelku.my.id": {
        zone: "b41c3bb25273c4059b542c381250c9f9",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "xnxxx.tech": {
        zone: "639f9cde20c22b1d2f33b2fee54f8f59",
        apitoken: "MtWI3a9-9Za-fGKmwl0uNznqM94eljKgobkF36h1"
    },
    "xyro.me": {
        zone: "a1c08ecd2f96516f2a85250b98850e8b", 
        apitoken: "f3IBOeIjRHYSsRhzxBO7yiwl-Twn3fqjmdkLdwlf"
    }, 
    "xyro.web.id": {
        zone: "46d0cd33a7966f0be5afdab04b63e695", 
        apitoken: "CygwSHXRSfZnsi1qZmyB8s4qHC12jX_RR4mTpm62"
    }, 
    "xyroku.my.id": {
        zone: "f6d1a73a272e6e770a232c39979d5139", 
        apitoken: "0Mae_Rtx1ixGYenzFcNG9bbPd-rWjoRwqN2tvNzo"
    }, 
    "xpanelprivate.my.id": {
        zone: "f6bd04c23d4de3ec6d60d8eeabe1ff40", 
        apitoken: "su_zz3Amd5WkrOv95OA6uQb1Y6ky6qVtjkhQnPCi"
    },
    "zainhosting.my.id": {
        zone: "c3eeb2afb2e4073fe4c55ad7145395e9", 
        apitoken: "RNlg5vrTwt73uAPTYAad_nJzBmDhhjbUZKiWFORZ"
    },
    "zhirastoreid.me": {
        zone: "fc6c7f786d01a0c7558a313549134a06", 
        apitoken: "STOIGXwGftk-OjdgCbqpCDaBWCYUpo5RgvmJ-rXe"
    },
    "zyydev.my.id": {
        zone: "337aaf9a6689c7a7145480ef3ccaffdb",
        apitoken: "jnNO465SjNC-Ss6CDM2WDIy7jwzbKWHJuOXA5xak"
    }
}
//==============================================//
global.mess = {
wait: "⏳ 𝗟𝗢𝗔𝗗𝗜𝗡𝗚...", 
premium: "⚠️ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗧𝗢𝗟𝗔𝗞 ⚠️\n𝗙𝗜𝗧𝗨𝗥 𝗜𝗡𝗜 𝗛𝗔𝗡𝗬𝗔 𝗨𝗡𝗧𝗨𝗞 𝗨𝗦𝗘𝗥 𝗥𝗘𝗦𝗘𝗟𝗘𝗥 𝗩𝗣𝗦",
owner: "⚠️ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗧𝗢𝗟𝗔𝗞 ⚠️\n𝗙𝗜𝗧𝗨𝗥 𝗜𝗡𝗜 𝗛𝗔𝗡𝗬𝗔 𝗨𝗡𝗧𝗨𝗞 𝗢𝗪𝗡𝗘𝗥!", 
group: "Fitur ini untuk dalam grup!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})