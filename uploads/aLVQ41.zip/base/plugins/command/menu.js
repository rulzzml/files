import fs from "fs"
import speed from 'performance-now'

const handler = async (m, { sock, qtxt, getPluginStats, usedPrefix }) => {

  const info = getPluginStats();
  const timestamp = speed();
  const latency = (speed() - timestamp).toFixed(4);
  
 let teks = `Hai @${m.sender.split("@")[0]}
 
 \`\`\`Info - Script\`\`\`
- Name bot : ${global.namaBot}
- Developer : ${global.namaOwner}
- Total plugins : [${info.totalFiles}] files 
- Plugin category : [${info.totalCategory}] folder 

 *./plugins-cmd*
  └── ${usedPrefix}addplugin 
  └── ${usedPrefix}listplugin 
  └── ${usedPrefix}delplugin 
  └── ${usedPrefix}geplugin 

 *./owners-cmd*
   └── ${usedPrefix}backup 
   └── ${usedPrefix}restart 
   └── ${usedPrefix}clearsesion 
   └── ${usedPrefix}bot-off 
   └── ${usedPrefix}bot-on 
   └── ${usedPrefix}bot /cek status on/off 
   └── ${usedPrefix}gantifile /ubah file 
   └── q 
   └── eval 
   └── $ 
   └── > 

 *./main-cmd*
   └── ${usedPrefix}sticker 
   └── ${usedPrefix}tourl 
   └── ${usedPrefix}ping 
   └── ${usedPrefix}owner

 *./tools-cmd*
   └── ${usedPrefix}toimage 
   └── ${usedPrefix}tovid
   └── ${usedPrefix}tovn`;
   
await sock.sendMessage(m.chat, {
    text: teks,
    footer: footer,
    interactiveButtons: [
      {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "お",
          url: global.url 
        })
      }
    ],
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender], 
      forwardedNewsletterMessageInfo: {
        newsletterName: global.namaChannel,
        newsletterJid: global.idChannel,
      }, 
      externalAdReply: { 
        title: namaBot, 
        body: global.ucapan(),
        thumbnailUrl: foto,
        sourceUrl: global.url,
      }
    }
  }, { quoted: qtxt });
}
handler.command = ["menu", "mani"];
export default handler;