import fs from "fs";
import { ImageUploadService } from "node-upload-images";

const handler = async (m, { sock, reply, isOwner, qmsg, mime }) => {
  if (!/image/.test(mime)) return reply("Kirim atau reply ke gambar!");

  try {
    // Download media ke file sementara
    const mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
    const buffer = fs.readFileSync(mediaPath);

    // Upload ke PixHost
    const service = new ImageUploadService("pixhost.to");
    const result = await service.uploadFromBinary(buffer, "jarroffc.png");

    if (result?.directLink) {
      await sock.sendMessage(m.chat, { text: result.directLink }, { quoted: m });
    } else {
      await reply("Gagal mengunggah gambar ke server.");
    }

    // Hapus file setelah selesai
    fs.unlinkSync(mediaPath);

  } catch (err) {
    console.error("Tourl Error:", err);
    reply("Terjadi kesalahan saat mengubah media menjadi URL.");
  }
};

handler.command = ["tourl"];
export default handler;