module.exports = {

 // ==== Bot Setting ========
  botToken: "7890651841:AAFwPcCeZ223oPBCmhf386bVeqkQKaghghk",
  botUsername: "RulzzOfficiaL-AutoBotz",
  menuImage: "https://files.catbox.moe/37btn5.jpg",
  prefix: "/",
  ownerName: "Rulzz OfficiaL",
  ownerUsername: "rulzzofficial",
  ownerId: "5679477929",
  channelLink: "https://whatsapp.com/channel/0029Vb5vjppCsU9Pmo3UUC2H",
  
  // ===== Userbot Setting =====
  apiId: 32202652, // api_id Telegram
  apiHash: "83c27b7c370e065469f18c83c6cf4d41",
  phoneNumber: "6285133225756", 
  sessionFile: "./session.txt", 

  // "orderkuota" atau "pakasir"
  paymentGateway: "orderkuota",

  // ===== OrderKuota Config =====
  orderkuota: {
    apikey: "verlangid",
    username: "rulzzofficial",
    token: "2166067:VnRhdXsrJQ2KFMy8bIz14pxle7ECgDqG",
    qrisCode: "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214513122296449660303UMI51440014ID.CO.QRIS.WWW0215ID20253689005640303UMI5204541153033605802ID5924RULZZ OFFICIAL OK21660676009SUKOHARJO61055716162070703A016304A543"
  },
  
  // ===== Pakasir Config =====
  pakasir: {
    slug: "verlang",
    apiKey: "FB8pkT9pbCIGp4SixVdu1e8Sfvm6bfll"
  },

  // Info payment manual (opsional)
  payment: {
    qris: "https://",
    dana: "085182337599",
    ovo: "Tidak tersedia",
    gopay: "Tidak tersedia"
  },
  
  // Apikey Digitalocean
  apiDigitalOcean: "asuuuuuu", 
  
  // ===== Panel Config =====
  egg: "15",
  nestid: "5",
  loc: "1",
  domain: "https://kitabisa.verlang.id",
  apikey: "ptla_l5qJO4QivpH9AO23xztTP5ZZuxYdMLmHbn1lUw5aQWY",
  capikey: "ptlc_v7ICM0qXGqBkpppNLkaroIHXrkCRaJMMi2sFoUNbn9o", 
  
  // ===== Setting Api Subdomain ===
  subdomain: {
    "pterovip.my.id": {
      "zone": "4b262004a90e37c8656accb7087c4150",
      "apitoken": "wb4wjXwwdpIQ9Ezi_zfi0-0fWQD9BYYyTk-1ad4N"
    }, 
    "pteroweb.my.id": {
      "zone": "714e0f2e54a90875426f8a6819f782d0",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },
    "panelwebsite.biz.id": {
      "zone": "2d6aab40136299392d66eed44a7b1122",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },
    "privatserver.my.id": {
      "zone": "699bb9eb65046a886399c91daacb1968",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },
    "serverku.biz.id": {
      "zone": "4e4feaba70b41ed78295d2dcc090dd3a",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },
    "vipserver.web.id": {
      "zone": "e305b750127749c9b80f41a9cf4a3a53",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    }, 
    "mypanelstore.web.id": {
      "zone": "c61c442d70392500611499c5af816532",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    }
  }
  
};