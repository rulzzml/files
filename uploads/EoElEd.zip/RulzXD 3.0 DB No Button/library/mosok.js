const fs = require("fs");
const path = require("path");

let handler = async (m, { Rulzz, isCreator, example, Reply, text, command, mime, qmsg, qlocJpm, sleep, mess }) => {
  if (!isCreator && command !== "listnokos") {
    return Reply(global.mess.owner);
  }

  switch (command) {
    case "unblock":
    case "unblok":
      if (m.isGroup && !m.quoted && !text) {
        return m.reply(example("@tag/nomornya"));
      }
      const memUnblock = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : "";
      await Rulzz.updateBlockStatus(memUnblock, "unblock");
      if (m.isGroup) {
        Rulzz.sendMessage(m.chat, { text: `Berhasil membuka blokiran @${memUnblock.split('@')[0]}`, mentions: [memUnblock] }, { quoted: m });
      }
      break;

    case "delete":
    case "del":
      if (m.isGroup) {
        if (!isCreator && !m.isAdmin) return Reply(mess.admin);
        if (!m.quoted) return m.reply("reply pesannya");
        if (m.quoted.fromMe) {
          Rulzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender } });
        } else {
          if (!m.isBotAdmin) return Reply(mess.botAdmin);
          Rulzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender } });
        }
      } else {
        if (!isCreator) return Reply(mess.owner);
        if (!m.quoted) return m.reply(example("reply pesan"));
        Rulzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender } });
      }
      break;

    case "sendtesti":
    case "testi":
      if (!isCreator) return Reply(global.mess.owner);
      if (!text) return m.reply(example("teks dengan mengirim foto"));
      if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"));

      const allgrup = await Rulzz.groupFetchAllParticipating();
      const res = await Object.keys(allgrup);
      let count = 0;
      const teks = text;
      const jid = m.chat;
      const rest = await Rulzz.downloadAndSaveMediaMessage(qmsg);
      await m.reply(`Memproses pengiriman *testimoni* ke dalam channel & ${res.length} grup chat`);

      await Rulzz.sendMessage(global.idSaluran, { image: await fs.readFileSync(rest), caption: teks });
      for (let i of res) {
        if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue;
        try {
          await Rulzz.sendMessage(i, { image: await fs.readFileSync(rest), caption: teks, contextInfo: { isForwarded: true, mentionedJid: [m.sender], businessMessageForwardInfo: { businessOwnerJid: global.owner + "@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: global.namaSaluran, newsletterJid: global.idSaluran } } }, { quoted: qlocJpm });
          count += 1;
        } catch (e) {
          console.error(e);
        }
        await sleep(global.delayJpm);
      }
      await fs.unlinkSync(rest);
      await Rulzz.sendMessage(jid, { text: `Berhasil mengirim *testimoni* ke dalam channel & ${count} grup chat` }, { quoted: m });
      break;
      
    case "boost":
    case "clearsession":
    case "clsesi":
    case "clearsesi":
      if (!isCreator) return Reply(global.mess.owner);
      const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json");
      const dirsampah = fs.readdirSync("./library/database/sampah").filter(e => e !== "A");
      for (const i of dirsesi) {
        await fs.unlinkSync("./session/" + i);
      }
      for (const u of dirsampah) {
        await fs.unlinkSync("./library/database/sampah/" + u);
      }
      m.reply(`*Berhasil membersihkan sampah ✅*\n*${dirsesi.length}* sampah session\n*${dirsampah.length}* sampah file`);
      break;

    case "anticall":
    case "autoread":
    case "autoreadgc":
    case "autopromosi":
    case "autotyping":
    case "autoreadsw":
      if (!isCreator) return Reply(mess.owner);
      if (!text) return m.reply(example("on/off"));
      if (!/on|off/.test(text)) return m.reply(example("on/off"));

      let event, name, actions;

      if (command == "autoread") {
        event = global.db.settings.autoread;
        name = "Autoread";
        actions = async (kondisi) => {
          global.db.settings.autoread = kondisi;
        };
      } else if (command == "autoreadgc") {
        event = global.db.settings.autoreadgc;
        name = "Autoreadgc";
        actions = async (kondisi) => {
          global.db.settings.autoreadgc = kondisi;
        };
      } else if (command == "autopromosi") {
        event = global.db.settings.autopromosi;
        name = "Autopromosi";
        actions = async (kondisi) => {
          global.db.settings.autopromosi = kondisi;
        };
      } else if (command == "autotyping") {
        name = "Autotyping";
        event = global.db.settings.autotyping;
        actions = async (kondisi) => {
          global.db.settings.autotyping = kondisi;
        };
      } else if (command == "autoreadsw") {
        event = global.db.settings.readsw;
        name = "Autoreadsw";
        actions = async (kondisi) => {
          global.db.settings.readsw = kondisi;
        };
      } else if (command == "anticall") {
        event = global.db.settings.anticall;
        name = "Anticall";
        actions = async (kondisi) => {
          global.db.settings.anticall = kondisi;
        };
      }

      if (text === "on") {
        if (event === true) return m.reply(`*${name} sudah aktif!*`);
        actions(true);
        m.reply(`*${name} berhasil di aktifkan ✅*`);
      } else if (text === "off") {
        if (event === false) return m.reply(`*${name} sudah tidak aktif!*`);
        actions(false);
        m.reply(`*${name} berhasil di matikan ✅*`);
      }
      break;
  }
};