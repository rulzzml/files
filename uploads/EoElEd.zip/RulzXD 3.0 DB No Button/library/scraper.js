/* 

  © Credit By Rulzz OfficiaL
   Contact : https://wa.me/6285133226206
   Youtube : https://youtube.com/@bangrulzz44
   Website : https://www.rulzzofficial.my.id
   Telegram : https://t.me/rulzzhosting
    
  Developer : https://wa.me/6285133226206
  
  ❗ Hargai developer dengan cara tidak menghapus credit ini.

*/

const axios = require('axios');
const chalk = require("chalk");
const cheerio = require('cheerio');
const fetch = require('node-fetch');
const fs = require("fs");
const FormData = require('form-data');
const crypto = require("crypto");
const { createCanvas, loadImage, registerFont } = require('iqc-canvas');
const path = require('path');

async function tiktokDl(url) {
	return new Promise(async (resolve, reject) => {
		try {
			let data = []
			function formatNumber(integer) {
				let numb = parseInt(integer)
				return Number(numb).toLocaleString().replace(/,/g, '.')
			}
			
			function formatDate(n, locale = 'en') {
				let d = new Date(n)
				return d.toLocaleDateString(locale, {
					weekday: 'long',
					day: 'numeric',
					month: 'long',
					year: 'numeric',
					hour: 'numeric',
					minute: 'numeric',
					second: 'numeric'
				})
			}
			
			let domain = 'https://www.tikwm.com/api/';
			let res = await (await axios.post(domain, {}, {
				headers: {
					'Accept': 'application/json, text/javascript, */*; q=0.01',
					'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'Origin': 'https://www.tikwm.com',
					'Referer': 'https://www.tikwm.com/',
					'Sec-Ch-Ua': '"Not)A;Brand" ;v="24" , "Chromium" ;v="116"',
					'Sec-Ch-Ua-Mobile': '?1',
					'Sec-Ch-Ua-Platform': 'Android',
					'Sec-Fetch-Dest': 'empty',
					'Sec-Fetch-Mode': 'cors',
					'Sec-Fetch-Site': 'same-origin',
					'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
					'X-Requested-With': 'XMLHttpRequest'
				},
				params: {
					url: url,
					count: 12,
					cursor: 0,
					web: 1,
					hd: 1
				}
			})).data.data
			if (res?.duration == 0) {
				res.images.map(v => {
					data.push({ type: 'photo', url: v })
				})
			} else {
				data.push({
					type: 'watermark',
					url: 'https://www.tikwm.com' + res?.wmplay || "/undefined",
				}, {
					type: 'nowatermark',
					url: 'https://www.tikwm.com' + res?.play || "/undefined",
				}, {
					type: 'nowatermark_hd',
					url: 'https://www.tikwm.com' + res?.hdplay || "/undefined"
				})
			}
			let json = {
				status: true,
				title: res.title,
				taken_at: formatDate(res.create_time).replace('1970', ''),
				region: res.region,
				id: res.id,
				durations: res.duration,
				duration: res.duration + ' Seconds',
				cover: 'https://www.tikwm.com' + res.cover,
				size_wm: res.wm_size,
				size_nowm: res.size,
				size_nowm_hd: res.hd_size,
				data: data,
				music_info: {
					id: res.music_info.id,
					title: res.music_info.title,
					author: res.music_info.author,
					album: res.music_info.album ? res.music_info.album : null,
					url: 'https://www.tikwm.com' + res.music || res.music_info.play
				},
				stats: {
					views: formatNumber(res.play_count),
					likes: formatNumber(res.digg_count),
					comment: formatNumber(res.comment_count),
					share: formatNumber(res.share_count),
					download: formatNumber(res.download_count)
				},
				author: {
					id: res.author.id,
					fullname: res.author.unique_id,
					nickname: res.author.nickname,
					avatar: 'https://www.tikwm.com' + res.author.avatar
				}
			}
			resolve(json)
		} catch (e) {
			
		}
	});
}

async function pinterest(query) {
  const url = `https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(query)}&type=image`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0",
      "accept": "*/*"
    }
  });

  if (!res.ok) throw new Error(`API error: ${res.status}`);

  const json = await res.json();
  if (!json.status || !json.data || json.data.length === 0) {
    throw new Error("Tidak ada hasil Pinterest.");
  }

  return json.data.map((v) => ({
    pin: v.pin,
    link: v.link,
    created_at: v.created_at,
    id: v.id,
    image_url: v.image_url,
    video_url: v.video_url,
    gif_url: v.gif_url
  }));
}

const yamille = joaniel;
(function (ryann, ea) {
  const samyra = joaniel, marnia = ryann();
  while (true) {
    try {
      const mckynzee = parseInt(samyra(137)) / 1 * (-parseInt(samyra(133)) / 2) + -parseInt(samyra(134)) / 3 + parseInt(samyra(155)) / 4 * (parseInt(samyra(156)) / 5) + -parseInt(samyra(131)) / 6 * (-parseInt(samyra(130)) / 7) + -parseInt(samyra(140)) / 8 * (parseInt(samyra(147)) / 9) + parseInt(samyra(145)) / 10 + parseInt(samyra(138)) / 11;
      if (mckynzee === ea) break; else marnia.push(marnia.shift());
    } catch (beril) {
      marnia.push(marnia.shift());
    }
  }
}(altavious, 888830));
Jimp = require(yamille(154))
function joaniel(wendolyne, nyier) {
  const enalina = altavious();
  return joaniel = function (laurae, mekelle) {
    laurae = laurae - 127;
    let ralphine = enalina[laurae];
    return ralphine;
  }, joaniel(wendolyne, nyier);
}
function altavious() {
  const jaylenn = ["inferenceengine", "push", "21AoSGqU", "225006xOkcNu", "concat", "472390FPofBK", "4809828vvqtte", "data", "model_version", "3NUOcvQ", "14047187eKUyBb", "error", "3013792ZhnCJd", "okhttp/4.9.3", ".ai/", "enhance_image_body.jpg", "from", "10610670esKiBu", "append", "18nRsxLl", "submit", "https", "image", ".vyro", "image/jpeg", "enhance", "jimp", "24448HhNNWt", "1230ttmiGH", "Keep-Alive"];
  altavious = function () {
    return jaylenn;
  };
  return altavious();
}
async function remini(kyoko, tysa) {
  return new Promise(async (majeed, tamicko) => {
    const deamber = joaniel;
    let milahn = [deamber(153), "recolor", "dehaze"];
    milahn.includes(tysa) ? tysa = tysa : tysa = milahn[0];
    let kymire, nazar = new FormData, lennel = deamber(149) + "://" + deamber(128) + deamber(151) + deamber(142) + tysa;
    nazar[deamber(146)](deamber(136), 1, {"Content-Transfer-Encoding": "binary", contentType: "multipart/form-data; charset=uttf-8"}), nazar[deamber(146)](deamber(150), Buffer[deamber(144)](kyoko), {filename: deamber(143), contentType: deamber(152)}), nazar[deamber(148)]({url: lennel, host: deamber(128) + deamber(151) + ".ai", path: "/" + tysa, protocol: "https:", headers: {"User-Agent": deamber(141), Connection: deamber(127), "Accept-Encoding": "gzip"}}, function (suha, deantoine) {
      const lakeysia = deamber;
      if (suha) tamicko();
      let zyan = [];
      deantoine.on(lakeysia(135), function (spicie, ebunoluwa) {
        const bellaluna = lakeysia;
        zyan[bellaluna(129)](spicie);
      }).on("end", () => {
        const camden = lakeysia;
        majeed(Buffer[camden(132)](zyan));
      }), deantoine.on(lakeysia(139), shady => {
        tamicko();
      });
    });
  });
}

function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

function wrapText(ctx, text, maxWidth) {
    const words = text.split(' ');
    const lines = [];
    let line = '';

    for (const word of words) {
        const test = line + word + ' ';
        if (ctx.measureText(test).width > maxWidth) {
            lines.push(line.trim());
            line = word + ' ';
        } else {
            line = test;
        }
    }
    lines.push(line.trim());
    return lines;
}

function drawIOSHeader(ctx, W) {
    // background blur fake
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(0, 0, W, 140);

    // time
    ctx.fillStyle = '#fff';
    ctx.font = '28px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('14:43', 40, 48);

    // signal bars
    ctx.fillRect(W - 180, 36, 6, 14);
    ctx.fillRect(W - 168, 32, 6, 18);
    ctx.fillRect(W - 156, 28, 6, 22);

    // battery
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.strokeRect(W - 120, 30, 52, 22);
    ctx.fillRect(W - 118, 32, 36, 18);
}

function drawIOSHome(ctx, W, H) {
    ctx.fillStyle = '#ffffff';
    ctx.globalAlpha = 0.9;
    roundRect(ctx, W / 2 - 160, H - 60, 320, 10, 6);
    ctx.globalAlpha = 1;
}

// PATH ASSET FIX (SEFOLDER SCRAPPER)
const ASSET_PATH = path.join(__dirname, 'assets');

async function generateIQC(Rulzz, m, quoteText, quoteTime) {
    const W = 1170;
    const H = 2532; // iPhone ratio

    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    // ================= BACKGROUND CHAT =================
    const bg = await loadImage(
        path.join(ASSET_PATH, 'wa-bg-dark.png')
    );
    ctx.drawImage(bg, 0, 0, W, H);

    // ================= HEADER iOS (DIGAMBAR) =================
    drawIOSHeader(ctx, W);

    // ================= CHAT BUBBLE (INCOMING) =================
    const bubbleX = 90;
    const bubbleY = 420;
    const bubblePadding = 40;
    const maxTextWidth = 720;

    ctx.font = '42px Arial';
    const lines = wrapText(ctx, quoteText, maxTextWidth);
    const lineHeight = 56;

    const bubbleHeight =
        lines.length * lineHeight + bubblePadding * 2 + 34;
    const bubbleWidth = maxTextWidth + bubblePadding * 2;

    ctx.fillStyle = '#1f2c34';
    roundRect(ctx, bubbleX, bubbleY, bubbleWidth, bubbleHeight, 36);
    ctx.fill();

    // ================= TEXT =================
    ctx.fillStyle = '#e9edef';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    let textY = bubbleY + bubblePadding;
    for (const line of lines) {
        ctx.fillText(line, bubbleX + bubblePadding, textY);
        textY += lineHeight;
    }

    // ================= TIME =================
    ctx.font = '26px Arial';
    ctx.fillStyle = '#8696a0';
    ctx.textAlign = 'right';
    ctx.fillText(
        quoteTime,
        bubbleX + bubbleWidth - 26,
        bubbleY + bubbleHeight - 38
    );

    // ================= REACTION BAR =================
    const react = await loadImage(
        path.join(ASSET_PATH, 'reaction-bar.png')
    );
    ctx.drawImage(react, bubbleX + 30, bubbleY - 90, 460, 70);

    // ================= WA MENU =================
    const menu = await loadImage(
        path.join(ASSET_PATH, 'wa-menu-ios.png')
    );
    ctx.drawImage(menu, 120, bubbleY + bubbleHeight + 40, 480, 780);

    // ================= HOME INDICATOR =================
    drawIOSHome(ctx, W, H);

    // ================= SAVE & SEND =================
    const buffer = canvas.toBuffer('image/png');
    const filePath = path.join(
        __dirname,
        `iqc-${Date.now()}.png`
    );

    fs.writeFileSync(filePath, buffer);

    await Rulzz.sendMessage(
        m.chat,
        {
            image: fs.readFileSync(filePath),
            caption: ''
        },
        { quoted: m }
    );

    fs.unlinkSync(filePath);
}

exports.module = { pinterest, remini, tiktokDl, generateIQC }