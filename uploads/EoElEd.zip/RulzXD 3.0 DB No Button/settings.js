/* 

  © Credit By Rulzz OfficiaL
   Contact : https://wa.me/6285133226206
   Youtube : https://youtube.com/@bangrulzz44
   Website : https://www.rulzzofficial.my.id
   Telegram : https://t.me/rulzzhosting
    
  Developer : https://wa.me/6285133226206
  
  ❗ Hargai developer dengan cara tidak menghapus credit ini.

*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Setting Botnya
global.owner = '6285133226206'
global.versi = version
global.namaOwner = "Rulzz OfficiaL🔥"
global.packname = 'RulzXD Bot'
global.botname = 'RulzXD Bot'
global.botname2 = 'RulzXD Bot'

global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah
global.prefix = "."
global.pairing "RulzXDGG" // Kode Pairing

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6285133226206"
global.website = "https://www.rulzzofficial.my.id"
global.linkGrup = "https://whatsapp.com/channel/0029VaprsPG6hENim13l6v23"

// Delay Jpm & Push Kontak || 10000 = 10 detik
global.delayJpm = 1000
global.delayPushkontak = 10000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VaprsPG6hENim13l6v23"
global.linksaluransc = "https://whatsapp.com/channel/0029Vb5f0w7AojYlVLBbU40j"
global.idSaluran = "120363338913902426@newsletter"
global.namaSaluran = "Rulzz OfficiaL🔥 [ Testimoni ]"

// Settings Payment Order Kuota
global.kodeqr = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214513122296449660303UMI51440014ID.CO.QRIS.WWW0215ID20253689005640303UMI5204541153033605802ID5924RULZZ OFFICIAL OK21660676009SUKOHARJO61055716162070703A016304A543"
global.username = "rulzzofficial"
global.tokenorkut = "2166067:VnRhdXsrJQ2KFMy8bIz14pxle7ECgDqG"

// Settings Github API untuk Auto Backup Database
global.token = "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"
global.akun = 'rulzzofficial'; // ganti dengan username github
global.repo = 'backup';        // ganti nama repo GitHub

// Settings Api Digital Ocean
global.apiDigitalOcean = "-"
global.apiDigitalOcean2 = "-"

// Settings Api Website Rest Api
global.apikeyRulzXD = "rulzxd_ohyzn72w9c_mhus98ew"

// Settings All Payment
global.dana = "Tidak Tersedia"
global.ovo = "Tidak Tersedia"
global.gopay = "Tidak Tersedia"

// Settings Api Panel Pterodactyl Server 1
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://pannel.rulzzofficial.biz.id"
global.apikey = "ptla_Ncw4qIytvsymTmza1YSRpg4AMl04zeGb47KILBpOrBw" //ptla
global.capikey = "ptlc_mfMu242Aaz2dzH7iP9liMMPJoDKf1OVlGVoUcKPO8tb" //ptlc

// Settings Api Panel Pterodactyl Server 2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://zynn.rulzzofficial.my.id"
global.apikeyV2 = "ptla_jz2WrJPYRfPmRD5Ec4S74uoYxywqDU3BSauGo0KkTlu" //ptla
global.capikeyV2 = "ptlc_RKhlOQVSGMj8Z4rwnRK4el040Wz0PRFYx4wIux42J9I" //ptlc

// Settings Image Url
global.image = {
menu: "https://img1.pixhost.to/images/6937/618113601_rulzz-official.jpg", 
reply: "https://img102.pixhost.to/images/28/556004457_rulzz-official.jpg", 
logo: "https://img102.pixhost.to/images/28/556004457_rulzz-official.jpg", 
qris: "https://img12.pixhost.to/images/811/574585662_rulzz-official.jpg"
}

// Settings Api Domain
global.subdomain = {
"rulzzofficial.my.id": {
"zone": "3906635b804cb14d8219d4eb25425d99",
"apitoken": "AyxZhs9FW894dM7Rl4HFM24HYaNZ7WzqBDNObg1y"
},
"rulzzofficial.biz.id": {
"zone": "d0502f68a91c95c1475a61a65f9b3861",
"apitoken": "JZu10dF1UFXAJ668tGrkqihL-z51asmmpdqCNg9R"
},
"panellvvip-rulzz.my.id": {
"zone": "bc3fc295a8f4f939e6b4e962692ebd2a",
"apitoken": "232-AQl5fF4E_JFGAhbwvkw9GQJw6m6BuKbx8kiS"
},
"pannellku.my.id": {
"zone": "f606f454f146bd54eea2466ed70d972e",
"apitoken": "PHvYOOXMxWZG_w8h2sXieGHlJWDqLuRMTzgX9k1c"
},
"pannel.my.id": {
"zone": "62628ca16584f84b5fb9cb1db2c88df7",
"apitoken": "PHvYOOXMxWZG_w8h2sXieGHlJWDqLuRMTzgX9k1c"
},
"serverhosting.my.id": {
"zone": "bd8fc0c2c9c8bea914ede3941e36db04",
"apitoken": "PHvYOOXMxWZG_w8h2sXieGHlJWDqLuRMTzgX9k1c"
},
"videey.biz.id": {
"zone": "8bb44b8cc26043530997189021661068",
"apitoken": "PHvYOOXMxWZG_w8h2sXieGHlJWDqLuRMTzgX9k1c"
},
"zynn.my.id": {
"zone": "d6ae509ec83ee7956ca4576e84590620",
"apitoken": "PHvYOOXMxWZG_w8h2sXieGHlJWDqLuRMTzgX9k1c"
},
"rulzzyn.biz.id": {
"zone": "db15571952d78946d0526c950c268388",
"apitoken": "PHvYOOXMxWZG_w8h2sXieGHlJWDqLuRMTzgX9k1c"
},
"panelstore-vvip.biz.id": {
"zone": "a99445e7459f95735af8e44f43b03834",
"apitoken": "pOKX689oVlJCQBq1awwHkok-o3cKyOEk6vq8AGoe"
},
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "fnl7ixlJ-Y-7zxJ7EUGEXitfmfLiPGW985iXobdu"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
},
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}
}

// Message Command 
global.mess = {
	owner: "* *Akses Ditolak*\nFitur ini hanya untuk owner!",
	admin: "* *Akses Ditolak*\nFitur ini hanya untuk admin grup!",
	botAdmin: "* *Akses Ditolak*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "* *Akses Ditolak*\nFitur ini hanya untuk dalam grup!",
	private: "* *Akses Ditolak*\nFitur ini hanya untuk dalam private chat!",
	prem: "* *Akses Ditolak*\nFitur ini hanya untuk user premium!",
	sellerprivate: "* *Akses Ditolak*\nFitur ini hanya untuk reseller panel private!",
	seller: "* *Akses Ditolak*\nFitur ini hanya untuk reseller panel!",
	resellersubdo: "* *Akses Ditolak*\nFitur ini hanya untuk reseller subdomain!"
}

global.setting = {
	Owner: "6285133226206"
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})