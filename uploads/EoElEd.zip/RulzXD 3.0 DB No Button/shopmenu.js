/* 

  © Credit By Rulzz OfficiaL
   Contact : https://wa.me/6285133226206
   Youtube : https://youtube.com/@bangrulzz44
   Website : https://www.rulzzofficial.my.id
   Telegram : https://t.me/rulzzhosting
    
  Developer : https://wa.me/6285133226206
  
  ❗ Hargai developer dengan cara tidak menghapus credit ini.
  
  
  FILE KHUSUS SETTING HARGA BUY OTOMATIS !!

*/

const fs = require('fs');
const chalk = require('chalk');

// <-- Harga Akses Panel Pterodactyl -->
global.hargaresspublic = 5000
global.hargaressprivate = 12000
global.hargaadp = 18000
global.hargaptp = 25000
global.hargaownp = 30000

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// <-- Harga Panel Pterodactyl -->
global.panel = {
  "1gb": 1000,
  "2gb": 2000,
  "3gb": 3000,
  "4gb": 4000,
  "5gb": 5000,
  "6gb": 6000,
  "7gb": 7000,
  "8gb": 8000,
  "9gb": 9000,
  "10gb": 10000,
  "unli": 12000
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// <-- Harga VPS Digital Ocean -->
global.vps = {
  "1g1": 15000,
  "2g1": 20000,
  "4g2": 30000,
  "8g4": 45000,
  "16g4": 65000
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// <-- Harga Jasa Jasa -->
global.hargainstalltema = 7000
global.hargainstallpanel = 5000
global.hargahbpanel = 2000
global.hargapwvps = 1000

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// <-- Harga Produk Lainnya -->
global.hargasubdo = 5000
global.hargamurbug = 20000
global.hargaressubdo = 10000
global.hargamurlog = 5000

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// <-- Link Grub -->
global.linkpublic = "https://"
global.linkprivate = "https://"
global.linkmurbug = "https://"
global.linkmurlog = "https://"
global.linkressubdo = "https://"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})