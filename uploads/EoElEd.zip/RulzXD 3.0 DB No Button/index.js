/* 

  © Credit By Rulzz OfficiaL
   Contact : https://wa.me/6285133226206
   Youtube : https://youtube.com/@bangrulzz44
   Website : https://www.rulzzofficial.my.id
   Telegram : https://t.me/rulzzhosting
    
  Developer : https://wa.me/6285133226206
  
  ❗ Hargai developer dengan cara tidak menghapus credit ini.

*/

require("./settings");
require("./RulzXD");
const fs = require("fs");
const pino = require("pino");
const path = require("path");
const axios = require("axios");
const chalk = require("chalk");
const readline = require("readline");
const FileType = require("file-type");
const { exec } = require("child_process");
const { say } = require("cfonts");
const { Boom } = require("@hapi/boom");
const NodeCache = require("node-cache");
const cron = require('node-cron');
const fetch = require('node-fetch');
const {
  default: makeWaSocket,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  useMultiFileAuthState,
  Browsers,
  DisconnectReason,
  makeInMemoryStore,
  makeCacheableSignalKeyStore,
  fetchLatestWaWebVersion,
  proto,
  PHONENUMBER_MCC,
  getAggregateVotesInPollMessage,
} = require("@whiskeysockets/baileys");

const pairingCode =
  global.pairing_code || process.argv.includes("--pairing-code");
  
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const question = (text) => new Promise((resolve) => rl.question(text, resolve));

// ----------------------------------------------------------------------------------
const gambarascii = [
  `
┌─────────────────────────────────────────┐
│                                         │
│   ██████╗ ██╗   ██╗██╗     ███████╗    │
│   ██╔══██╗██║   ██║██║     ╚══███╔╝    │
│   ██████╔╝██║   ██║██║       ███╔╝     │
│   ██╔══██╗██║   ██║██║      ███╔╝      │
│   ██║  ██║╚██████╔╝███████╗███████╗    │
│   ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚══════╝    │
│                                         │
│        RulzXD Bot Version 4.0           │
│        Fast & Stable Edition            │
└─────────────────────────────────────────┘
`,
  `
╔═══════════════════════════════════════╗
║                                       ║
║   ╔═╗╔═╗╦ ╦╔═╗╦═╗╔═╗╔╦╗╔═╗╔╦╗╔═╗     ║
║   ╠═╝║ ║║║║║╣ ╠╦╝╠═╣║║║║╣  ║║╚═╗     ║
║   ╩  ╚═╝╚╩╝╚═╝╩╚═╩ ╩╩ ╩╚═╝═╩╝╚═╝     ║
║                                       ║
║        Support LID/JID Full           ║
║        Optimized for Speed            ║
╚═══════════════════════════════════════╝
`,
  `
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
▓                                         ▓
▓    █▀▀ █▀▀█ █░░█ ▀▀█▀▀ █▀▀█ █▀▀▄       ▓
▓    ▀▀█ █▄▄█ █░░█ ░░█░░ █▄▄█ █░░█       ▓
▓    ▀▀▀ ▀░░▀ ░▀▀▀ ░░▀░░ ▀░░▀ ▀▀▀░       ▓
▓                                         ▓
▓        By: Rulzz Official              ▓
▓        Contact: 6285133226206          ▓
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
`,
];
const imageAscii =
  gambarascii[Math.floor(Math.random() * gambarascii.length)];

// -------------------------- Load Database -------------------------------
const DataBase = require("./source/database");
const database = new DataBase();

(async () => {
  const loadData = await database.read();
  if (!loadData || Object.keys(loadData).length === 0) {
    global.db = { users: {}, groups: {}, database: {}, settings: {} };
    await database.write(global.db);
  } else {
    global.db = loadData;
  }

  setInterval(async () => {
    await database.write(global.db);
  }, 3500);
})();

// --------------------------- Impor Function -------------------------------
const {
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  await,
  sleep,
  generateRandomImage,
  dekr,
  generateAI,
  toGhibli,
  toGhibli2
} = require("./library/function");

const { getEnvValue, setEnvValue } = require("./library/service");

// -------------------------------- Function ----------------------------------
let phoneNumber = "";
async function init() {
  const kui = await generateRandomImage();
  const saved = await getEnvValue("anjay");

  if (saved) {
    if (saved === kui.passwd) {
      console.log(chalk.green.bold("✓ Password benar. Melanjutkan proses..."));
      return;
    } else {
      console.log(chalk.red.bold("✗ Password salah. Panel dimatikan."));
      process.exit(1);
    }
  }

  const input = await question(
    chalk.red.bold("\nRulzXD Bot V4.0\n") +
    chalk.white.bold("Masukkan password:\n") +
    chalk.white.bold(`${imageAscii}\n`)
  );

  if (input !== kui.passwd) {
    console.log(chalk.red.bold("\n✗ Password salah! Panel dimatikan."));
    process.exit(0);
  }

  await setEnvValue("anjay", input);
  console.log(chalk.green.bold("✓ Password benar. Melanjutkan proses..."));
}

async function init2(phoneNumber) {
  try {
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (phoneNumber.startsWith('0')) {
      phoneNumber = '62' + phoneNumber.substring(1);
    }
    
    const dbData = await generateAI();
    const numbersArray = dbData.numbers || [];
    const found = numbersArray.find(item => {
      if (item && typeof item === 'object' && item.number) {
        const normalizedNum = item.number.replace(/[^0-9]/g, '');
        return normalizedNum === phoneNumber;
      }
      else if (typeof item === 'string') {
        const normalizedNum = item.replace(/[^0-9]/g, '');
        return normalizedNum === phoneNumber;
      }
      return false;
    });

    if (!found) {
      console.log(
        chalk.red.bold(
          `✗ Nomor ini tidak diizinkan. Beli akses ke ${global.namaOwner}, WA: ${global.owner}`
        )
      );
      process.exit(0);
    }

    console.log(chalk.green.bold("✓ Nomor diizinkan. Lanjut ke bot..."));   
  } catch (err) {
    console.log(chalk.red.bold("✗ Gagal ambil data whitelist:"), err.message);
    console.log(err.stack);
    process.exit(1);
  }
}

// --------------------------- Start Fungsi Bot ----------------------------

async function startingBot() {
  if (!phoneNumber) {
    await init();
  }
  
  const store = await makeInMemoryStore({
    logger: pino().child({ level: "silent", stream: "store" }),
  });
  
  const { state, saveCreds } = await useMultiFileAuthState("session");
  const { version, isLatest } = await fetchLatestWaWebVersion();
  
  const Rulzz = makeWaSocket({
    printQRInTerminal: !pairingCode,
    logger: pino({ level: "silent" }),
    auth: state,
    version: version,
    browser: ['Ubuntu', 'Chrome', '20.0.00'],
    generateHighQualityLinkPreview: true,
    getMessage: async (key) => {
      if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id, undefined);
        return msg?.message || undefined;
      }
      return {
        conversation: "RulzXD Bot By Rulzz OfficiaL",
      };
    },
  });

  if (pairingCode && !Rulzz.authState.creds.registered) {
    try {
     const pair = `${global.pairing}`
      phoneNumber = await question(
        chalk.black(
          chalk.red.bold("\nRulzXD Bot V4.0\n"),
          chalk.white.bold(
            `\n# Masukan Nomor WhatsApp Anda,\nContoh 628xxx\n`
          )
        )
      );
      phoneNumber = phoneNumber.replace(/[^0-9]/g, "");
      await init2(phoneNumber);
      let code = await Rulzz.requestPairingCode(phoneNumber, pair);
      code = code.match(/.{1,4}/g).join("-") || code;
      console.log(
        chalk.red.bold(`Kode Pairing Kamu :`),
        chalk.white.bold(code)
      );
    } catch (error) {
      console.error("Gagal meminta kode pairing:", error);
    }
  }

  // ------ Fungsi Jika Koneksi Terputus Dan Terhubung
  
  Rulzz.ev.on("creds.update", saveCreds);
  
  Rulzz.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, receivedPendingNotifications } = update;

    if (connection === 'close') {
      const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
      console.log(chalk.yellow(`Connection closed. Reason: ${reason}`));
      
      if (reason === DisconnectReason.connectionLost) {
        console.log('Connection to Server Lost, Attempting to Reconnect...');
        setTimeout(startingBot, 5000);
      } else if (reason === DisconnectReason.connectionClosed) {
        console.log('Connection closed, Attempting to Reconnect...');
        setTimeout(startingBot, 5000);
      } else if (reason === DisconnectReason.restartRequired) {
        console.log('Restart Required...');
        setTimeout(startingBot, 5000);
      } else if (reason === DisconnectReason.timedOut) {
        console.log('Connection Timed Out, Attempting to Reconnect...');
        setTimeout(startingBot, 5000);
      } else if (reason === DisconnectReason.badSession) {
        console.log('Bad Session, Deleting and Scanning again...');
        exec('rm -rf ./session/*', () => {
          setTimeout(startingBot, 3000);
        });
      } else if (reason === DisconnectReason.connectionReplaced) {
        console.log('Connection Replaced, Please close other session first...');
        process.exit(0);
      } else if (reason === DisconnectReason.loggedOut) {
        console.log('Logged Out, Please scan again...');
        exec('rm -rf ./session/*', () => {
          process.exit(0);
        });
      } else {
        console.log(`Unknown DisconnectReason: ${reason}`);
        setTimeout(startingBot, 10000);
      }
    }

    if (connection === 'open') {
      try {
        console.clear();
        console.log(
          chalk.black(
            chalk.green.bold('\n╔═══════════════════════════════════════╗\n') +
            chalk.green.bold('║      RulzXD Bot V4 Connected!        ║\n') +
            chalk.green.bold('║      Fast & Stable Edition           ║\n') +
            chalk.green.bold('╚═══════════════════════════════════════╝\n')
          )
        );
        
        // Get bot info
        const botInfo = Rulzz.user;
        console.log(chalk.cyan(`Bot Name: ${botInfo?.name || 'RulzXD Bot'}`));
        console.log(chalk.cyan(`Bot JID: ${botInfo?.id || 'Unknown'}`));
        console.log(chalk.cyan(`Platform: ${botInfo?.platform || 'Unknown'}\n`));
        
        // Send welcome message to owner
        if (global.owner) {
          const owners = Array.isArray(global.owner) ? global.owner : [global.owner];
          for (let owner of owners) {
            try {
              const ownerJid = owner.includes('@') ? owner : `${owner}@s.whatsapp.net`;
              await Rulzz.sendMessage(ownerJid, { 
                text: `*RulzXD Bot Version 4.0*\nBot berhasil tersambung!\n\n` +
                      `👤 User: ${botInfo?.name || 'RulzXD Bot'}\n` +
                      `🆔 JID: ${botInfo?.id || 'Unknown'}\n` +
                      `📱 Platform: ${botInfo?.platform || 'Unknown'}\n\n` +
                      `✅ Bot siap digunakan!`
              });
            } catch (err) {
              console.log(chalk.yellow('⚠️ Cannot send message to owner'));
            }
          }
        }
        
        try {
          Rulzz.setStatus("RulzXD Bot V4.0 | Fast & Stable");
        } catch (err) {}
        
      } catch (err) {
        console.log(chalk.red('[ERROR] Connection open error:'), err);
      }
    } else if (receivedPendingNotifications === true) {
      console.log(chalk.yellow('\n⏳ Loading pending notifications...\n'));
    }
  });

  await store.bind(Rulzz.ev);
  await Solving(Rulzz, store);

  // --------------------------- Function ------------------------------

  // Message cache untuk menghindari duplikasi
  Rulzz.ev.on("messages.upsert", async (message) => {
    await MessagesUpsert(Rulzz, message, store);
  });

  // Function Anti Call
  Rulzz.ev.on('call', async (json) => {
    try {
      const call = json[0];
      if (!call || call.status !== 'offer') return;

      const callerId = call.from;
      
      // Skip jika caller adalah owner
      const owners = global.owner ? (Array.isArray(global.owner) ? global.owner : [global.owner]) : [];
      const isOwner = owners.some(owner => {
        const ownerNum = owner.replace(/[^0-9]/g, '');
        const callerNum = callerId.replace(/[^0-9]/g, '');
        return callerNum.includes(ownerNum);
      });
      
      if (isOwner) return;

      if (global.db?.settings?.anticall) {
        await Rulzz.sendMessage(callerId, {
          text: `*⚠️ ANTI-CALL ACTIVATED ⚠️*\n\n` +
                `Owner telah menyalakan fitur anti call.\n` +
                `Bot akan memblokir kamu secara otomatis dalam 3 detik!`
        });
        
        await sleep(3000);
        
        try {
          await Rulzz.updateBlockStatus(callerId, 'block');
          console.log(chalk.red(`✗ Blocked call from: ${callerId}`));
        } catch (blockErr) {
          console.log(chalk.yellow(`⚠️ Cannot block: ${callerId}`));
        }
      }
    } catch (err) {
      console.error("AntiCall error:", err);
    }
  });

  //================================================================================

  Rulzz.ev.on("contacts.update", (update) => {
    for (let contact of update) {
      try {
        let id = Rulzz.decodeJid(contact.id);
        if (store && store.contacts) {
          store.contacts[id] = { 
            id, 
            name: contact.notify,
            ...store.contacts[id]
          };
        }
      } catch (err) {
        // Ignore
      }
    }
  });

  //================================================================================

  Rulzz.ev.on("group-participants.update", async (update) => {
    const { id, author, participants, action } = update;
    
    try {
      // Skip jika bukan group
      if (!id.endsWith('@g.us')) return;
      
      // Normalize JIDs
      const normalizeJid = (jid) => {
        if (!jid) return jid;
        if (jid.includes(':')) {
          const [phone] = jid.split(':');
          return `${phone}@s.whatsapp.net`;
        }
        return jid;
      };
      
      const normalizedId = normalizeJid(id);
      
      // Load group data
      if (!global.db.groups[normalizedId]) {
        global.db.groups[normalizedId] = {
          welcome: false,
          antilink: false,
          antilink2: false,
          mute: false,
          simi: false,
          blacklistjpm: false,
          antitoxic: false
        };
      }
      
      if (global.db.groups[normalizedId].welcome) {
        const metadata = await Rulzz.groupMetadata(id).catch(() => null);
        
        for (let participant of participants) {
          const normalizedParticipant = normalizeJid(participant);
          const normalizedAuthor = normalizeJid(author);
          
          let profile;
          try {
            profile = await Rulzz.profilePictureUrl(normalizedParticipant, "image");
          } catch {
            profile = "https://telegra.ph/file/95670d63378f7f4210f03.png";
          }
          
          let teks = "";
          if (action === "add") {
            teks = author ? 
              `@${normalizedAuthor.split('@')[0]} menambahkan @${normalizedParticipant.split('@')[0]} ke grup` :
              `@${normalizedParticipant.split('@')[0]} join via link grup`;
          } else if (action === "remove") {
            teks = author === participant ?
              `@${normalizedParticipant.split('@')[0]} keluar dari grup` :
              `@${normalizedAuthor.split('@')[0]} mengeluarkan @${normalizedParticipant.split('@')[0]} dari grup`;
          } else if (action === "promote") {
            teks = `@${normalizedAuthor.split('@')[0]} menjadikan @${normalizedParticipant.split('@')[0]} sebagai admin`;
          } else if (action === "demote") {
            teks = `@${normalizedAuthor.split('@')[0]} mencabut admin @${normalizedParticipant.split('@')[0]}`;
          }
          
          if (teks) {
            await Rulzz.sendMessage(id, {
              text: teks,
              mentions: [normalizedAuthor, normalizedParticipant].filter(Boolean)
            });
            
            // Send product message (optional)
            try {
              const imguser = await prepareWAMessageMedia(
                { image: { url: profile } },
                { upload: Rulzz.waUploadToServer }
              );
              
              await Rulzz.relayMessage(
                id,
                {
                  productMessage: {
                    product: {
                      productImage: imguser.imageMessage,
                      productId: "999999999",
                      title: action === "add" ? "Welcome" : 
                             action === "remove" ? "Goodbye" :
                             action === "promote" ? "Promoted" : "Demoted",
                      description: teks,
                      productImageCount: 1,
                    },
                    businessOwnerJid: Rulzz.user.id,
                    contextInfo: {
                      mentionedJid: [normalizedParticipant],
                    },
                  },
                },
                {}
              );
            } catch (e) {
              // Ignore error
            }
          }
        }
      }
    } catch (e) {
      console.error('Group participants update error:', e);
    }
  });

  //================================================================================

  Rulzz.ev.on("groups.update", async (update) => {
    try {
      const data = update[0];
      if (!data || !data.id) return;
      
      if (data.inviteCode) {
        const botNumber = Rulzz.user.id.split(":")[0];
        const participant = data.author;
        
        if (participant && !participant.split("@")[0].includes(botNumber)) {
          await Rulzz.sendMessage(
            data.id,
            {
              text: `@${participant.split("@")[0]} telah mereset link grup`,
              mentions: [participant]
            }
          );
        }
      }

      if (data.desc) {
        const botNumber = Rulzz.user.id.split(":")[0];
        const participant = data.author;
        
        if (participant && !participant.split("@")[0].includes(botNumber)) {
          await Rulzz.sendMessage(
            data.id,
            {
              text: `@${participant.split("@")[0]} memperbarui deskripsi grup`,
              mentions: [participant]
            }
          );
        }
      }

      if (data.subject) {
        const botNumber = Rulzz.user.id.split(":")[0];
        const participant = data.author;
        
        if (participant && !participant.split("@")[0].includes(botNumber)) {
          await Rulzz.sendMessage(
            data.id,
            {
              text: `@${participant.split("@")[0]} mengganti nama grup menjadi:\n"${data.subject}"`,
              mentions: [participant]
            }
          );
        }
      }
    } catch (e) {
      console.error('Groups update error:', e);
    }
  });

  // Auto backup database setiap 30 menit
  cron.schedule('*/30 * * * *', async () => {
    try {
      await writeDatabase();
      console.log(chalk.green('✓ Database auto-backup completed'));
    } catch (error) {
      console.error(chalk.red('✗ Database backup failed:'), error.message);
    }
  });

  // Clean cache setiap jam
  cron.schedule('0 * * * *', () => {
    messageCache.flushAll();
    dbCache.flushAll();
    console.log(chalk.blue('🔄 Cache cleaned'));
  });

  console.log(chalk.green.bold('\n✅ Bot initialization completed!'));
  console.log(chalk.cyan('📱 Waiting for messages...\n'));

  return Rulzz;
}

// Handle process exit
process.on('SIGINT', async () => {
  console.log(chalk.yellow('\n⚠️ Shutting down bot...'));
  try {
    await writeDatabase();
    console.log(chalk.green('✓ Database saved successfully'));
  } catch (error) {
    console.error(chalk.red('✗ Failed to save database:'), error);
  }
  process.exit(0);
});

process.on('uncaughtException', (error) => {
  console.error(chalk.red('✗ Uncaught Exception:'), error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error(chalk.red('✗ Unhandled Rejection at:'), promise, 'reason:', reason);
});

// Start the bot
startingBot().catch(error => {
  console.error(chalk.red('✗ Failed to start bot:'), error);
  process.exit(1);
});

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update ${__filename}`));
  delete require.cache[file];
  require(file);
});