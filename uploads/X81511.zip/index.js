// Impor Module
const express = require("express");
const path = require("path");
const bodyParser = require('body-parser');
const http = require("http");
const https = require("https");
const session = require('express-session');
const fileUpload = require('express-fileupload');
const { setTimeout: sleep } = require('timers/promises');
const app = express();
const PORT = process.env.PORT || 5000;
const axios = require("axios");
const fetch = require("node-fetch");
const fs = require('fs');

const uploaderFunctions = require('./function/function.js');
const adminFunctions = require('./function/admin.js');

// ========== DATA LOGIN ADMIN DI SINI SAJA ==========
const adminCredentials = {
  users: [
    {
      id: 1,
      username: "admin",
      password: "admin123",
      name: "Super Admin",
      email: "admin@rulzxd.com",
      role: "superadmin"
    },
    {
      id: 2,
      username: "moderator", 
      password: "mod123",
      name: "Content Moderator",
      email: "mod@rulzxd.com",
      role: "moderator"
    },
    {
      id: 3,
      username: "rulzz",
      password: "rulzz123",
      name: "Rulzz Developer",
      email: "rulzzofficial628@gmail.com",
      role: "admin"
    }
  ]
};

// Fungsi cek login sederhana
function checkLogin(username, password) {
  const user = adminCredentials.users.find(u => 
    u.username === username && u.password === password
  );
  
  if (user) {
    // Remove password sebelum return
    const { password: _, ...userWithoutPassword } = user;
    return {
      success: true,
      user: userWithoutPassword
    };
  }
  
  return {
    success: false,
    message: "Username atau password salah"
  };
}

// Ganti Sesuai Punya Lu
// 4 GitHub Repositories Data
const tkn1 = 'ZvyiL8y7wgiCz6NyHKQruX1a2aadw205SQst';
const tkn2 = 'ZvyiL8y7wgiCz6NyHKQruX1a2aadw205SQst';
const tkn3 = 'ZvyiL8y7wgiCz6NyHKQruX1a2aadw205SQst';
const tkn4 = 'ZvyiL8y7wgiCz6NyHKQruX1a2aadw205SQst';

const githubDatas = [
  {
    token: `ghp_${tkn1}`,
    owner: 'rulzzml',
    repo: 'files',
    branch: 'main'
  },
  {
    token: `ghp_${tkn2}`,
    owner: 'rulzzml', 
    repo: 'files-2',
    branch: 'main'
  },
  {
    token: `ghp_${tkn3}`,
    owner: 'rulzzml',
    repo: 'files-3',
    branch: 'main'
  },
  {
    token: `ghp_${tkn4}`,
    owner: 'rulzzml',
    repo: 'files-4',
    branch: 'main'
  }
];

// Diem Gausah Otak Atik
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(fileUpload());
app.use(express.static('public'));

// Middleware untuk cek session admin

app.use(session({
  secret: 'rulzxd_secret_key_2025',
  resave: true, // Ubah jadi true
  saveUninitialized: true, // Ubah jadi true
  cookie: {
    secure: false, // false untuk development
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Middleware untuk cek session admin
const checkAdminSession = (req, res, next) => {
  console.log('Session check:', req.session);
  console.log('isAdmin:', req.session.isAdmin);
  
  if (req.session.isAdmin) {
    next();
  } else {
    console.log('Not logged in, redirecting to login');
    res.redirect('/login');
  }
};

// Home page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Upload page
app.get('/upload', (req, res) => {
  res.sendFile(path.join(__dirname, 'uploader.html'));
});

// Login page
app.get('/login', (req, res) => {
  // Jika sudah login, redirect ke dashboard
  if (req.session.isAdmin) {
    console.log('Already logged in, redirecting to dashboard');
    return res.redirect('/dashboard-admin');
  }
  res.sendFile(path.join(__dirname, 'login.html'));
});

// Dashboard admin
app.get('/dashboard-admin', checkAdminSession, (req, res) => {
  console.log('Accessing dashboard for user:', req.session.adminUser);
  res.sendFile(path.join(__dirname, 'dash-admin.html'));
});

// Admin page (redirect to dashboard)
app.get('/admin', (req, res) => {
  res.redirect('/dashboard-admin');
});

// Check session endpoint - SIMPLE VERSION
app.get('/api/check-session', (req, res) => {
  console.log('Check session endpoint hit');
  console.log('Session ID:', req.sessionID);
  console.log('Session data:', req.session);
  
  if (req.session.isAdmin && req.session.adminUser) {
    console.log('User is logged in:', req.session.adminUser.username);
    res.json({
      loggedIn: true,
      user: req.session.adminUser
    });
  } else {
    console.log('User is NOT logged in');
    res.json({ 
      loggedIn: false,
      message: 'Not authenticated'
    });
  }
});

// Login endpoint - SIMPLE VERSION
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  
  console.log('Login attempt:', { username, password });
  console.log('Session ID:', req.sessionID);
  
  try {
    // Cari user
    const user = adminCredentials.users.find(u => 
      u.username === username && u.password === password
    );
    
    if (user) {
      // Remove password sebelum simpan di session
      const { password: _, ...userWithoutPassword } = user;
      
      // Set session
      req.session.isAdmin = true;
      req.session.adminUser = userWithoutPassword;
      req.session.userId = user.id;
      
      console.log('Login successful for user:', user.username);
      console.log('Session after login:', req.session);
      
      // Save session
      req.session.save((err) => {
        if (err) {
          console.error('Session save error:', err);
          return res.status(500).json({
            success: false,
            message: 'Session error'
          });
        }
        
        res.json({
          success: true,
          message: 'Login successful',
          user: userWithoutPassword
        });
      });
      
    } else {
      console.log('Login failed: invalid credentials');
      res.json({
        success: false,
        message: 'Username atau password salah'
      });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// Logout endpoint
app.get('/logout', (req, res) => {
  console.log('Logout for user:', req.session.adminUser?.username);
  
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
    }
    res.redirect('/login');
  });
});

// ========== ENDPOINT ADMIN (PAKE FUNGSI DARI admin.js) ==========
app.get('/api/admin/me', async (req, res) => {
  if (!req.session.isAdmin) {
    return res.status(401).json({
      status: false,
      message: 'Unauthorized'
    });
  }
  
  try {
    res.json({
      success: true,
      data: req.session.adminUser
    });
  } catch (error) {
    console.error('Get admin info error:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});

app.get('/api/admin/stats', async (req, res) => {
  if (!req.session.isAdmin) {
    return res.status(401).json({
      status: false,
      message: 'Unauthorized'
    });
  }
  
  try {
    // PAKE FUNGSI DARI admin.js
    const result = adminFunctions.getAdminStats();
    res.json(result);
  } catch (error) {
    console.error('Get admin stats error:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});

app.get('/api/admin/files', async (req, res) => {
  if (!req.session.isAdmin) {
    return res.status(401).json({
      status: false,
      message: 'Unauthorized'
    });
  }
  
  try {
    // PAKE FUNGSI DARI admin.js
    const result = adminFunctions.getAllFilesWithStatus();
    res.json(result);
  } catch (error) {
    console.error('Get admin files error:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});

app.post('/api/admin/files/update', async (req, res) => {
  if (!req.session.isAdmin) {
    return res.status(401).json({
      status: false,
      message: 'Unauthorized'
    });
  }
  
  const { fileId, repoIndex, newName, status, notes } = req.body;
  
  try {
    // PAKE FUNGSI DARI admin.js
    const result = adminFunctions.updateFile(fileId, repoIndex, {
      newName,
      status,
      notes
    });
    res.json(result);
  } catch (error) {
    console.error('Update file error:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});

app.post('/api/admin/files/delete', async (req, res) => {
  if (!req.session.isAdmin) {
    return res.status(401).json({
      status: false,
      message: 'Unauthorized'
    });
  }
  
  const { fileId, repoIndex } = req.body;
  
  try {
    // PAKE FUNGSI DARI admin.js
    const result = adminFunctions.deleteFile(fileId, repoIndex);
    res.json(result);
  } catch (error) {
    console.error('Delete file error:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});

app.post('/api/admin/repos/update', async (req, res) => {
  if (!req.session.isAdmin) {
    return res.status(401).json({
      status: false,
      message: 'Unauthorized'
    });
  }
  
  try {
    // PAKE FUNGSI DARI admin.js
    const result = adminFunctions.updateRepositories();
    res.json(result);
  } catch (error) {
    console.error('Update repos error:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});

app.get('/api/admin/real-stats', checkAdminSession, async (req, res) => {
  try {
    console.log('Fetching real stats from GitHub...');
    
    const allFiles = await getAllRealFiles();
    const totalFiles = allFiles.length;
    
    // Calculate total size
    const totalSizeBytes = allFiles.reduce((sum, file) => sum + (file.size || 0), 0);
    const totalSizeMB = (totalSizeBytes / (1024 * 1024)).toFixed(2);
    
    // Get repo stats
    const repoStats = [];
    for (let i = 0; i < githubDatas.length; i++) {
      try {
        const stats = await getRealRepoStats(i);
        if (stats) repoStats.push(stats);
      } catch (error) {
        console.error(`Error fetching repo ${i} stats:`, error.message);
        repoStats.push({
          id: i,
          name: `Repo ${i + 1}`,
          files: 0,
          size: '0 MB',
          lastUpdated: '-',
          status: 'error',
          branch: 'main',
          stars: 0,
          watchers: 0
        });
      }
    }
    
    // Count files by type
    const imageFiles = allFiles.filter(f => f.type === 'image').length;
    const videoFiles = allFiles.filter(f => f.type === 'video').length;
    const audioFiles = allFiles.filter(f => f.type === 'audio').length;
    const docFiles = allFiles.filter(f => f.type === 'document').length;
    
    const responseData = {
      success: true,
      data: {
        totalFiles,
        totalSize: `${totalSizeMB} MB`,
        totalSizeBytes,
        reposUsed: `${githubDatas.length}/4`,
        imageFiles,
        videoFiles,
        audioFiles,
        docFiles,
        otherFiles: totalFiles - (imageFiles + videoFiles + audioFiles + docFiles),
        repoStats
      }
    };
    
    console.log('Real stats response:', responseData);
    res.json(responseData);
    
  } catch (error) {
    console.error('Error getting real stats:', error);
    // Return fallback data if GitHub API fails
    const fallbackData = {
      success: true,
      data: {
        totalFiles: 0,
        totalSize: '0 MB',
        totalSizeBytes: 0,
        reposUsed: `${githubDatas.length}/4`,
        imageFiles: 0,
        videoFiles: 0,
        audioFiles: 0,
        docFiles: 0,
        otherFiles: 0,
        repoStats: githubDatas.map((repo, i) => ({
          id: i,
          name: `Repo ${i + 1}`,
          files: 0,
          size: '0 MB',
          lastUpdated: '-',
          status: 'error',
          branch: 'main',
          stars: 0,
          watchers: 0
        }))
      }
    };
    res.json(fallbackData);
  }
});

// Get all real files dari semua repos
app.get('/api/admin/real-files', checkAdminSession, async (req, res) => {
  try {
    console.log('Fetching real files from GitHub...');
    
    const allFiles = await getAllRealFiles();
    
    // Apply sorting
    const { sort = 'date_desc', page = 1, limit = 50, search = '' } = req.query;
    
    let filteredFiles = allFiles;
    
    // Apply search filter
    if (search) {
      filteredFiles = filteredFiles.filter(file => 
        file.file_name.toLowerCase().includes(search.toLowerCase()) ||
        (file.original_name || '').toLowerCase().includes(search.toLowerCase())
      );
    }
    
    // Apply sorting
    switch(sort) {
      case 'date_desc':
        filteredFiles.sort((a, b) => new Date(b.uploaded_at) - new Date(a.uploaded_at));
        break;
      case 'date_asc':
        filteredFiles.sort((a, b) => new Date(a.uploaded_at) - new Date(b.uploaded_at));
        break;
      case 'size_desc':
        filteredFiles.sort((a, b) => b.size - a.size);
        break;
      case 'size_asc':
        filteredFiles.sort((a, b) => a.size - b.size);
        break;
      case 'name_asc':
        filteredFiles.sort((a, b) => (a.file_name || '').localeCompare(b.file_name || ''));
        break;
      case 'name_desc':
        filteredFiles.sort((a, b) => (b.file_name || '').localeCompare(a.file_name || ''));
        break;
      case 'repo':
        filteredFiles.sort((a, b) => a.repo_index - b.repo_index);
        break;
    }
    
    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedFiles = filteredFiles.slice(startIndex, endIndex);
    
    const responseData = {
      success: true,
      data: paginatedFiles,
      total: filteredFiles.length,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(filteredFiles.length / limit),
      sort: sort
    };
    
    console.log(`Returning ${paginatedFiles.length} files (total: ${filteredFiles.length})`);
    res.json(responseData);
    
  } catch (error) {
    console.error('Error getting real files:', error);
    // Return empty array if GitHub API fails
    const fallbackData = {
      success: true,
      data: [],
      total: 0,
      page: 1,
      limit: 50,
      totalPages: 0,
      sort: 'date_desc'
    };
    res.json(fallbackData);
  }
});

// Get specific repo details
app.get('/api/admin/repo/:repoIndex', checkAdminSession, async (req, res) => {
  try {
    const repoIndex = parseInt(req.params.repoIndex);
    if (isNaN(repoIndex) || repoIndex < 0 || repoIndex >= githubDatas.length) {
      return res.status(400).json({
        success: false,
        message: 'Invalid repository index'
      });
    }
    
    const repoStats = await getRealRepoStats(repoIndex);
    
    if (!repoStats) {
      return res.status(404).json({
        success: false,
        message: 'Repository not found'
      });
    }
    
    res.json({
      success: true,
      data: repoStats
    });
  } catch (error) {
    console.error('Error getting repo details:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching repository data'
    });
  }
});

// ========== FUNGSI HELPER UNTUK GITHUB API ==========
async function getRealRepoStats(repoIndex) {
  try {
    const repo = githubDatas[repoIndex];
    if (!repo) {
      console.error(`Repo ${repoIndex} not found in config`);
      return null;
    }

    console.log(`Fetching stats for repo ${repoIndex}: ${repo.owner}/${repo.repo}`);
    
    // Get repo info
    const repoResponse = await axios.get(
      `https://api.github.com/repos/${repo.owner}/${repo.repo}`,
      {
        headers: {
          'Authorization': `token ${repo.token}`,
          'Accept': 'application/vnd.github.v3+json',
          'User-Agent': 'RulzXD-API'
        },
        timeout: 10000 // 10 second timeout
      }
    ).catch(error => {
      console.error(`GitHub API error for repo ${repoIndex}:`, error.message);
      throw error;
    });

    const repoData = repoResponse.data;
    
    // Try to get files count
    let filesCount = 0;
    try {
      const filesResponse = await axios.get(
        `https://api.github.com/repos/${repo.owner}/${repo.repo}/git/trees/${repo.branch}?recursive=1`,
        {
          headers: {
            'Authorization': `token ${repo.token}`,
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'RulzXD-API'
          },
          timeout: 10000
        }
      );
      
      if (filesResponse.data && filesResponse.data.tree) {
        filesCount = filesResponse.data.tree.length;
      }
    } catch (treeError) {
      console.error(`Error getting tree for repo ${repoIndex}:`, treeError.message);
      // Use default if tree API fails
      filesCount = 0;
    }
    
    // Calculate size in MB (GitHub returns size in KB)
    const sizeMB = repoData.size ? (repoData.size / 1024).toFixed(2) : '0';
    
    return {
      id: repoIndex,
      name: `${repo.owner}/${repo.repo}`,
      files: filesCount,
      size: `${sizeMB} MB`,
      lastUpdated: new Date(repoData.updated_at || repoData.created_at).toLocaleDateString('id-ID'),
      status: 'active',
      branch: repo.branch,
      stars: repoData.stargazers_count || 0,
      watchers: repoData.watchers_count || 0,
      description: repoData.description || ''
    };
  } catch (error) {
    console.error(`Error fetching repo ${repoIndex} stats:`, error.message);
    
    // Return error status
    return {
      id: repoIndex,
      name: `Repo ${repoIndex + 1}`,
      files: 0,
      size: '0 MB',
      lastUpdated: '-',
      status: 'error',
      branch: 'main',
      stars: 0,
      watchers: 0,
      description: `Error: ${error.message}`
    };
  }
}

async function getAllRealFiles() {
  const allFiles = [];
  console.log('Fetching files from all repositories...');
  
  for (let i = 0; i < githubDatas.length; i++) {
    try {
      const repo = githubDatas[i];
      console.log(`Fetching files from repo ${i}: ${repo.owner}/${repo.repo}`);
      
      const response = await axios.get(
        `https://api.github.com/repos/${repo.owner}/${repo.repo}/git/trees/${repo.branch}?recursive=1`,
        {
          headers: {
            'Authorization': `token ${repo.token}`,
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'RulzXD-API'
          },
          timeout: 15000 // 15 second timeout
        }
      );

      const files = response.data.tree || [];
      console.log(`Found ${files.length} items in repo ${i}`);
      
      files.forEach(file => {
        if (file.type === 'blob' && !file.path.includes('.gitignore')) {
          const fileName = file.path.split('/').pop();
          const fileExt = fileName.split('.').pop().toLowerCase();
          const fileType = getFileType(fileExt);
          
          allFiles.push({
            _id: file.sha,
            file_name: fileName,
            original_name: file.path,
            repo_index: i,
            size: file.size || 0,
            type: fileType,
            path: file.path,
            sha: file.sha,
            url: file.url,
            uploaded_at: new Date().toISOString(),
            last_accessed: new Date().toISOString(),
            status: 'active',
            views: Math.floor(Math.random() * 1000)
          });
        }
      });
    } catch (error) {
      console.error(`Error fetching files from repo ${i}:`, error.message);
    }
  }
  
  console.log(`Total files found: ${allFiles.length}`);
  return allFiles;
}

function getFileType(extension) {
  const imageExt = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
  const videoExt = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv', 'webm'];
  const audioExt = ['mp3', 'wav', 'ogg', 'flac', 'm4a'];
  const docExt = ['pdf', 'doc', 'docx', 'txt', 'rtf', 'xls', 'xlsx', 'ppt', 'pptx'];
  
  if (imageExt.includes(extension)) return 'image';
  if (videoExt.includes(extension)) return 'video';
  if (audioExt.includes(extension)) return 'audio';
  if (docExt.includes(extension)) return 'document';
  
  return 'other';
}

app.get('/api/admin/real-stats', checkAdminSession, async (req, res) => {
  try {
    let totalFiles = 0;
    let totalSizeBytes = 0;
    const repoStats = [];
    
    for (let i = 0; i < githubDatas.length; i++) {
      const stats = await getRealRepoStats(i);
      if (stats) {
        repoStats.push(stats);
        totalFiles += stats.files;
        const sizeMB = parseFloat(stats.size.replace(' MB', ''));
        totalSizeBytes += sizeMB * 1024 * 1024;
      }
    }
    
    const totalSizeMB = (totalSizeBytes / (1024 * 1024)).toFixed(2);
    
    res.json({
      success: true,
      data: {
        totalFiles,
        totalSize: `${totalSizeMB} MB`,
        reposUsed: `${githubDatas.length}/4`,
        repoStats
      }
    });
  } catch (error) {
    console.error('Error getting real stats:', error);
    res.json({
      success: true,
      data: {
        totalFiles: 0,
        totalSize: '0 MB',
        reposUsed: `${githubDatas.length}/4`,
        repoStats: githubDatas.map((repo, i) => ({
          id: i,
          name: `Repo ${i + 1}`,
          files: 0,
          size: '0 MB',
          lastUpdated: '-',
          status: 'error',
          branch: 'main',
          stars: 0,
          watchers: 0
        }))
      }
    });
  }
});

app.get('/api/admin/real-files', checkAdminSession, async (req, res) => {
  try {
    const { repo: repoParam, page = 1, limit = 20 } = req.query;
    let selectedRepo = parseInt(repoParam);
    
    if (isNaN(selectedRepo) || selectedRepo < 0 || selectedRepo >= githubDatas.length) {
      selectedRepo = 0;
    }
    
    const allFiles = await getFilesFromRepo(selectedRepo);
    
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedFiles = allFiles.slice(startIndex, endIndex);
    
    res.json({
      success: true,
      data: paginatedFiles,
      total: allFiles.length,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(allFiles.length / limit),
      selectedRepo: selectedRepo
    });
  } catch (error) {
    console.error('Error getting real files:', error);
    res.json({
      success: true,
      data: [],
      total: 0,
      page: 1,
      limit: 20,
      totalPages: 0,
      selectedRepo: 0
    });
  }
});

app.post('/api/admin/delete-file', checkAdminSession, async (req, res) => {
    try {
        const { repoIndex, filePath, sha } = req.body;
        
        console.log('DELETE FILE REQUEST:', req.body);
        
        // Validate required parameters
        if (repoIndex === undefined || !filePath || !sha) {
            console.error('Missing parameters:', { repoIndex, filePath, sha });
            return res.status(400).json({
                success: false,
                message: 'Missing required parameters: repoIndex, filePath, and sha are required'
            });
        }
        
        const repoIdx = parseInt(repoIndex);
        if (isNaN(repoIdx) || repoIdx < 0 || repoIdx >= githubDatas.length) {
            console.error('Invalid repo index:', repoIdx);
            return res.status(400).json({
                success: false,
                message: `Invalid repository index: ${repoIndex}. Must be between 0 and ${githubDatas.length - 1}`
            });
        }
        
        console.log(`Deleting file from repo ${repoIdx}: ${filePath}`);
        
        const repo = githubDatas[repoIdx];
        
        try {
            // First, get the file to verify it exists
            const getFileResponse = await axios.get(
                `https://api.github.com/repos/${repo.owner}/${repo.repo}/contents/${encodeURIComponent(filePath)}`,
                {
                    headers: {
                        'Authorization': `token ${repo.token}`,
                        'Accept': 'application/vnd.github.v3+json',
                        'User-Agent': 'RulzXD-API'
                    }
                }
            );
            
            const fileData = getFileResponse.data;
            
            // Delete the file
            const deleteResponse = await axios.delete(
                `https://api.github.com/repos/${repo.owner}/${repo.repo}/contents/${encodeURIComponent(filePath)}`,
                {
                    headers: {
                        'Authorization': `token ${repo.token}`,
                        'Accept': 'application/vnd.github.v3+json',
                        'User-Agent': 'RulzXD-API'
                    },
                    data: {
                        message: `Deleted file: ${filePath}`,
                        sha: sha,
                        branch: repo.branch
                    }
                }
            );
            
            console.log('Delete successful:', deleteResponse.data);
            
            res.json({
                success: true,
                message: 'File deleted successfully',
                data: deleteResponse.data
            });
            
        } catch (githubError) {
            console.error('GitHub API error:', githubError.response?.data || githubError.message);
            
            let errorMessage = 'Failed to delete file from GitHub';
            if (githubError.response) {
                if (githubError.response.status === 404) {
                    errorMessage = 'File not found on GitHub';
                } else if (githubError.response.status === 403) {
                    errorMessage = 'Permission denied - check GitHub token';
                } else {
                    errorMessage = `GitHub API error: ${githubError.response.status} - ${JSON.stringify(githubError.response.data)}`;
                }
            }
            
            res.status(400).json({
                success: false,
                message: errorMessage
            });
        }
        
    } catch (error) {
        console.error('Error in delete-file endpoint:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error: ' + error.message
        });
    }
});

// Helper function untuk delete file dari repo
async function deleteFileFromRepo(repoIndex, filePath, sha) {
    const repo = githubDatas[repoIndex];
    
    try {
        const response = await axios.delete(
            `https://api.github.com/repos/${repo.owner}/${repo.repo}/contents/${encodeURIComponent(filePath)}`,
            {
                headers: {
                    'Authorization': `token ${repo.token}`,
                    'Accept': 'application/vnd.github.v3+json',
                    'User-Agent': 'RulzXD-API'
                },
                data: {
                    message: `Deleted file: ${filePath}`,
                    sha: sha,
                    branch: repo.branch
                }
            }
        );
        
        return {
            success: true,
            data: response.data
        };
    } catch (error) {
        console.error(`Error deleting file from repo ${repoIndex}:`, error.response?.data || error.message);
        return {
            success: false,
            message: error.response?.data?.message || error.message
        };
    }
}

// ========== EXISTING ENDPOINTS ==========
app.post('/uploadfile', async (req, res) => {
  console.log('=== UPLOAD REQUEST ===');
  
  if (!req.files || Object.keys(req.files).length === 0) {
    console.log('ERROR: No files uploaded');
    return res.status(400).send(uploaderFunctions.createErrorHtml('No files were uploaded.'));
  }

  const uploadedFile = req.files.file;
  const customName = req.body.filename ? req.body.filename.trim() : null;
  
  console.log(`File: ${uploadedFile.name}, Size: ${uploadedFile.size}, Custom name: ${customName}`);

  try {
    console.log('Uploading to GitHub with load balancing...');
    const uploadResult = await uploaderFunctions.uploadFileToGithub(uploadedFile, customName, githubDatas);
    
    console.log('Upload result:', uploadResult.success ? 'SUCCESS' : 'FAILED');
    
    if (!uploadResult.success) {
      console.log('Upload failed:', uploadResult.error);
      return res.status(500).send(uploaderFunctions.createErrorHtml(uploadResult.error, uploadResult.code));
    }

    const publicUrl = uploaderFunctions.createPublicUrl(req, uploadResult.data.file_name, uploadResult.data.repo_index);
    console.log('Public URL:', publicUrl);
    console.log('Repository:', uploadResult.data.repo_index + 1, uploadResult.data.repo_name);
    
    res.send(uploaderFunctions.createSuccessHtml(
      publicUrl, 
      uploadResult.data.file_name, 
      uploadResult.data.size,
      {
        index: uploadResult.data.repo_index,
        name: uploadResult.data.repo_name
      }
    ));
    
  } catch (error) {
    console.error('Upload error:', error.message);
    res.status(500).send(uploaderFunctions.createErrorHtml('Internal server error: ' + error.message));
  }
});

app.get('/api/files', async (req, res) => {
  const { sort = 'date_desc', page = 1, limit = 20 } = req.query;
  
  try {
    const filesResult = await uploaderFunctions.getAllFilesFromGithub(githubDatas);
    
    if (!filesResult.success) {
      return res.status(500).json({
        status: false,
        message: filesResult.error || 'Failed to fetch files'
      });
    }
    
    let sortedFiles = [...filesResult.data];
    
    // Apply sorting
    switch(sort) {
      case 'date_desc':
        sortedFiles.sort((a, b) => b.sort_date - a.sort_date);
        break;
      case 'date_asc':
        sortedFiles.sort((a, b) => a.sort_date - b.sort_date);
        break;
      case 'size_desc':
        sortedFiles.sort((a, b) => b.size - a.size);
        break;
      case 'size_asc':
        sortedFiles.sort((a, b) => a.size - b.size);
        break;
      case 'name_asc':
        sortedFiles.sort((a, b) => a.custom_name.localeCompare(b.custom_name));
        break;
      case 'name_desc':
        sortedFiles.sort((a, b) => b.custom_name.localeCompare(a.custom_name));
        break;
      case 'repo':
        sortedFiles.sort((a, b) => a.repo_index - b.repo_index);
        break;
    }
    
    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedFiles = sortedFiles.slice(startIndex, endIndex);
    
    res.json({
      status: true,
      data: paginatedFiles,
      total: filesResult.count,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(filesResult.count / limit),
      sort: sort
    });
    
  } catch (error) {
    console.error('Error fetching files:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});

app.get('/files/:repoIndex/:fileName', async (req, res) => {
  const { repoIndex, fileName } = req.params;
  
  if (!fileName) {
    return res.status(400).send('Missing file name');
  }

  try {
    const repoIdx = parseInt(repoIndex);
    if (isNaN(repoIdx) || repoIdx < 0 || repoIdx >= githubDatas.length) {
      return res.status(400).send('Invalid repository index');
    }
    
    const fileResult = await uploaderFunctions.getFileFromGithub(fileName, repoIdx, githubDatas);
    
    if (!fileResult.success) {
      return res.status(404).send('File not found');
    }

    res.set('Content-Type', fileResult.contentType);
    res.set('Cache-Control', 'public, max-age=3600');
    res.send(fileResult.data);
    
  } catch (error) {
    console.error('Error serving file:', error);
    res.status(500).send('Error fetching file');
  }
});

// Public stats endpoint
app.get('/api/stats', async (req, res) => {
  try {
    // PAKE FUNGSI DARI admin.js
    const stats = adminFunctions.getAdminStats();
    res.json(stats);
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});

// Jangan edit

app.use((err, req, res, next) => {
  console.log(err.stack);
  res.status(500).send("Error");
});

app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, '404.html'));
});

app.listen(PORT, () => {
  console.log(`Server Telah Berjalan > http://localhost:${PORT}`)
  console.log('===============================')
  console.log('DATA LOGIN YANG BISA DIPAKAI:')
  console.log('1. admin / admin123')
  console.log('2. moderator / mod123')
  console.log('3. rulzz / rulzz123')
  console.log('===============================')
});