const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// Database in-memory untuk file status (ganti dengan database sesungguhnya di production)
const fileStatusDB = new Map();

const JWT_SECRET = 'rulzxd_admin_secret_key_2025_change_this_in_production';

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

function getAdminInfo(token) {
  const decoded = verifyToken(token);
  
  if (!decoded) {
    return {
      success: false,
      message: 'Invalid token'
    };
  }
  
  // Note: User data sekarang dari index.js, jadi cuma return data dari token
  return {
    success: true,
    data: {
      id: decoded.id,
      username: decoded.username,
      name: decoded.name,
      role: decoded.role
    }
  };
}

function getAdminStats() {
  const totalFiles = fileStatusDB.size;
  const activeFiles = Array.from(fileStatusDB.values()).filter(f => f.status === 'active').length;
  const takedownFiles = Array.from(fileStatusDB.values()).filter(f => f.status === 'takedown').length;
  const warningFiles = Array.from(fileStatusDB.values()).filter(f => f.status === 'warning').length;
  
  return {
    success: true,
    data: {
      totalFiles: totalFiles || 1247,
      totalSize: '1.2 GB',
      activeFiles: activeFiles || 1150,
      takedownFiles: takedownFiles || 97,
      warningFiles: warningFiles || 0,
      reposUsed: '4/4',
      apiCalls: 8421,
      activeUsers: 156,
      storageUsed: '65%',
      todayUploads: 42
    }
  };
}

function getAllFilesWithStatus() {
  const files = Array.from(fileStatusDB.values());
  
  // If no files in status DB, return mock data
  if (files.length === 0) {
    const mockFiles = [
      {
        _id: '1',
        original_name: 'nature_photo.jpg',
        custom_name: 'nature.jpg',
        file_name: 'abc123.jpg',
        size: 1024000,
        type: 'image/jpeg',
        uploaded_at: new Date(Date.now() - 86400000).toISOString(),
        repo_index: 0,
        status: 'active',
        notes: 'Nature photography',
        views: 125,
        last_accessed: new Date().toISOString()
      },
      {
        _id: '2',
        original_name: 'document.pdf',
        custom_name: 'report_q4.pdf',
        file_name: 'def456.pdf',
        size: 5120000,
        type: 'application/pdf',
        uploaded_at: new Date(Date.now() - 172800000).toISOString(),
        repo_index: 1,
        status: 'active',
        notes: 'Quarterly report',
        views: 89,
        last_accessed: new Date(Date.now() - 3600000).toISOString()
      },
      {
        _id: '3',
        original_name: 'video.mp4',
        custom_name: 'tutorial.mp4',
        file_name: 'ghi789.mp4',
        size: 15360000,
        type: 'video/mp4',
        uploaded_at: new Date(Date.now() - 259200000).toISOString(),
        repo_index: 2,
        status: 'warning',
        notes: 'Content review needed',
        views: 256,
        last_accessed: new Date(Date.now() - 7200000).toISOString()
      },
      {
        _id: '4',
        original_name: 'music.mp3',
        custom_name: 'song.mp3',
        file_name: 'jkl012.mp3',
        size: 8192000,
        type: 'audio/mpeg',
        uploaded_at: new Date(Date.now() - 345600000).toISOString(),
        repo_index: 3,
        status: 'takedown',
        notes: 'Copyright issue',
        views: 342,
        last_accessed: new Date(Date.now() - 86400000).toISOString()
      },
      {
        _id: '5',
        original_name: 'archive.zip',
        custom_name: 'project_files.zip',
        file_name: 'mno345.zip',
        size: 25600000,
        type: 'application/zip',
        uploaded_at: new Date(Date.now() - 432000000).toISOString(),
        repo_index: 0,
        status: 'active',
        notes: 'Project backup',
        views: 67,
        last_accessed: new Date(Date.now() - 28800000).toISOString()
      }
    ];
    
    // Add mock files to status DB
    mockFiles.forEach(file => {
      fileStatusDB.set(file._id, file);
    });
    
    return {
      success: true,
      data: mockFiles,
      total: mockFiles.length
    };
  }
  
  return {
    success: true,
    data: files,
    total: files.length
  };
}

function updateFile(fileId, repoIndex, updates) {
  const key = `${repoIndex}_${fileId}`;
  const existing = fileStatusDB.get(key);
  
  if (!existing) {
    // Create new entry if doesn't exist
    fileStatusDB.set(key, {
      _id: key,
      file_name: fileId,
      repo_index: repoIndex,
      ...updates,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });
  } else {
    // Update existing entry
    Object.assign(existing, updates, { updated_at: new Date().toISOString() });
    fileStatusDB.set(key, existing);
  }
  
  console.log(`Updated file ${fileId} in repo ${repoIndex}:`, updates);
  
  return {
    success: true,
    message: 'File updated successfully'
  };
}

function deleteFile(fileId, repoIndex) {
  const key = `${repoIndex}_${fileId}`;
  const deleted = fileStatusDB.delete(key);
  
  console.log(`Deleted file ${fileId} from repo ${repoIndex}. Success: ${deleted}`);
  
  return {
    success: true,
    message: 'File deleted successfully'
  };
}

function updateRepositories() {
  console.log('Updating repositories status...');
  
  // Simulate repository status check
  const repoStatus = [
    { id: 0, name: 'Repo 1', used: '45%', files: 312, lastSync: new Date().toISOString() },
    { id: 1, name: 'Repo 2', used: '38%', files: 265, lastSync: new Date().toISOString() },
    { id: 2, name: 'Repo 3', used: '52%', files: 348, lastSync: new Date().toISOString() },
    { id: 3, name: 'Repo 4', used: '29%', files: 198, lastSync: new Date().toISOString() }
  ];
  
  return {
    success: true,
    message: 'Repositories updated successfully',
    data: repoStatus
  };
}

module.exports = {
  getAdminInfo,
  getAdminStats,
  getAllFilesWithStatus,
  updateFile,
  deleteFile,
  updateRepositories,
  verifyToken
};