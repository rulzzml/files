/*
  © Credit By Rulzz OfficiaL
  Contact : https://wa.me/6285133226206
  Youtube : https://youtube.com/@bangrulzz44
  Website : https://www.rulzzofficial.my.id
  Telegram : https://t.me/rulzzhosting
  Developer : https://wa.me/6285133226206
  ❗ Hargai developer dengan cara tidak menghapus credit ini.
*/

require('../settings');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const mongoose = require('mongoose');
let DataBase;

if (/mongo/.test(global.tempatDB)) {
  DataBase = class MongoDB {
    constructor(url, options = { useNewUrlParser: true, useUnifiedTopology: true }) {
      this.url = url;
      this.data = {};
      this._model = {};
      this.options = options;
    }

    read = async () => {
      mongoose.connect(this.url, { ...this.options });
      this.connection = mongoose.connection;

      try {
        const schema = new mongoose.Schema({
          data: {
            type: Object,
            required: true,
            default: {},
          }
        });
        this._model = mongoose.model('data', schema);
      } catch {
        this._model = mongoose.model('data');
      }

      this.data = await this._model.findOne({});
      if (!this.data) {
        new this._model({ data: {} }).save();
        this.data = await this._model.findOne({});
      }

      return this?.data?.data || this?.data;
    };

    write = async (data) => {
      if (this.data && !this.data.data) return (new this._model({ data })).save();
      this._model.findById(this.data._id, (err, docs) => {
        if (!err) {
          if (!docs.data) docs.data = {};
          docs.data = data;
          return docs.save();
        }
      });
    };
  };
} else if (/json/.test(global.tempatDB)) {
  DataBase = class JSONDB {
    data = {};
    file = path.join(process.cwd(), 'library/database', global.tempatDB);

    read = async () => {
      if (fs.existsSync(this.file)) {
        this.data = JSON.parse(fs.readFileSync(this.file));
      } else {
        fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2));
      }
      return this.data;
    };

    write = async (data) => {
      this.data = data || global.db;

      const seen = new WeakSet();
      const safeData = JSON.stringify(this.data, (key, value) => {
        if (typeof value === 'object' && value !== null) {
          if (seen.has(value)) return '[Circular]';
          seen.add(value);
        }
        if (typeof value === 'function') return '[Function]';
        return value;
      }, 2);

      const dirname = path.dirname(this.file);
      if (!fs.existsSync(dirname)) fs.mkdirSync(dirname, { recursive: true });

      fs.writeFileSync(this.file, safeData);
      return this.file;
    };
  };
}

module.exports = DataBase;

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update ${__filename}`));
  delete require.cache[file];
  require(file);
});