/* 

  © Credit By Rulzz OfficiaL
   Contact : https://wa.me/6285133226206
   Youtube : https://youtube.com/@bangrulzz44
   Website : https://www.rulzzofficial.my.id
   Telegram : https://t.me/rulzzhosting
    
  Developer : https://wa.me/6285133226206
  
  ❗ Hargai developer dengan cara tidak menghapus credit ini.

*/

const fs = require("fs");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const dataDir = path.join(__dirname, "data");
const dbPath = path.join(dataDir, "database.nv");

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error("❌ Gagal buka DB:", err.message);
    process.exit(1);
  }
});

db.run(`
  CREATE TABLE IF NOT EXISTS env (
    key TEXT PRIMARY KEY,
    value TEXT
  )
`);

function getEnvValue(key) {
  return new Promise((resolve, reject) => {
    db.get("SELECT value FROM env WHERE key = ?", [key], (err, row) => {
      if (err) return reject(err);
      resolve(row ? row.value : null);
    });
  });
}

function setEnvValue(key, value) {
  return new Promise((resolve, reject) => {
    db.run(
      `
      INSERT INTO env (key, value)
      VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
      `,
      [key, value],
      (err) => {
        if (err) return reject(err);
        resolve();
      }
    );
  });
}

module.exports = {
  getEnvValue,
  setEnvValue,
};