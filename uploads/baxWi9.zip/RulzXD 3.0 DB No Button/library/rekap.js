/* 

  © Credit By Rulzz OfficiaL
   Contact : https://wa.me/6285133226206
   Youtube : https://youtube.com/@bangrulzz44
   Website : https://www.rulzzofficial.my.id
   Telegram : https://t.me/rulzzhosting
    
  Developer : https://wa.me/6285133226206
  
  ❗ Hargai developer dengan cara tidak menghapus credit ini.

*/

const path = require("path");
const fs = require("fs");
const sqlite3 = require('sqlite3').verbose();
const dataDir = path.join(__dirname, "database");
const dbPath = path.join(dataDir, "rekaptransaksi.env");

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const rekap = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error("❌ Gagal buka Data Rekap:", err.message);
    process.exit(1);
  }
});

rekap.serialize(() => {
  rekap.run(`
    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      type TEXT,
      amount INTEGER,
      date INTEGER
    )
  `);
});

module.exports = rekap;