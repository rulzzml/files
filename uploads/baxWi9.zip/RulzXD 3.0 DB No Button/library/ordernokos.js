/* 

  © Credit By Rulzz OfficiaL
   Contact : https://wa.me/6285133226206
   Youtube : https://youtube.com/@bangrulzz44
   Website : https://www.rulzzofficial.my.id
   Telegram : https://t.me/rulzzhosting
    
  Developer : https://wa.me/6285133226206
  
  ❗ Hargai developer dengan cara tidak menghapus credit ini.

*/

require('../settings');
const axios = require("axios");
const virtu = require("./virtusim");

const EXPIRATION_TIME = 570000; // 9 menit 30 detik
const CHECK_INTERVAL = 15000;   // 15 detik

// Mapping list negara
const countryList = {
  1: { name: "Indonesia", virtuCode: "716", price: 5100 },
  2: { name: "Korea Selatan", virtuCode: "712", price: 8000 },
  3: { name: "USA", virtuCode: "710", price: 10000 },
  4: { name: "Jepang", virtuCode: "708", price: 9000 },
  5: { name: "Kamboja", virtuCode: "709", price: 7000 },
  6: { name: "Islandia", virtuCode: "707", price: 12000 }
};

// Fungsi aman panggil API
async function safeApiCall(callback) {
  try {
    return await callback();
  } catch (error) {
    console.error("API Error:", error.message || error);
    return null;
  }
}

// Set kedaluwarsa OTP
function setOrderOtpExpiration(user, Rulzz) {
  const timeoutId = setTimeout(async () => {
    const status = await safeApiCall(() =>
      virtu.ChangeStatusNumber(user.order_otp_id, "2")
    );
    if (status && user.order_otp) {
      user.order_otp = false;
      user.order_otp_id = null;
      delete user.order_otp_number;
      delete user.order_otp_exp;

      Rulzz.sendMessage(user.saweria.chat, { text: "Order Expired!" });
    }
  }, EXPIRATION_TIME);

  user.order_otp_exp = Date.now() + EXPIRATION_TIME;
}

// Cek status OTP
async function checkOtpStatus(user, Rulzz) {
  const status = await safeApiCall(() => virtu.CheckAllActiveNumber());
  if (status?.status === "false") return;
  const find = status.data.find((x) => x.id == user.order_otp_id);
  if (find?.status === "Otp Diterima") {
    Rulzz.sendMessage(user.saweria.chat, {
      text: `✅ *OTP Diterima!*\n\n${find.otp}`,
    });
  } else {
    setTimeout(() => checkOtpStatus(user, Rulzz), CHECK_INTERVAL);
  }
}

// Cek status pembayaran
async function checkPaymentStatus(user, Rulzz, selectedCountry) {
  const paymentStatus = await safeApiCall(() =>
    axios.get(
      `https://api.rulzzofficial.my.id/api/orkut/cekstatus?apikey=rulzzofficial0411&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`
    )
  );

  if (paymentStatus?.data?.amount == user.saweria.amount && user.saweria) {
    user.status_deposit = false;

    await Rulzz.sendMessage(user.saweria.chat, {
      text: `✅ *PEMBAYARAN BERHASIL DITERIMA*\n\n• ID : ${user.saweria.idDeposit}\n• Amount : Rp${user.saweria.amount}\n• Produk : Order Nokos ${selectedCountry.name}\n• Payment : ${paymentStatus.data.brand_name}`,
    }, { quoted: user.saweria.msg });

    await Rulzz.sendMessage(user.saweria.chat, {
      delete: user.saweria.msg.key,
    });

    const createOrder = await safeApiCall(() => virtu.OrderNumber(selectedCountry.virtuCode));
    if (!createOrder?.status) {
      return Rulzz.sendMessage(user.saweria.chat, {
        text: `❌ Gagal Order: ${createOrder?.data?.msg || "Unknown error"}`,
      });
    }

    user.order_otp = true;
    user.order_otp_id = createOrder.data.id;
    user.order_otp_number = createOrder.data.number;

    Rulzz.sendMessage(user.saweria.chat, {
      text: `✅ *Order Berhasil!*\n\n• Negara : ${selectedCountry.name}\n• Nomor : ${createOrder.data.number}\n• ID : ${createOrder.data.id}\n• Expire : 10 Menit`,
    });

    setOrderOtpExpiration(user, Rulzz);
    checkOtpStatus(user, Rulzz);
  } else {
    setTimeout(() => checkPaymentStatus(user, Rulzz, selectedCountry), CHECK_INTERVAL);
  }
}

// Fungsi utama pemesanan Nokos
async function handleOrderNokos(m, db, Rulzz, text) {
  const user = db.users[m.sender];
  if (user.status_deposit) {
    return m.reply("⚠️ Kamu masih punya transaksi aktif. Ketik *.batalbeli* untuk membatalkan.");
  }

  const num = parseInt(text);
  if (!text || isNaN(num)) return m.reply("⚠️ Nomor harus berupa angka dari list!");
  const selectedCountry = countryList[num];
  if (!selectedCountry) {
    return m.reply("❌ Negara tidak tersedia.\n\nKetik *.listnokos* untuk melihat list.");
  }

  const amount = selectedCountry.price + Math.floor(Math.random() * (250 - 110 + 1)) + 110;
  const paymentInfo = await safeApiCall(() =>
    axios.get(
      `https://api.rulzzofficial.my.id/api/orkut/createpayment?apikey=rulzzofficial0411&amount=${amount}&codeqr=${global.qrisOrderKuota}`
    )
  );

  if (!paymentInfo?.data?.result) {
    return m.reply("❌ Gagal membuat pembayaran. Coba lagi nanti.");
  }

  const { transactionId, amount: total, qrImageUrl } = paymentInfo.data.result;

  const messageText = `
*▧ INFORMASI PEMBAYARAN*

📄 *Detail:*
• Transaksi : ${transactionId}
• Produk    : Order Nokos ${selectedCountry.name}
• Total     : Rp${total}
• Berlaku   : 5 Menit

📌 *Catatan:*
- QRIS hanya berlaku 5 menit.
- Setelah bayar, bot akan memproses pesanan otomatis.`;

  const msgQr = await Rulzz.sendMessage(
    m.chat,
    { image: { url: qrImageUrl }, caption: messageText },
    { quoted: m }
  );

  user.status_deposit = true;
  user.saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: transactionId,
    amount: total.toString(),
  };

  checkPaymentStatus(user, Rulzz, selectedCountry);
}

module.exports = { handleOrderNokos };